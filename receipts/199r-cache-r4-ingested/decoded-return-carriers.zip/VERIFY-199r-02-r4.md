# VERIFY — W-gdb-199r-1nstinct-02 r4 (G0955 context): macOS-13-compatible allocator owner
# SUPPORT lane only, no acceptance claims. Synthetic/materialized Linux,
# clean_checkout:false, supplied candidate-input bytes (sha-match packet SHA256.json).
# Base main f8bcd542c1ff15e6494ce95fc94389c2e0021e96 unfetchable here (404/clone refused).

Toolchain actually used: Swift version 6.0.3 (swift-6.0.3-RELEASE), Target:
x86_64-unknown-linux-gnu. Owned paths only: Sources/GorAVPlaybackCore/CacheAccounting.swift
and kits/199r/1nstinct-02/. ArchiveItemSource untouched. No root Package.swift edits,
no OS minimum raised.

R4 CHANGE (finding: Synchronization.Mutex requires macOS 15, product floor is macOS 13):
- The issuer counter owner is now LockedCounter, an internal NSLock-based box.
  NSLock predates macOS 13; deployment floor untouched. Synchronization import removed.
- The @unchecked Sendable conformance on LockedCounter is the single unavoidable
  waiver, stated here as required: mutual exclusion is implemented manually with
  NSLock, so every access to the protected counter is serialized by construction.
  No nonisolated(unsafe) anywhere.
- Allocation stays checked, non-wrapping, fail-closed (addingReportingOverflow;
  poisoned instance with instanceID 0 at exhaustion; typed .overflow on every op;
  no trap). Issuer binding, foreign release/commit refusal before state mutation,
  destroyed-issuer rejection, throwing non-wrapping reset with exhaustion refusal,
  failure atomicity, zero policy: unchanged, all regressions retained.
- APIs used by CacheAccounting.swift (full list): Foundation (NSLock),
  UInt64.addingReportingOverflow, Dictionary, Equatable/Hashable/Sendable conformances,
  ArchiveItemSource.identifier (pinned in-module). Imports: Foundation only.
  macOS 13 availability itself is NOT_RUN (Linux toolchain cannot evaluate Darwin
  availability); no macOS-15-only symbols are present — verifiable by import/symbol
  inspection above.

STRICT SWIFT 6 EVIDENCE (exact commands + exits in logs/):
1. Module typecheck:
   $ swiftc -swift-version 6 -strict-concurrency=complete -typecheck -module-name GorAVPlaybackCore \
       Sources/GorAVPlaybackCore/ArchiveItemSource.swift Sources/GorAVPlaybackCore/CacheAccounting.swift
   strict_typecheck_compile_exit=0 (strict-clean with the NSLock box)
2. Strict semantic harness (shipped as strict-harness/main.swift — filename kept
   main.swift per Review lane note; top-level code):
   $ swiftc -swift-version 6 -strict-concurrency=complete -module-name strict_harness -o run \
       <both production sources> strict-harness/main.swift   -> strict_compile_exit=0
   $ ./run                                                   -> strict_semantic_exit=0, 11/11 PASS
   (own-token lifecycle; B.release/B.commit foreign typed refusal with no counter
   mutation; counter-exhaustion poison, typed overflow, no trap; reset-exhaustion
   refusal with unchanged state; UInt64.max boundary arithmetic.)
   Recorded again: full-package strict `swift test -Xswiftc -swift-version -Xswiftc 6
   -Xswiftc -strict-concurrency=complete` fails inside SwiftPM's generated Linux XCTest
   discovery code (all-discovered-tests.swift Sendable artifact), not returned sources;
   log carried from r3 (same artifact) and re-observed this revision.

STANDARD SUITE (Swift 6.0.3):
  $ kits/199r/1nstinct-02/tools/verify-pinned.sh  -> PIN_BYTES_MATCH, exit 0
  $ swift test --package-path kits/199r/1nstinct-02          -> exit 0, 14/14 (debug)
  $ swift test -c release --package-path kits/199r/1nstinct-02 -> exit 0, 14/14 (release)

Negative controls (mutants over the staged r4 copy; explicit exits): M1 capacity check
removed exit=1; M2 double release accepted exit=1; M3 reset keeps generation exit=1;
M4 cross-instance accepted exit=1; M5 poison bypass exit=1. Restore: PIN_BYTES_MATCH +
final green 14/14 (logs/199r-02r4-restored-final.log).

Revised production: Sources/GorAVPlaybackCore/CacheAccounting.swift sha256
fd0eabc795e6b8b8c1a72309f26db0c4b2e557bab224517e2581830a4038241e.
Patch against f8bcd542 candidate inputs (new files only; apply-check verified,
post-apply byte-match; supersedes r1/r2/r3): 199r-1nstinct-02-r4.patch sha256
5c53165a49936464fb025a8552137b07081d15fcd0e493ac1c14348b50f79abf.

NOT_RUN: Darwin/macOS (incl. macOS 13 availability verification — cannot be evaluated
on Linux), owner Mac, UI, playback, live cache wiring, eviction, mpv, integration,
pre-existing portable tests (none supplied), full-package strict swift test (toolchain
XCTest-discovery blocker, recorded).

Contents: VERIFY-r4.md, 199r-1nstinct-02-r4.patch, SHA256-MANIFEST-r4.txt,
strict-harness/main.swift, files-r4/ (full tree), logs/ (strict typecheck, strict
semantic, GREEN debug+release, 5 mutants, restored).
