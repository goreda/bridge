import Foundation
let accounting=CacheAccounting(capacity:100)
print(accounting.instanceID)
