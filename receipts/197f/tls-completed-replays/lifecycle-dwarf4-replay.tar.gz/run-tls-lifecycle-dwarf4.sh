#!/usr/bin/env bash
# Invoke: bash run-tls-inventory.sh CHECKOUT FF_PREFIX
# CHECKOUT must be a clean a34e2cd checkout. FF_PREFIX is the provider used
# by the product build, not a system ffmpeg. Runs in a disposable archive.
set -u -o pipefail
repo=$(realpath "$1"); ff=$(realpath "$2"); here=$(cd "$(dirname "$0")" && pwd)
want=a34e2cd96b6825932a196424a17cc62962e910a7
[ "$(git -C "$repo" rev-parse HEAD)" = "$want" ] || exit 2
[ -z "$(git -C "$repo" status --porcelain --untracked-files=all)" ] || exit 2
work=$(mktemp -d)
trap 'rm -f "$work/key.pem" "$work/cert.pem"' EXIT
printf 'RETAINED_TREE=%s\n' "$work/tree"
mkdir "$work/tree"
git -C "$repo" archive HEAD | tar -x -C "$work/tree"
printf 'product_sha=%s\nprovider_prefix=%s\n' "$want" "$ff"
export PKG_CONFIG_PATH="$ff/lib/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"
export LD_LIBRARY_PATH="$ff/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
pkg-config --modversion libavformat libavcodec libavutil libswresample
cc "$here/protocol-inventory.c" -I"$ff/include" -L"$ff/lib" -Wl,-rpath,"$ff/lib" $(pkg-config --static --cflags --libs libavformat libavcodec libavutil) -o "$work/protocol-inventory" || exit 2
ldd "$work/protocol-inventory"
"$work/protocol-inventory"; inventory_rc=$?
# Ephemeral fixture key: never print, attach or retain it.
openssl req -x509 -newkey rsa:2048 -nodes -keyout "$work/key.pem" -out "$work/cert.pem" -days 1 -subj /CN=localhost -addext 'subjectAltName=IP:127.0.0.1,DNS:localhost' > /dev/null 2>&1 || exit 2
export M2_TLS_CERT="$work/cert.pem" M2_TLS_KEY="$work/key.pem"
cp "$here/tls-lifecycle-main.swift" "$work/tree/Sources/remote-source-tests/main.swift"
python3 "$here/patch-tls-close-order.py" "$work/tree" || exit 2
cd "$work/tree"
swiftc --version
# Preserve actual red status. No expected failure is converted to product PASS.
# Existing Package.swift/provider layout must already be configured by the lane.
# Link explicitly to the measured candidate provider, including static deps.
mapfile -t ff_link < <(pkg-config --static --libs libavformat libavcodec libavutil libswscale libswresample | python3 -c 'import shlex,sys; print("\n".join(shlex.split(sys.stdin.read())))')
swift_args=(--sanitize address -Xswiftc -dwarf-version=4 -Xcc -gdwarf-4 -Xcc "-I$ff/include")
for flag in "${ff_link[@]}"; do swift_args+=(-Xlinker "$flag"); done
printf 'BUILD_START DWARF4 ASAN\n'
timeout 300 swift build "${swift_args[@]}" --product remote-source-tests > "$work/build.log" 2>&1
build_rc=$?; tail -15 "$work/build.log"
[ "$build_rc" -eq 0 ] || { printf 'BUILD_FAILED rc=%s log=%s\n' "$build_rc" "$work/build.log"; exit 2; }
printf 'BUILD_FINISHED\n' 
bin=$(swift build "${swift_args[@]}" --show-bin-path)/remote-source-tests
printf 'RETAINED_BINARY=%s\n' "$bin"
timeout 300 "$bin" 2>&1 | tee "$work/lifecycle.log"; product_rc=${PIPESTATUS[0]}
python3 - "$work/lifecycle.log" > "$work/offsets" <<'PYOFF'
import re,sys
s=open(sys.argv[1]).read()
for x in dict.fromkeys(re.findall(r'remote-source-tests\+(0x[0-9a-fA-F]+)',s)): print(x)
PYOFF
if command -v addr2line >/dev/null; then xargs -r addr2line -f -C -e "$bin" < "$work/offsets"; fi
printf 'SOURCE_MAP open\n'
nl -ba Sources/GorAVFFmpegAdapter/FFmpegSoftwareAudioDecoder.swift | sed -n '310,345p;490,515p'
printf 'SOURCE_MAP close\n'
nl -ba Sources/GorAVFFmpegAdapter/FFmpegSoftwareAudioDecoder.swift | sed -n '810,858p' 
printf 'RAW_LOG=%s BUILD_LOG=%s\n' "$work/lifecycle.log" "$work/build.log"
printf 'M2_TLS_LIFECYCLE_DWARF4_ASAN_CANDIDATE_RESULT inventory_exit=%s product_open_exit=%s\n' "$inventory_rc" "$product_rc"
# Retain cancellation/deadline regression coverage; run regardless of TLS status.
timeout 180 swift run "${swift_args[@]}" audio-interrupt-tests; lifecycle_rc=$?
printf 'M2_TLS_LIFECYCLE_DWARF4_ASAN_LIFECYCLE exit=%s\n' "$lifecycle_rc"
[ "$inventory_rc" -eq 0 ] && [ "$product_rc" -eq 0 ] && [ "$lifecycle_rc" -eq 0 ]
