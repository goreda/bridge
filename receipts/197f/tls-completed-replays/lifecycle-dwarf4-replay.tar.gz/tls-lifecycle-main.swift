// Packet-authored TLS adaptation of remote-source-tests at a34e2cd.
// Measures encrypted loopback open only, NOT peer certificate verification,
// public CA validation, decoded PCM, or live-service availability.
import Foundation
#if canImport(Glibc)
import Glibc
#elseif canImport(Darwin)
import Darwin
#endif
setbuf(stdout, nil)
import GorAVCore
import GorAVFFmpegAdapter

// R3 (arch-195b) witness: remote (http) source open with headers/cookies,
// redaction, and refusal without credentials. Local python http server
// requires a header AND a cookie; serves a PCM wav (stream-friendly probe).

var failures = 0
func check(_ name: String, _ ok: Bool, _ info: String = "") {
    print((ok ? "PASS " : "FAIL ") + name + (ok || info.isEmpty ? "" : " \(info)"))
    if !ok { failures += 1 }
}

// U-series: redaction and option summary (pure)
check("U1 userinfo redacted", URLRedaction.redact("http://user:secret@example.com/a.wav") == "REDACTED")
check("U2 query values and keys redacted", URLRedaction.redact("https://h/p?token=abc&x=1") == "REDACTED")
check("U3 fragment and path redacted", URLRedaction.redact("http://h/secret#frag") == "REDACTED")
check("U4 local path not exposed", URLRedaction.redact("/plain/path.wav") == "REDACTED")
check("U6 malformed credential redacted", URLRedaction.redact("http://user:slash/secret@host/p?bareSecret") == "REDACTED")
check("U7 encoded credential redacted", URLRedaction.redact("http://%73ecret@host/%74oken?%73ecret") == "REDACTED")
check("U5 summary counts only", SourceOpenOptions(headers: ["Authorization": "s3cr3t"], cookies: ["k": "v"]).redactedSummary == "headers=1 cookies=1 deadline=none")

// S-series: live http open through the admitted remote path
let root = ProcessInfo.processInfo.environment["GORAV_REPO"] ?? FileManager.default.currentDirectoryPath
let fixture = root + "/fixtures/tone-48k.wav"
let tmp = NSTemporaryDirectory() + "r3srv-\(UUID().uuidString)"
try! FileManager.default.createDirectory(atPath: tmp, withIntermediateDirectories: true)
let serverPy = tmp + "/server.py"
let portFile = tmp + "/port"
let script = """
import http.server, sys, threading, ssl, time
fixture = sys.argv[1]
portfile = sys.argv[2]
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.headers.get('X-GorAV-Test') != 'yes' or ('session=abc' not in (self.headers.get('Cookie') or '') or 'other=def' not in (self.headers.get('Cookie') or '')):
            self.send_response(403); self.end_headers(); return
        if self.path == '/slow.wav': time.sleep(4.0)
        with open(fixture, 'rb') as fh: data = fh.read()
        self.send_response(200)
        self.send_header('Content-Type', 'audio/wav')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Accept-Ranges', 'bytes')
        self.end_headers()
        self.wfile.write(data)
    def log_message(self, *a): pass
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H)
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx.load_cert_chain(sys.argv[3], sys.argv[4])
srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
with open(portfile, 'w') as fh: fh.write(str(srv.server_address[1]))
srv.serve_forever()
"""
try! script.write(toFile: serverPy, atomically: true, encoding: .utf8)
let proc = Process()
proc.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
guard let cert = ProcessInfo.processInfo.environment["M2_TLS_CERT"], let key = ProcessInfo.processInfo.environment["M2_TLS_KEY"] else { fatalError("TLS fixture paths required") }
proc.arguments = [serverPy, fixture, portFile, cert, key]
try! proc.run()
var port: String? = nil
for _ in 0..<200 {
    if let p = try? String(contentsOfFile: portFile, encoding: .utf8), !p.isEmpty { port = p.trimmingCharacters(in: .whitespacesAndNewlines); break }
    try? await Task.sleep(nanoseconds: 50_000_000)
}
guard let port else {
    check("S0 server started", false)
    print("remote-source-tests: \(failures) FAIL"); exit(1)
}
check("S0 server started on 127.0.0.1:\(port)", true)
let url = "https://127.0.0.1:\(port)/tone-48k.wav"

func probeOpen(withOptions opts: SourceOpenOptions?, epoch: UInt64) async -> String {
    let d = FFmpegSoftwareAudioDecoder()
    do { try d.pinLocalRoots([root]) } catch { return "pin \(error)" }
    if let opts { d.remoteOpenOptions = opts }
    let src = SourceDescriptor(id: url, kind: .remote, seekable: true)
    do {
        try await d.open(source: src, session: SessionID(uncheckedEpoch: epoch))
    } catch { return "open-error: \(error)" }
    // drain the .opened event
    var seen = "no-event"
    if let ev = await d.nextEvent(session: SessionID(uncheckedEpoch: epoch)), case .opened(let c, let r, let ch, _, _) = ev {
        seen = "\(c) \(r)Hz x\(ch)"
    }
    await d.close(session: SessionID(uncheckedEpoch: epoch))
    return seen
}

let noCred = await probeOpen(withOptions: nil, epoch: 91)
check("S1 remote open without credentials is refused by the server", noCred.hasPrefix("open-error"), noCred)
let withCred = await probeOpen(withOptions: SourceOpenOptions(headers: ["X-GorAV-Test": "yes"], cookies: ["session": "abc", "other": "def"]), epoch: 92)
check("TLS product audio open with header+cookie identifies wav", withCred == "pcm_s16le 48000Hz x2", withCred)

let injected = await probeOpen(withOptions: SourceOpenOptions(headers: ["X-GorAV-Test": "yes\r\nX-Injected: true"]), epoch: 95)
check("S2b header newline injection refused", injected.hasPrefix("open-error"), injected)

// S3: transport failure errors carry the redacted URL, never the secret
let d2 = FFmpegSoftwareAudioDecoder()
try! d2.pinLocalRoots([root])
let secretURL = "http://user:s3cr3t@127.0.0.1:1/x.wav?token=abc123"
do {
    try await d2.open(source: SourceDescriptor(id: secretURL, kind: .remote, seekable: true), session: SessionID(uncheckedEpoch: 93))
    check("S3 dead-endpoint open throws", false, "opened")
} catch {
    let msg = "\(error)"
    check("S3 error redacts userinfo and query", msg.contains("REDACTED") && !msg.contains("s3cr3t") && !msg.contains("abc123"), msg)
}

// S4: scheme admission still enforced for the audio path
do {
    try await d2.open(source: SourceDescriptor(id: "ftp://127.0.0.1/x.wav", kind: .remote, seekable: true), session: SessionID(uncheckedEpoch: 94))
    check("S4 non-admitted scheme refused", false, "opened")
} catch {
    check("S4 non-admitted scheme refused", "\(error)".contains("scheme not admitted"), "\(error)")
}

// Added to the encrypted loopback fixture before server teardown.
let credentials = SourceOpenOptions(headers: ["X-GorAV-Test": "yes"], cookies: ["session": "abc", "other": "def"])
func lifecycleOpen(_ epoch: UInt64, abandon: Bool) async -> Bool {
    var decoder: FFmpegSoftwareAudioDecoder? = FFmpegSoftwareAudioDecoder()
    decoder!.remoteOpenOptions = credentials
    do {
        try await decoder!.open(source: SourceDescriptor(id: url, kind: .remote, seekable: true), session: SessionID(uncheckedEpoch: epoch))
        if !abandon { await decoder!.close(session: SessionID(uncheckedEpoch: epoch)) }
        decoder = nil // Exercise actual deinit, not only explicit-close.
        return true
    } catch { return false }
}
for i in 0..<10 {
    check("L explicit close iteration \(i)", await lifecycleOpen(200 + UInt64(i), abandon: false))
    check("L abandon/deinit iteration \(i)", await lifecycleOpen(300 + UInt64(i), abandon: true))
}
for i in 0..<3 {
    let rejected = await probeOpen(withOptions: nil, epoch: 400 + UInt64(i))
    check("L failed open iteration \(i)", rejected.hasPrefix("open-error"))
}
func blockedOpen(_ epoch: UInt64, cancel: Bool) async -> (String, Double) {
    let decoder = FFmpegSoftwareAudioDecoder()
    var opts = credentials
    opts.openDeadlineSeconds = cancel ? 8.0 : 0.25
    decoder.remoteOpenOptions = opts
    if cancel {
        Thread.detachNewThread {
            Thread.sleep(forTimeInterval: 0.25)
            decoder.requestInterrupt(session: SessionID(uncheckedEpoch: epoch))
        }
    }
    let begin = DispatchTime.now().uptimeNanoseconds
    var message = "unexpected-open"
    do {
        try await decoder.open(source: SourceDescriptor(id: "https://127.0.0.1:\(port)/slow.wav", kind: .remote, seekable: true), session: SessionID(uncheckedEpoch: epoch))
        await decoder.close(session: SessionID(uncheckedEpoch: epoch))
    } catch { message = "\(error)" }
    let seconds = Double(DispatchTime.now().uptimeNanoseconds - begin) / 1e9
    return (message, seconds)
}
let timed = await blockedOpen(500, cancel: false)
check("L TLS blocked open deadline", timed.0.contains("deadline exceeded") && timed.1 < 2.5, "\(timed)")
let cancelled = await blockedOpen(501, cancel: true)
check("L TLS blocked open cancel", cancelled.0.contains("interrupted") && cancelled.1 < 2.5, "\(cancelled)")
let recovery = await probeOpen(withOptions: credentials, epoch: 502)
check("L recovery after cancel/deadline", recovery == "pcm_s16le 48000Hz x2", recovery)

proc.terminate()
print(failures == 0 ? "m2-tls-open: all pass" : "remote-source-tests: \(failures) FAIL")
exit(failures == 0 ? 0 : 1)
