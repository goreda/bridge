#include <stdio.h>
#include <string.h>
#include <libavformat/avio.h>
#include <libavformat/avformat.h>
int main(void) {
    void *opaque = NULL; const char *p; int h=0,t=0,s=0;
    printf("avformat_version=%u\nconfiguration=%s\n",avformat_version(),avformat_configuration());
    while ((p=avio_enum_protocols(&opaque,0))) {
        printf("input_protocol=%s\n",p);
        h |= !strcmp(p,"http"); t |= !strcmp(p,"tcp"); s |= !strcmp(p,"https");
    }
    printf("provider-required: http=%d tcp=%d https=%d\n",h,t,s);
    return h&&t&&s ? 0 : 1;
}
