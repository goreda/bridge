// swift-tools-version:6.0
import PackageDescription

// Isolated test package for W-gdb-199r-in2tinct-02 (TRANSPORT-EXTENDED).
// Builds the actual production module staged under Sources/; the runner
// (run_tests.sh) verifies byte equality of the staged copy against the
// production path Sources/GorAVPlaybackCore/ChapterNavigation.swift before
// any build. No reimplementation exists in this package.
let package = Package(
    name: "in2tinct-02-chapter-navigation",
    targets: [
        .target(name: "GorAVPlaybackCore", path: "Sources/GorAVPlaybackCore"),
        .testTarget(
            name: "ChapterNavigationTests",
            dependencies: ["GorAVPlaybackCore"],
            path: "Tests/ChapterNavigationTests"
        ),
    ]
)
