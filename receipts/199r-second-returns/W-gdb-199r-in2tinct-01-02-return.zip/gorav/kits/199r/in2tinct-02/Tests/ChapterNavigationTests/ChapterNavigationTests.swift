import XCTest
@testable import GorAVPlaybackCore

/// Semantic tests for the exact delivered82 ChapterNavigation port
/// (W-gdb-199r-in2tinct-02). The reference bytes are the compatibility
/// contract: these tests pin behavior, not implementation details.
final class ChapterNavigationTests: XCTestCase {

    private func entry(_ i: Int, _ s: Double, _ e: Double) -> ChapterNavigationEntry {
        ChapterNavigationEntry(index: i, startSeconds: s, endSeconds: e)
    }

    /// 0:[0,10) 1:[10,20) 2:[20,30)
    private var three: [ChapterNavigationEntry] { [entry(0, 0, 10), entry(1, 10, 20), entry(2, 20, 30)] }

    private func refusal(_ entries: [ChapterNavigationEntry], _ pos: Double?, _ dir: ChapterDirection) -> ChapterNavigationRefusal? {
        do {
            _ = try ChapterNavigation.target(entries: entries, position: pos, direction: dir)
            return nil
        } catch let e as ChapterNavigationRefusal {
            return e
        } catch {
            XCTFail("unexpected error type: \(error)")
            return nil
        }
    }

    // MARK: happy paths

    func testNextFromMiddleReturnsFollowingEntry() throws {
        let t = try ChapterNavigation.target(entries: three, position: 12, direction: .next)
        XCTAssertEqual(t.index, 2)
        XCTAssertEqual(t.startSeconds, 20)
    }

    func testPreviousFromMiddleReturnsPrecedingEntry() throws {
        let t = try ChapterNavigation.target(entries: three, position: 12, direction: .previous)
        XCTAssertEqual(t.index, 0)
    }

    func testNextAtExactChapterStartCountsAsInsideThatChapter() throws {
        // position 10 is inside chapter 1 ([10,20) half-open by start ordering)
        let t = try ChapterNavigation.target(entries: three, position: 10, direction: .next)
        XCTAssertEqual(t.index, 2)
    }

    func testNextFromBeforeFirstReturnsFirstEntry() throws {
        // Chapters starting at 10/20/30: position 5 precedes every start, so
        // there is no current chapter and next targets the first entry.
        // (Positions < 0 refuse unknownPosition, so "before first" requires a
        // first start > position >= 0.)
        let shifted = [entry(0, 10, 20), entry(1, 20, 30), entry(2, 30, 40)]
        let t = try ChapterNavigation.target(entries: shifted, position: 5, direction: .next)
        XCTAssertEqual(t.index, 0)
    }

    func testNegativeZeroPositionEqualsZeroAndIsValid() throws {
        // -0.0 >= 0 and -0.0 == 0.0 in IEEE, so chapter starting at 0 is current.
        let t = try ChapterNavigation.target(entries: three, position: -0.0, direction: .next)
        XCTAssertEqual(t.index, 1)
    }

    // MARK: boundaries, no wrap

    func testNextAtLastChapterRefusesBoundaryNoWrap() {
        XCTAssertEqual(refusal(three, 25, .next), .boundary)
    }

    func testNextExactlyAtLastStartRefusesBoundary() {
        XCTAssertEqual(refusal(three, 20, .next), .boundary)
    }

    func testPreviousBeforeFirstRefusesBoundary() {
        XCTAssertEqual(refusal(three, 0, .previous), .boundary)
    }

    func testPreviousAtFirstChapterRefusesBoundaryNoWrap() {
        XCTAssertEqual(refusal(three, 5, .previous), .boundary)
    }

    func testPreviousFromSecondReturnsFirst() throws {
        let t = try ChapterNavigation.target(entries: three, position: 10, direction: .previous)
        XCTAssertEqual(t.index, 0)
    }

    // MARK: positions

    func testZeroPositionIsValid() throws {
        let t = try ChapterNavigation.target(entries: three, position: 0, direction: .next)
        XCTAssertEqual(t.index, 1)
    }

    func testNilPositionRefusesUnknown() {
        XCTAssertEqual(refusal(three, nil, .next), .unknownPosition)
    }

    func testNaNPositionRefusesUnknown() {
        XCTAssertEqual(refusal(three, .nan, .next), .unknownPosition)
    }

    func testPositiveInfinitePositionRefusesUnknown() {
        XCTAssertEqual(refusal(three, .infinity, .next), .unknownPosition)
    }

    func testNegativeInfinitePositionRefusesUnknown() {
        XCTAssertEqual(refusal(three, -.infinity, .next), .unknownPosition)
    }

    func testNegativePositionRefusesUnknown() {
        XCTAssertEqual(refusal(three, -0.5, .next), .unknownPosition)
    }

    // MARK: inventory validation

    func testEmptyInventoryRefusesUnavailable() {
        XCTAssertEqual(refusal([], 0, .next), .unavailable)
        XCTAssertEqual(refusal([], nil, .previous), .unavailable)
    }

    func testDuplicateIndicesRefuseInvalidInventory() {
        let bad = [entry(1, 0, 10), entry(1, 10, 20)]
        XCTAssertEqual(refusal(bad, 5, .next), .invalidInventory)
    }

    func testNonmonotonicStartsRefuseInvalidInventory() {
        let bad = [entry(0, 10, 20), entry(1, 5, 15)]
        XCTAssertEqual(refusal(bad, 12, .next), .invalidInventory)
    }

    func testEqualStartsRefuseInvalidInventory() {
        // start must be strictly greater than the prior start
        let bad = [entry(0, 10, 20), entry(1, 10, 30)]
        XCTAssertEqual(refusal(bad, 12, .next), .invalidInventory)
    }

    func testEndBeforeStartRefusesInvalidInventory() {
        let bad = [entry(0, 10, 5)]
        XCTAssertEqual(refusal(bad, 10, .next), .invalidInventory)
    }

    func testNegativeStartRefusesInvalidInventory() {
        let bad = [entry(0, -1, 5)]
        XCTAssertEqual(refusal(bad, 0, .next), .invalidInventory)
    }

    func testNonfiniteEntryTimesRefuseInvalidInventory() {
        XCTAssertEqual(refusal([entry(0, .nan, 5)], 0, .next), .invalidInventory)
        XCTAssertEqual(refusal([entry(0, 0, .infinity)], 0, .next), .invalidInventory)
    }

    func testNegativeEntryIndexRefusesInvalidInventory() {
        let bad = [entry(-1, 0, 10)]
        XCTAssertEqual(refusal(bad, 5, .next), .invalidInventory)
    }

    // MARK: sparse stable indices

    func testSparseIndicesArePreservedNotRenumbersed() throws {
        let sparse = [entry(3, 0, 10), entry(7, 10, 20), entry(42, 20, 30)]
        let t = try ChapterNavigation.target(entries: sparse, position: 15, direction: .next)
        XCTAssertEqual(t, sparse[2])
        XCTAssertEqual(t.index, 42)
        let p = try ChapterNavigation.target(entries: sparse, position: 15, direction: .previous)
        XCTAssertEqual(p.index, 3)
    }

    // MARK: overflow before millisecond conversion

    func testOverflowingStartRefusesInvalidInventoryBeforeConversion() {
        // startSeconds*1000 must be Int64-representable; Double(Int64.max) is not after scaling.
        let huge = Double(Int64.max) // ~9.22e18; *1000 overflows Int64
        let bad = [entry(0, huge, huge)]
        XCTAssertEqual(refusal(bad, 0, .next), .invalidInventory)
    }

    func testLargeRepresentableMillisecondStartValidatesThenHitsBoundary() {
        // 1e15 s is Double-exact here and 1e18 ms fits Int64: validation must
        // pass, then the single-chapter next hits boundary (no wrap).
        let s = 1_000_000_000_000_000.0
        let ok = [entry(0, s, s + 1)]
        XCTAssertEqual(refusal(ok, s, .next), .boundary)
    }

    func testInt64MaxOver1000RoundsUpAndRefusesInvalidInventory() {
        // Double(Int64.max/1000) rounds up past the exact quotient; *1000 then
        // exceeds Int64.max, so the guard refuses before conversion.
        let s = Double(Int64.max / 1000)
        let bad = [entry(0, s, s + 1)]
        XCTAssertEqual(refusal(bad, s, .next), .invalidInventory)
    }

    // MARK: direction coverage on single entry

    func testSingleEntryNextAndPreviousBothRefuseBoundary() {
        let one = [entry(0, 0, 10)]
        XCTAssertEqual(refusal(one, 5, .next), .boundary)
        XCTAssertEqual(refusal(one, 5, .previous), .boundary)
    }
}
