#!/bin/sh
# Runner for W-gdb-199r-in2tinct-02. Verifies the staged production source is
# byte-identical to the gorav production path before running swift test.
# Usage: kits/199r/in2tinct-02/run_tests.sh   (from anywhere)
set -e
KIT="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$KIT/../../.." && pwd)"
PROD="$ROOT/Sources/GorAVPlaybackCore/ChapterNavigation.swift"
STAGED="$KIT/Sources/GorAVPlaybackCore/ChapterNavigation.swift"
for f in "$PROD" "$STAGED"; do
    [ -f "$f" ] || { echo "MISSING: $f" >&2; exit 2; }
done
hp=$(sha256sum "$PROD" | awk '{print $1}')
hs=$(sha256sum "$STAGED" | awk '{print $1}')
echo "production $hp  $PROD"
echo "staged     $hs  $STAGED"
[ "$hp" = "$hs" ] || { echo "BYTE-INEQUALITY: staged copy diverges from production; refusing to test" >&2; exit 3; }
echo "byte equality verified; building and testing actual production bytes"
swift --version
swift test --package-path "$KIT" 2>&1
echo "swift test exit: $?"
