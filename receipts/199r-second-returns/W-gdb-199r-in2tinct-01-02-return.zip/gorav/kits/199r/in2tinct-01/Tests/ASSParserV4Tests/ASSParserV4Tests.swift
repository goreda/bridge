import XCTest
@testable import GorAVSubtitles

/// Baseline semantic tests for W-gdb-199r-in2tinct-01: SSA [V4 Styles] reading
/// in the pinned production ASSParser (gorav cf3e3f17), V4+ behavior kept
/// unchanged. Every case here runs the actual production bytes; the runner
/// verifies byte equality before building.
final class ASSParserV4Tests: XCTestCase {

    // MARK: fixtures

    /// SSA V4 document: V4 style table (AlphaLevel/Encoding, no ScaleX/...),
    /// Marked-style events format, one cue whose text carries an embedded comma.
    private let v4Doc = """
    [Script Info]
    PlayResX: 384
    PlayResY: 288

    [V4 Styles]
    Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, TertiaryColour, ShadowColour, Bold, Italic, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, AlphaLevel, Encoding
    Style: Default,Arial,16,&H11223344,&H000000FF,&H00000000,&H80000000,-1,0,1,2,0,2,20,20,20,0,1
    Style: Alt,Courier,18,&H00FFFFFF,&H00000000,&H00000000,&H00000000,0,0,1,2,0,2,20,20,20,0,1

    [Events]
    Format: Marked, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
    Dialogue: Marked=0,0:00:01.00,0:00:03.00,Default,,0,0,0,,Hello, world
    Dialogue: Marked=0,0:00:04.00,0:00:06.50,Alt,,0,0,0,,second line
    """

    /// ASS V4+ document with the standard V4+ style and event formats.
    private let v4plusDoc = """
    [Script Info]
    PlayResX: 640
    PlayResY: 360

    [V4+ Styles]
    Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
    Style: Default,Arial,20,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,0,2,10,10,10,1

    [Events]
    Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
    Dialogue: 0,0:00:00.50,0:00:02.00,Default,,0,0,0,,v4plus cue
    Comment: 0,0:00:09.00,0:00:10.00,Default,,0,0,0,,not a cue
    """

    private func parse(_ s: String) throws -> ASSParser.Document { try ASSParser.parse(s) }

    private func refusal(_ s: String) -> ASSParser.ParseError? {
        do { _ = try ASSParser.parse(s); return nil }
        catch let e as ASSParser.ParseError { return e }
        catch { XCTFail("unexpected error type: \(error)"); return nil }
    }

    // MARK: V4 style reading

    func testV4StylesParseIntoStyleModel() throws {
        let d = try parse(v4Doc)
        XCTAssertEqual(d.styles.count, 2)
        XCTAssertEqual(d.skippedStyles, [])
        let def = d.styles[0]
        XCTAssertEqual(def.name, "Default")
        XCTAssertEqual(def.fontName, "Arial")
        XCTAssertEqual(def.fontSize, 16)
        // &H11223344 is AABBGGRR: AA=11 BB=22 GG=33 RR=44 -> AARRGGBB 0x11443322
        XCTAssertEqual(def.primaryColourARGB, 0x11443322)
        let alt = d.styles[1]
        XCTAssertEqual(alt.name, "Alt")
        XCTAssertEqual(alt.primaryColourARGB, 0x00FFFFFF)
        XCTAssertEqual(d.playResX, 384)
        XCTAssertEqual(d.playResY, 288)
    }

    func testV4CuesCarryTextAndStyleAssociation() throws {
        let d = try parse(v4Doc)
        XCTAssertEqual(d.cues.count, 2)
        XCTAssertEqual(d.cues[0].startSeconds, 1.0, accuracy: 1e-9)
        XCTAssertEqual(d.cues[0].endSeconds, 3.0, accuracy: 1e-9)
        XCTAssertEqual(d.cues[0].text, "Hello, world") // embedded comma survives
        XCTAssertEqual(d.cues[0].styleName, "Default")
        XCTAssertEqual(d.cues[1].endSeconds, 6.5, accuracy: 1e-9)
        XCTAssertEqual(d.cues[1].styleName, "Alt")
    }

    // MARK: V4+ unchanged

    func testV4PlusStylesAndCuesUnchanged() throws {
        let d = try parse(v4plusDoc)
        XCTAssertEqual(d.styles.count, 1)
        XCTAssertEqual(d.styles[0].fontSize, 20)
        XCTAssertEqual(d.styles[0].primaryColourARGB, 0x00FFFFFF)
        XCTAssertEqual(d.cues.count, 1) // Comment row is not a cue
        XCTAssertEqual(d.cues[0].text, "v4plus cue")
        XCTAssertEqual(d.skippedStyles, [])
        XCTAssertEqual(d.unsupportedOverrides, [])
    }

    // MARK: explicit Format column order

    func testExplicitFormatColumnOrderIsHonored() throws {
        let reordered = """
        [V4 Styles]
        Format: Fontsize, PrimaryColour, Fontname, Name
        Style: 22,&H00010203,Helvetica,Odd
        [Events]
        Format: Text, End, Start
        Dialogue: body text,0:00:02.00,0:00:01.00
        """
        let d = try parse(reordered)
        XCTAssertEqual(d.styles.count, 1)
        XCTAssertEqual(d.styles[0].name, "Odd")
        XCTAssertEqual(d.styles[0].fontName, "Helvetica")
        XCTAssertEqual(d.styles[0].fontSize, 22)
        // &H00010203: AA=00 BB=01 GG=02 RR=03 -> 0x00030201
        XCTAssertEqual(d.styles[0].primaryColourARGB, 0x00030201)
        XCTAssertEqual(d.cues.count, 1)
        XCTAssertEqual(d.cues[0].text, "body text")
        XCTAssertEqual(d.cues[0].startSeconds, 1.0, accuracy: 1e-9)
        XCTAssertEqual(d.cues[0].endSeconds, 2.0, accuracy: 1e-9)
        // Events format carries no Style field: association is nil, not guessed.
        XCTAssertNil(d.cues[0].styleName)
    }

    // MARK: missing fields

    func testStyleRowWithFewerFieldsIsSkippedOnRecord() throws {
        let s = """
        [V4 Styles]
        Format: Name, Fontname, Fontsize, PrimaryColour, Extra
        Style: OnlyName,Arial,16,&H00000000
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,ok
        """
        let d = try parse(s)
        XCTAssertEqual(d.styles, [])
        XCTAssertEqual(d.skippedStyles, [ASSParser.SkippedStyle(line: 3, reason: "field count")])
        XCTAssertEqual(d.cues.count, 1)
    }

    func testStyleFormatMissingRequiredColumnIsSkippedOnRecord() throws {
        let s = """
        [V4+ Styles]
        Format: Name, Fontsize, PrimaryColour
        Style: Default,16,&H00000000
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,ok
        """
        let d = try parse(s)
        XCTAssertEqual(d.skippedStyles, [ASSParser.SkippedStyle(line: 3, reason: "missing required field")])
    }

    func testStyleRowBeforeAnyFormatIsSkippedOnRecord() throws {
        let s = """
        [V4 Styles]
        Style: Default,Arial,16,&H00000000
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,ok
        """
        let d = try parse(s)
        XCTAssertEqual(d.skippedStyles, [ASSParser.SkippedStyle(line: 2, reason: "no style Format")])
    }

    func testDialogueWithFewerFieldsRefuses() {
        let s = """
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00
        """
        XCTAssertEqual(refusal(s), .badDialogueFieldCount(line: 3))
    }

    // MARK: malformed timestamps

    func testMalformedTimestampsRefuse() {
        let base = """
        [Events]
        Format: Start, End, Text
        Dialogue: %@,0:00:02.00,ok
        """
        for bad in ["0:0:01.00", "00:01.00", "0:00:01", "0:00:01.0", "0:00:60.00", "0:60:01.00", "x:00:01.00", "0:00:01.000"] {
            XCTAssertEqual(refusal(String(format: base, bad)), .badTimestamp(line: 3), "expected badTimestamp for \(bad)")
        }
    }

    func testEndNotAfterStartRefuses() {
        let s = """
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:02.00,0:00:02.00,ok
        """
        XCTAssertEqual(refusal(s), .endNotAfterStart(line: 3))
    }

    // MARK: style-only errors vs content refusals

    func testCosmeticStyleErrorDoesNotBlockContent() throws {
        // Bad style row is cosmetic (skipped, on record); cues still parse.
        let s = """
        [V4 Styles]
        Format: Name, Fontname, Fontsize, PrimaryColour
        Style: Broken,Arial,notasize,&H00000000
        Style: Good,Arial,16,&H00000000
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,content survives
        """
        let d = try parse(s)
        XCTAssertEqual(d.skippedStyles, [ASSParser.SkippedStyle(line: 3, reason: "bad fontsize")])
        XCTAssertEqual(d.styles.map { $0.name }, ["Good"])
        XCTAssertEqual(d.cues.count, 1)
    }

    func testContentErrorRefusesWholeDocument() {
        // Malformed dialogue is content: typed refusal, no partial document.
        let s = """
        [V4 Styles]
        Format: Name, Fontname, Fontsize, PrimaryColour
        Style: Good,Arial,16,&H00000000
        [Events]
        Format: Start, End, Text
        Dialogue: bogus,0:00:02.00,broken
        """
        XCTAssertEqual(refusal(s), .badTimestamp(line: 6))
    }

    // MARK: colour conversion

    func testColourConversionMatrix() throws {
        func colour(_ raw: String) -> UInt32? {
            let s = """
            [V4+ Styles]
            Format: Name, Fontname, Fontsize, PrimaryColour
            Style: C,Arial,16,\(raw)
            [Events]
            Format: Start, End, Text
            Dialogue: 0:00:01.00,0:00:02.00,ok
            """
            guard let d = try? parse(s), d.skippedStyles.isEmpty else { return nil }
            return d.styles.first?.primaryColourARGB
        }
        XCTAssertEqual(colour("&H11223344"), 0x11443322) // 8-digit AABBGGRR -> AARRGGBB
        XCTAssertEqual(colour("&HFFFFFF"), 0x00FFFFFF)   // 6-digit implies alpha 00
        XCTAssertEqual(colour("&h00000000"), 0x00000000) // case-insensitive prefix
        XCTAssertNil(colour("&H12345"))                  // wrong length refuses
        XCTAssertNil(colour("&H1234567"))                // 7 digits refuses
        XCTAssertNil(colour("&H123456789"))              // 9 digits refuses
        XCTAssertNil(colour("&HZZZZZZZZ"))               // non-hex refuses
        XCTAssertNil(colour("123456"))                   // missing &H refuses
    }

    func testBadColourIsSkippedNotRefused() throws {
        let s = """
        [V4 Styles]
        Format: Name, Fontname, Fontsize, PrimaryColour
        Style: Bad,Arial,16,red
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,ok
        """
        let d = try parse(s)
        XCTAssertEqual(d.skippedStyles, [ASSParser.SkippedStyle(line: 3, reason: "bad colour")])
        XCTAssertEqual(d.cues.count, 1)
    }

    // MARK: override handling

    func testOverrideOnlyTextRefusesExplicitly() {
        let s = """
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,{\\pos(10,10)\\fad(300,300)}
        """
        XCTAssertEqual(refusal(s), .overrideOnlyText(line: 3))
    }

    func testOverrideBlocksAreReportedAndStrippedNeverInterpreted() throws {
        let s = """
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,keep {\\pos(10,10)} this {\\fad(0,0)\\b1} text
        """
        let d = try parse(s)
        XCTAssertEqual(d.cues.count, 1)
        XCTAssertEqual(d.cues[0].text, "keep  this  text")
        XCTAssertEqual(d.unsupportedOverrides.count, 1)
        XCTAssertEqual(d.unsupportedOverrides[0].cueIndex, 1)
        XCTAssertEqual(d.unsupportedOverrides[0].tags, ["\\b", "\\fad", "\\pos"])
    }

    func testDrawingOnlyBlockReportsAsBlock() throws {
        let s = """
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,art {m 0 0 l 5 5} shown
        """
        let d = try parse(s)
        XCTAssertEqual(d.unsupportedOverrides.first?.tags, ["block"])
        XCTAssertEqual(d.cues[0].text, "art  shown")
    }

    func testUnterminatedOverrideBlockIsReported() throws {
        let s = """
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,visible {\\pos(1,1)
        """
        let d = try parse(s)
        XCTAssertEqual(d.cues[0].text, "visible")
        XCTAssertEqual(d.unsupportedOverrides.first?.tags, ["\\pos"])
    }

    // MARK: escape handling

    func testEscapes() throws {
        let s = """
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,a\\Nb\\nc\\hd
        """
        let d = try parse(s)
        XCTAssertEqual(d.cues[0].lines, ["a", "b", "c\u{00A0}d"])
        XCTAssertEqual(d.cues[0].text, "a\nb\nc\u{00A0}d")
    }

    // MARK: structural refusals

    func testMissingEventsSectionRefuses() {
        XCTAssertEqual(refusal("[Script Info]\nPlayResX: 1\n"), .missingEventsSection)
    }

    func testDialogueBeforeFormatRefuses() {
        let s = """
        [Events]
        Dialogue: 0:00:01.00,0:00:02.00,ok
        """
        XCTAssertEqual(refusal(s), .dialogueBeforeFormat(line: 2))
    }

    func testEventsFormatWithoutRequiredFieldsRefuses() {
        let s = """
        [Events]
        Format: Start, Text
        """
        XCTAssertEqual(refusal(s), .missingEventsFormat(line: 2))
    }

    func testEmptyTextFieldRefuses() {
        let s = """
        [Events]
        Format: Start, End, Text
        Dialogue: 0:00:01.00,0:00:02.00,
        """
        XCTAssertEqual(refusal(s), .missingText(line: 3))
    }

    // MARK: robustness

    func testBOMAndCRLFAreNormalized() throws {
        let crlf = "\u{FEFF}" + v4Doc.replacingOccurrences(of: "\n", with: "\r\n")
        let d = try parse(crlf)
        XCTAssertEqual(d.styles.count, 2)
        XCTAssertEqual(d.cues.count, 2)
    }

    func testBothStyleSectionsCoexist() throws {
        let both = v4Doc + "\n" + """
        [V4+ Styles]
        Format: Name, Fontname, Fontsize, PrimaryColour
        Style: Plus,Arial,30,&H00000001
        """
        let d = try parse(both)
        XCTAssertEqual(d.styles.map { $0.name }, ["Default", "Alt", "Plus"])
    }

    func testSubtitleCueIntervalSemantics() {
        let c = SubtitleCue(index: 1, startSeconds: 2, endSeconds: 4, lines: ["x"])
        XCTAssertFalse(c.contains(seconds: 1.999))
        XCTAssertTrue(c.contains(seconds: 2))
        XCTAssertTrue(c.contains(seconds: 3.999))
        XCTAssertFalse(c.contains(seconds: 4)) // half-open
        let inverted = SubtitleCue(index: 2, startSeconds: 4, endSeconds: 2, lines: ["y"])
        XCTAssertFalse(inverted.contains(seconds: 3))
    }
}
