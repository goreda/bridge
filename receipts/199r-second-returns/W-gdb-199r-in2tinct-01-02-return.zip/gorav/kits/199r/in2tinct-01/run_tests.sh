#!/bin/sh
# Runner for W-gdb-199r-in2tinct-01. Verifies staged sources are byte-identical
# to the gorav production paths before running swift test.
set -e
KIT="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$KIT/../../.." && pwd)"
for rel in Sources/GorAVSubtitles/ASSParser.swift Sources/GorAVSubtitles/SubtitleCue.swift; do
    PROD="$ROOT/$rel"
    STAGED="$KIT/$rel"
    for f in "$PROD" "$STAGED"; do
        [ -f "$f" ] || { echo "MISSING: $f" >&2; exit 2; }
    done
    hp=$(sha256sum "$PROD" | awk '{print $1}')
    hs=$(sha256sum "$STAGED" | awk '{print $1}')
    echo "production $hp  $PROD"
    echo "staged     $hs  $STAGED"
    [ "$hp" = "$hs" ] || { echo "BYTE-INEQUALITY on $rel: staged copy diverges from production; refusing to test" >&2; exit 3; }
done
echo "byte equality verified for all staged production files"
swift --version
swift test --package-path "$KIT" 2>&1
echo "swift test exit: $?"
