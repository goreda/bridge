// swift-tools-version:6.0
import PackageDescription

// Isolated test package for W-gdb-199r-in2tinct-01 (SUBTITLE-FORMATS, SSA V4).
// Builds the actual production sources staged under Sources/; the runner
// (run_tests.sh) verifies byte equality of every staged file against its
// gorav production path before any build. No reimplementation exists here.
let package = Package(
    name: "in2tinct-01-assparser-v4",
    targets: [
        .target(name: "GorAVSubtitles", path: "Sources/GorAVSubtitles"),
        .testTarget(
            name: "ASSParserV4Tests",
            dependencies: ["GorAVSubtitles"],
            path: "Tests/ASSParserV4Tests"
        ),
    ]
)
