# W-gdb-199r in2tinct-01 / in2tinct-02 — lab return

Bridge tip 936bde30cc520cadb34fe4ccc84ff71f2268922f; gorav main pin cf3e3f1772033dbc8465b19689e93f53c60006ce.
Claim: internal 10:36:15 UTC; public H-0682 published 10:39:13 UTC, lease to 12:39:13 UTC.
Environment: Linux x86_64, Swift 6.0.3 (swift-6.0.3-RELEASE, ubuntu22.04). All results below are Linux SwiftPM `swift test` executions. SUPPORT status only: no Darwin wiring, no native/UI/playback/owner-Mac claim, no production-ref or billing change. goreda/gorav is not readable by this lab (HTTP 404), so the packet-sanctioned byte-verified source-copy staging was used: each kit's run_tests.sh sha256-verifies every staged file against the gorav production path and refuses to build on divergence (exit 3). Patch applicability was verified with `git apply --check` against a pristine pinned baseline, and applying both patches reproduces the delivered hashes exactly.

## in2tinct-01 — SUBTITLE-FORMATS: SSA V4 styles

Finding: the pinned production ASSParser already reads SSA [V4 Styles]. The section switch routes "v4 styles" and "v4+ styles" through the same Format-driven Style parsing; parseStyle resolves name/fontname/fontsize/primarycolour by explicit Format column index; parseColour decodes &HAABBGGRR and &HBBGGRR to AARRGGBB with strict 6/8-hex length and digit checks; malformed Style rows are skipped on record (cosmetic) while malformed Dialogue rows refuse (content); override blocks are reported as unsupported and stripped, never interpreted.

Production change in this return: header doc-comment correction only (4c16b99f... -> 31b45ecd...). The comment claimed "[V4+ Styles]" while the code accepts both V4 and V4+; the comment now says so. This is a documentation correction, not a runtime behavior change, and it is not presented as one.

ACCEPTANCE CAVEAT (explicit): the packet requires "at least one real production change ... test-only models do not count." Test-driven baseline verification (26 semantic tests, all packet-listed cases) exposed no genuine in-scope defect: V4 reading is already complete at the pin. The behavioral production-change requirement is therefore UNSATISFIED by this return unless the integrator accepts the doc correction plus regression kit as scope-complete. We did not invent redundant parser edits or a no-Format default-order fallback (out of the packet's "Format/Style rows" wording; flagged in qualification, declined by main).

Tests (26, 0 failures, exit 0 — identical on pinned bytes 4c16b99f and on corrected bytes 31b45ecd; logs in2tinct-01-baseline.log and in2tinct-01-final.log):
V4 style parse into Style model incl. colour 0x&H11223344->0x11443322; V4 cues with style association and embedded-comma text; V4+ unchanged incl. Comment-row skip; explicit reordered Format columns honored (styles and events; missing Style field -> nil association); style field-count/missing-column/no-Format skips on record; dialogue field-count refusal; malformed timestamp matrix (8 shapes) and end<=start refusals; cosmetic-style-vs-content-refusal asymmetry; colour conversion matrix (8/6-digit, case, bad lengths/chars/prefix refuse) and bad-colour skip-not-refuse; override-only refusal; override blocks reported+stripped (tags sorted), drawing-only block as "block", unterminated block reported; \N \n \h escapes; missing-Events/dialogue-before-Format/missing-Events-Format/empty-text refusals; BOM+CRLF normalization; V4+V4 sections coexisting; SubtitleCue half-open interval semantics.

## in2tinct-02 — TRANSPORT-EXTENDED: chapter navigation

Production change: new file Sources/GorAVPlaybackCore/ChapterNavigation.swift as an EXACT byte-identical port of the supplied delivered82 reference (cca7eafbe8bfae8bf5b87b4e0d751f963c65b77ca487f4390c4fe31452c1614a), the packet's "exact chapter API port plus semantic tests" path. Public type names, signatures and refusal semantics preserved: ChapterDirection, ChapterNavigationEntry, ChapterNavigationRefusal (unavailable/invalidInventory/unknownPosition/boundary), ChapterNavigation.target(entries:position:direction:). Playlist and A-B excluded per packet.

Tests (29, 0 failures, exit 0; log in2tinct-02-swifttest.log): next/previous from middle; exact-start boundary attribution; before-first next -> first entry; boundary without wrap both directions incl. single-entry; position zero/-0.0/nil/NaN/+inf/-inf/negative; empty inventory; duplicate indices; nonmonotonic and equal starts; end<start; negative start; nonfinite entry times; negative index; sparse stable indices preserved (3,7,42); overflow before millisecond conversion refused (Double(Int64.max) and the Double(Int64.max/1000) round-up case); large representable start (1e15 s) validates then hits boundary.

Authoring note: two initial test expectations were wrong against the reference semantics (position -0.0 equals 0 so chapter-at-0 is current; Double rounding makes Int64.max/1000 overflow) — corrected in the tests; production bytes never changed (exact port maintained throughout).

## Contents
- gorav/Sources/... — production files (01 corrected comment, 01 unchanged SubtitleCue for kit completeness, 02 exact port)
- gorav/kits/199r/in2tinct-01, in2tinct-02 — SwiftPM test packages (Package.swift, run_tests.sh byte-equality runner, staged Sources, Tests); build output excluded via .gitignore
- patches/199r-in2tinct-01.patch, 199r-in2tinct-02.patch — git diffs against the pin; both `git apply --check` clean on a pristine pinned baseline
- logs/ — full runner output incl. exact command, compiler version, byte-equality lines, per-test results, exit status
- SHA256SUMS — every returned file

Integrator path per packet: gdb/goreda runs `swift test` (or kits/.../run_tests.sh) within 2h of return; PASS merges to a gorav lane branch, FAIL returns with exact output.
