# VERIFY — W-gdb-199r-1nstinct-02 CACHE, revision r1 (Review 6.1.2 corrections)
# SUPPORT only, no acceptance claims. Synthetic Linux, clean_checkout:false,
# packet-baseline only.

Toolchain actually used: Swift version 6.0.3 (swift-6.0.3-RELEASE), Target:
x86_64-unknown-linux-gnu. One writer per production file; ArchiveItemSource.swift
untouched (byte-identical to the supplied pin baseline, sha b3ceab52...).

PIN STATEMENT: my packet baseline is the supplied pin cf3e3f1772033dbc8465b19689e93f53c60006ce
with the packet-shipped baseline bytes. The requester's current main is reported as
f8bcd542c1ff15e6494ce95fc94389c2e0021e96 (unverified by parent) — this DIFFERS from my
packet baseline. Both pins remain publicly unfetchable here (GitHub 404 / clone refused),
so I cannot verify either; the patch adds new files only and conflicts with neither.
Still-missing input: read access to goreda/gorav at either ref.

CORRECTION 1 — instance-bound tokens (Review 6.1.2 finding 1):
- CacheToken now carries (instance, generation, id); every CacheAccounting instance gets a
  unique instanceID from a locked process counter. commit/release refuse a foreign token
  with typed CacheAccountingError.foreignInstance BEFORE any state lookup, so a token from
  instance A can never release or commit B's reservation.
- RED-before evidence (old bytes, compile_exit=0, semantic_exit=1):
  logs/199r-02r-RED-cross-instance.log — cross-instance regression written against the
  previously returned API fails: "did not throw error" and B's accountedBytes corrupted
  to 0 (the exact reported alias reproduced on my old bytes).
- GREEN-after: testCrossInstanceTokenRefused passes — foreign release/commit refused
  typed, B's accounting untouched, A's token still valid on A.

CORRECTION 2 — explicit reset-generation exhaustion (Review 6.1.2 finding 2):
- reset() is now throwing: at generation == UInt64.max it refuses with
  CacheAccountingError.overflow and leaves ALL state unchanged (no silent wrap; the
  pre-correction bytes used `generation &+ 1`, which wrapped silently by construction —
  that mechanism is the finding, cited from the returned old file).
- GREEN-after: testResetGenerationExhaustionRefused (via the internal
  @testable-only init(capacity:generation:) seam) — refused reset keeps generation,
  counters and live tokens; the live token still releases afterwards.

Full GREEN suite: 12/12 XCTest both modes.
  swift test --package-path kits/199r/1nstinct-02          -> exit 0 (debug, 12/12)
  swift test -c release --package-path kits/199r/1nstinct-02 -> exit 0 (release, 12/12)
  compile_exit=0 and semantic_exit=0 reported separately in the logs; verify-pinned gate
  PIN_BYTES_MATCH ran before each build.
Coverage: reserve->commit->release; failure atomicity; over-capacity at bound; UInt64.max
boundary; double release/commit; unknown token; cross-instance refusal; reset
invalidation; reset exhaustion; zero size; identifier boundary; deterministic replay.

Negative controls (mutants over the revised staged copy, each must fail):
  M1 capacity check removed      -> exit 1 (atomicity/over-capacity tests fail)
  M2 double release accepted     -> exit 1 (double-release test fails)
  M3 reset keeps generation      -> exit 1 (stale-generation + replay tests fail)
  M4 cross-instance accepted     -> exit 1 (cross-instance test fails)
  Restore: verify-pinned PASS + final green run (logs/199r-02r-restored-final.log).

Revised production file:
  Sources/GorAVPlaybackCore/CacheAccounting.swift sha256
  ef6b7c40a632024617c378f93ffa0cac2728362635eff0b71c957685494f6438
Patch against the packet pin baseline (new files only; apply-check verified; post-apply
byte-match): 199r-1nstinct-02-r1.patch sha256
  dd1b35b8d16af0a773022d2f71257f76df8708da985681ebb2082e27dbe2e1e6
The r1 patch supersedes the first return's patch; it targets the same baseline (new files
only), not the first return's bytes.

NOT_RUN: Darwin/macOS, owner Mac, UI, playback, live cache wiring, eviction, mpv,
integration, pre-existing portable tests (none exist in the pinned material).

Contents: VERIFY-r1.md, 199r-1nstinct-02-r1.patch, SHA256-MANIFEST-r1.txt, files-r1/
(full tree), logs/ (RED, GREEN debug+release, 4 mutant runs, restored final).
