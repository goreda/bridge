import Foundation
// Publisher concern 2 repro: reset() uses wrapping addition (generation &+ 1).
// Claim under test: "old tokens stay stale forever". Simulate a full UInt64 wrap.
let acct = CacheAccounting(capacity: 1024)
do {
    let old = try acct.reserve(identifier: "old-item", bytes: 100)   // minted in epoch 0
    acct.generation = UInt64.max   // INSTRUMENTED: stands in for 2^64-1 reset() calls
    acct.reset()                   // wraps generation to 0; clears tokens and nextTokenID
    print("after wrap: generation=\(acct.generation)")
    let new = try acct.reserve(identifier: "new-item", bytes: 400)   // epoch 0 again, id 0 reused
    print("old=\(old) new=\(new) equal=\(old == new)")
    try acct.release(old)          // pre-wrap token presented after the wrap
    print("WRAP_REPRODUCED: pre-wrap token accepted after generation wrap; reservedBytes=\(acct.reservedBytes) (new token's 400 drained by old token)")
    print("new token state now tombstoned; releasing new throws:")
    do { try acct.release(new); print("unexpected: new released too") } catch { print("  release(new) -> \(error)") }
    exit(1) // nonzero = concern reproduces
} catch {
    print("REFUSED: \(error) -> concern does NOT reproduce")
    exit(0)
}
