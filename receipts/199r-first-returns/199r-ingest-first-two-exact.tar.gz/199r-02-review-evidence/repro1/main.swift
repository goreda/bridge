import Foundation
// Publisher concern 1 repro: CacheToken = (generation, id) only, no instance identity.
// Two CacheAccounting instances with equal counters: does instance B accept A's token?
let a = CacheAccounting(capacity: 1024)
let b = CacheAccounting(capacity: 1024)
do {
    let tokA = try a.reserve(identifier: "item-a", bytes: 100)
    let tokB = try b.reserve(identifier: "item-b", bytes: 200)
    print("tokA=\(tokA) tokB=\(tokB)  equal=\(tokA == tokB)")
    // Present A's token to instance B for release:
    try b.release(tokA)
    print("ALIAS_REPRODUCED: instance B accepted and released instance A's token; b.reservedBytes=\(b.reservedBytes) (expected 200 if B had refused)")
    // B's own token still accounted, but its bytes were partially drained by the foreign token:
    print("b.accountedBytes=\(b.accountedBytes) a.accountedBytes=\(a.accountedBytes)")
    exit(1) // nonzero = concern reproduces
} catch {
    print("REFUSED: \(error) -> concern does NOT reproduce")
    exit(0)
}
