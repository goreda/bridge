# VERIFY-199r-01 — W-gdb-199r-1nstinct-01 MULTIAUDIO (lab 1nstinct, SUPPORT)

Product: goreda/gorav main pin cf3e3f1772033dbc8465b19689e93f53c60006ce.
Owned paths only: Sources/GorAVPlaybackCore/AudioTrackPlan.swift + kits/199r/1nstinct-01/. No shared root
Package.swift edits. No other packet's production path touched (1nstinct-02 CacheAccounting.swift untouched).

## Pin provenance (blocker check)
Public repo lookup FAILED, as the parent saw: api.github.com/repos/goreda/gorav -> 404,
raw.githubusercontent.com at the pin -> 404, git ls-remote requires credentials (private or absent).
The pin could NOT be independently cloned. Work proceeded on the packet-supplied baseline bytes under
1nstinct-01/pinned/, verified byte-exact against 1nstinct-01/SHA256.json
(24d8e9f53b044811f39268299767fad5a2bf788982133439138f5269c5678c31 — matches). The owned file is
self-contained (defines AudioTrackInfo/AudioTrackSelector/AudioTrackRefusal/AudioTrackPlan/AudioDelay),
so no further repo inputs were required. Existing portable test packages: none supplied and the repo is
unreachable — existing-test run NOT_RUN, blocker named, no pass claimed.

## Production change (real, additive; patch against the pin)
- New typed refusal AudioTrackRefusal.duplicateIndex(Int): a duplicate container stream index in the
  inventory is refused loudly before any selector runs (was: silent arbitrary pick).
- New resolver AudioTrackPlan.selectPreferred(_ preferences: [String], from:): ordered language
  preferences (case-insensitive, first matching track in inventory order), a missing preference advances
  to the next, exhausted preferences resolve exactly like the current auto policy, empty list is pure auto.
- select() validates duplicate indices first, then applies the unchanged auto/index/language logic.
- Preserved byte-semantic: existing selectors and all three existing refusal cases, exact-index-never-
  falls-back, AudioDelay replace-not-accumulate semantics and 600s limit, AudioTrackInfo failable init.

## Execution (Linux, synthetic, clean_checkout:false, SUPPORT only)
Compiler: Swift version 6.0.3 (swift-6.0.3-RELEASE), Target: x86_64-unknown-linux-gnu.
Commands (full log: logs/199r-01-swift-test.log):
  swift --version
  kits/199r/1nstinct-01/stage.sh      -> STAGED byte-identical sha256=f8b7d8d1... (production -> package copy verified BEFORE build)
  swift test --package-path kits/199r/1nstinct-01
  -> swift_test_exit=0, swift-testing 6.0.3, 11/11 tests passed:
     stagedBytesMatchProduction (in-test byte re-verification vs the production file), noAudioRefused,
     existingSelectorsPreserved, exactIndexNeverFallsBack, duplicateIndicesRefusedTyped,
     preferenceOrderThenAuto, preferenceMatchingCaseInsensitiveAndFirstInInventoryOrder,
     multipleDefaultsDeterministicFirstFlag, repeatabilityDeterminism (50 iterations),
     audioDelayReplacementSemantics, invalidIndexImpossibleAtConstruction.
Coverage vs packet list: no-audio / sparse indices / case-insensitive language / multiple defaults /
duplicate indices / exact-index absent / determinism / delay replacement — all executed.

## NOT_RUN / labels
Linux SUPPORT only. No Darwin, UI, playback, mpv, native slot, owner-Mac or acceptance claims. No gor host
edits, no production refs, no billing changes. Repo fetch blocked (404, above) — no claim about repo state
beyond the supplied pinned bytes.
