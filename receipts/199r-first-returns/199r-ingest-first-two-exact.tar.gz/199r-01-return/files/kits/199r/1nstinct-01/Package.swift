// swift-tools-version: 6.0
import PackageDescription

// W-gdb-199r-1nstinct-01 MULTIAUDIO: isolated Linux test package. Builds the
// byte-staged copy of the real production file Sources/GorAVPlaybackCore/
// AudioTrackPlan.swift (staged by stage.sh, byte-equality re-verified by the
// StagedBytesMatchProduction test). No reimplemented models.
let package = Package(
    name: "199r-1nstinct-01",
    targets: [
        .target(name: "AudioTrackPlan", path: "Sources/AudioTrackPlan"),
        .testTarget(name: "AudioTrackPlanTests", dependencies: ["AudioTrackPlan"], path: "Tests/AudioTrackPlanTests"),
    ]
)
