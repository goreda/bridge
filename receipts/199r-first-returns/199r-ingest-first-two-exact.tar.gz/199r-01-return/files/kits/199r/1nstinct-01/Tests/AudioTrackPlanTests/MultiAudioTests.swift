import Foundation
import Testing
@testable import AudioTrackPlan

// W-gdb-199r-1nstinct-01 MULTIAUDIO semantic tests (Linux, Swift 6.0.3).
// Runs against the byte-staged copy of the real production file.

private func t(_ index: Int, _ language: String? = nil, title: String? = nil, d: Bool = false) -> AudioTrackInfo {
    AudioTrackInfo(index: index, language: language, title: title, isDefault: d)!
}

@Test func stagedBytesMatchProduction() throws {
    // The staged copy under test must be byte-identical to the production file.
    let here = URL(fileURLWithPath: #filePath)   // .../kits/199r/1nstinct-01/Tests/AudioTrackPlanTests/MultiAudioTests.swift
    let kit = here.deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
    let root = kit.deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
    let prod = root.appendingPathComponent("Sources/GorAVPlaybackCore/AudioTrackPlan.swift")
    let staged = kit.appendingPathComponent("Sources/AudioTrackPlan/AudioTrackPlan.swift")
    let a = try Data(contentsOf: prod), b = try Data(contentsOf: staged)
    #expect(a == b, "staged copy drifted from production; re-run stage.sh")
}

@Test func noAudioRefused() {
    #expect(AudioTrackPlan.select(.auto, from: []) == .failure(.noAudioTracks))
    #expect(AudioTrackPlan.select(.index(1), from: []) == .failure(.noAudioTracks))
    #expect(AudioTrackPlan.select(.language("eng"), from: []) == .failure(.noAudioTracks))
    #expect(AudioTrackPlan.selectPreferred(["eng"], from: []) == .failure(.noAudioTracks))
    #expect(AudioTrackPlan.selectPreferred([], from: []) == .failure(.noAudioTracks))
}

@Test func existingSelectorsPreserved() {
    let tracks = [t(1, "eng"), t(4, "tur", d: true), t(9, "jpn")]
    // auto: default flag first
    #expect(AudioTrackPlan.select(.auto, from: tracks) == .success(tracks[1]))
    // auto without any default: lowest stream index (sparse indices kept)
    #expect(AudioTrackPlan.select(.auto, from: [t(4, "tur"), t(9, "jpn")]) == .success(t(4, "tur")))
    // exact index honored
    #expect(AudioTrackPlan.select(.index(9), from: tracks) == .success(tracks[2]))
    // exact language, case-insensitive
    #expect(AudioTrackPlan.select(.language("TUR"), from: tracks) == .success(tracks[1]))
    // absent language refuses
    #expect(AudioTrackPlan.select(.language("fra"), from: tracks) == .failure(.requestedLanguageAbsent("fra")))
}

@Test func exactIndexNeverFallsBack() {
    let tracks = [t(1, "eng"), t(4, "tur", d: true)]
    #expect(AudioTrackPlan.select(.index(7), from: tracks) == .failure(.requestedIndexAbsent(7)))
    // a default flag must not rescue an absent exact index
    #expect(AudioTrackPlan.select(.index(4), from: tracks) == .success(tracks[1]))
    #expect(AudioTrackPlan.select(.index(0), from: tracks) == .failure(.requestedIndexAbsent(0)))
}

@Test func duplicateIndicesRefusedTyped() {
    let dup = [t(2, "eng"), t(2, "tur"), t(5, "jpn")]
    #expect(AudioTrackPlan.select(.auto, from: dup) == .failure(.duplicateIndex(2)))
    #expect(AudioTrackPlan.select(.index(2), from: dup) == .failure(.duplicateIndex(2)))
    #expect(AudioTrackPlan.select(.index(5), from: dup) == .failure(.duplicateIndex(2)))
    #expect(AudioTrackPlan.select(.language("jpn"), from: dup) == .failure(.duplicateIndex(2)))
    #expect(AudioTrackPlan.selectPreferred(["jpn"], from: dup) == .failure(.duplicateIndex(2)))
    // the refusal is typed and loud, not an arbitrary pick of the first duplicate
    #expect(AudioTrackRefusal.duplicateIndex(2).description == "duplicateIndex(2)")
}

@Test func preferenceOrderThenAuto() {
    let tracks = [t(1, "eng"), t(4, "tur", d: true), t(9, "jpn")]
    // first matching preference wins
    #expect(AudioTrackPlan.selectPreferred(["tur", "eng"], from: tracks) == .success(tracks[1]))
    #expect(AudioTrackPlan.selectPreferred(["eng", "tur"], from: tracks) == .success(tracks[0]))
    // a missing preference advances to the next one
    #expect(AudioTrackPlan.selectPreferred(["fra", "jpn", "eng"], from: tracks) == .success(tracks[2]))
    // exhausted preferences fall back to the current auto policy (default flag)
    #expect(AudioTrackPlan.selectPreferred(["fra", "deu"], from: tracks) == .success(tracks[1]))
    // exhausted preferences, no default flag: lowest stream index
    #expect(AudioTrackPlan.selectPreferred(["fra"], from: [t(9, "jpn"), t(4, "tur")]) == .success(t(4, "tur")))
    // empty preference list is pure auto
    #expect(AudioTrackPlan.selectPreferred([], from: tracks) == .success(tracks[1]))
}

@Test func preferenceMatchingCaseInsensitiveAndFirstInInventoryOrder() {
    let tracks = [t(3, "ENG"), t(7, "eng", d: true)]
    #expect(AudioTrackPlan.selectPreferred(["eng"], from: tracks) == .success(tracks[0]))
    #expect(AudioTrackPlan.selectPreferred(["eNg"], from: tracks) == .success(tracks[0]))
    // tracks with no language never match a preference but stay reachable via auto
    let sparse = [t(2, nil), t(8, "tur")]
    #expect(AudioTrackPlan.selectPreferred(["eng"], from: sparse) == .success(sparse[0]))
}

@Test func multipleDefaultsDeterministicFirstFlag() {
    let tracks = [t(5, "eng", d: true), t(2, "tur", d: true)]
    // existing behavior preserved: first default flag in inventory order, not lowest index
    #expect(AudioTrackPlan.select(.auto, from: tracks) == .success(tracks[0]))
    #expect(AudioTrackPlan.selectPreferred(["fra"], from: tracks) == .success(tracks[0]))
}

@Test func repeatabilityDeterminism() {
    let tracks = [t(1, "eng"), t(4, "tur", d: true), t(9, "jpn")]
    let prefs = ["fra", "jpn", "tur"]
    let first = AudioTrackPlan.selectPreferred(prefs, from: tracks)
    for _ in 0..<50 {
        #expect(AudioTrackPlan.selectPreferred(prefs, from: tracks) == first)
        #expect(AudioTrackPlan.select(.auto, from: tracks) == .success(tracks[1]))
    }
    #expect(first == .success(tracks[2]))
}

@Test func audioDelayReplacementSemantics() {
    // setting REPLACES the value; it never accumulates (mpv audio-delay convention)
    var d = AudioDelay(1.5)
    #expect(d?.seconds == 1.5)
    d = AudioDelay(-0.25)
    #expect(d?.seconds == -0.25)
    #expect(AudioDelay(600.0)?.seconds == 600.0)
    #expect(AudioDelay(-600.0)?.seconds == -600.0)
    #expect(AudioDelay(600.1) == nil)
    #expect(AudioDelay(.nan) == nil)
    #expect(AudioDelay(.infinity) == nil)
    #expect(AudioDelay.limitSeconds == 600.0)
}

@Test func invalidIndexImpossibleAtConstruction() {
    // negative container indices are refused at the failable initializer,
    // so no AudioTrackInfo can carry an invalid index into selection
    #expect(AudioTrackInfo(index: -1, language: "eng", title: nil, isDefault: false) == nil)
    #expect(AudioTrackInfo(index: 0, language: nil, title: nil, isDefault: false) != nil)
}
