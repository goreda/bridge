#!/bin/sh
# W-gdb-199r-1nstinct-01 staging runner: copies the REAL production file into
# this package and verifies byte equality BEFORE any build. Fails loudly.
set -e
KIT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$KIT/../../.." && pwd)
PROD="$ROOT/Sources/GorAVPlaybackCore/AudioTrackPlan.swift"
DEST="$KIT/Sources/AudioTrackPlan/AudioTrackPlan.swift"
[ -f "$PROD" ] || { echo "STAGE_FAIL missing production file: $PROD" >&2; exit 1; }
cp "$PROD" "$DEST"
A=$(sha256sum "$PROD" | cut -d' ' -f1)
B=$(sha256sum "$DEST" | cut -d' ' -f1)
[ "$A" = "$B" ] || { echo "STAGE_FAIL byte mismatch $A != $B" >&2; exit 1; }
echo "STAGED byte-identical sha256=$B"
