# VERIFY — W-gdb-199r-1nstinct-02 CACHE (SUPPORT only, no acceptance claims)

Pin: goreda/gorav main cf3e3f1772033dbc8465b19689e93f53c60006ce.
PIN FETCH BLOCKER (named input missing, not worked around silently): the pin is not
publicly fetchable — GitHub API and web fetches for goreda/gorav return 404/CRAWL_NOT_FOUND
and unauthenticated git clone fails (repository not found without credentials). No full
checkout of the pinned repo exists here. Mitigation within the packet's own rules: the
packet supplies the pinned baseline bytes (pinned/Sources/GorAVPlaybackCore/
ArchiveItemSource.swift, sha256 b3ceab524aed7067e6744c6885cf14f343cf52b09300bb87e6a676ae4c5781bd,
matches SHA256.json) and this packet's only source dependency is that one file. The patch
adds new files only and modifies no existing bytes, so it applies to the true pin tree
without conflict. If the integrator needs the patch produced inside a real checkout, the
missing input is read access to goreda/gorav at the pin (or a tarball of it).

Toolchain actually used: Swift version 6.0.3 (swift-6.0.3-RELEASE), Target:
x86_64-unknown-linux-gnu. Synthetic Linux, clean_checkout:false, SUPPORT only.
No Darwin/UI/playback/live-cache claims. No I/O, no eviction in the accounting type.

Production change (real, new file — packet requires at least one real production change):
- Sources/GorAVPlaybackCore/CacheAccounting.swift sha256
  0ed9b572793e868db6638c908e46c687cfe4af7a4f29eb5ef91838ce505f613c
  Generation-scoped reserve/commit/release over UInt64 with checked arithmetic;
  capacity bound; typed refusals: staleGeneration(expected:found:), duplicateToken(id:),
  unknownToken(id:), overflow, underflow, invalidIdentifier. Tokens carry (generation, id)
  and prevent double release/double commit; reset() invalidates the prior generation and
  releases all accounted bytes. No eviction, no I/O, no live cache wiring.
Boundary: archive/source identifiers enter ONLY through
CacheAccounting.validatedIdentifier, which delegates to the pinned
ArchiveItemSource.identifier and maps its refusal to .invalidIdentifier. No identifier
rules re-implemented. No extra source dependency: the packet-listed ArchiveItemSource.swift
is the only production file referenced (compiled into the test target from staged bytes,
byte-equality-gated by tools/verify-pinned.sh).

Test/package (owned paths only; no shared root Package.swift edit):
- kits/199r/1nstinct-02/Package.swift (isolated SwiftPM package)
- kits/199r/1nstinct-02/tools/verify-pinned.sh (PIN_BYTES_MATCH gate, runs before build)
- kits/199r/1nstinct-02/Sources/GorAVPlaybackCore/*.swift (byte-identical staged copies)
- kits/199r/1nstinct-02/Tests/GorAVPlaybackCoreTests/CacheAccountingTests.swift
  10 XCTest cases: reserve->commit->release; failure atomicity of a refused reserve
  (counters and nextTokenID unchanged); over-capacity exactly at the bound; UInt64.max
  boundary (no wrap to zero); double release and double commit refusals; unknown token;
  reset invalidation (staleGeneration with expected/found); zero-size refusal;
  identifier boundary (bad/".." refused, good admitted); deterministic replay
  (two runs produce identical token ids/counters).

Executed commands (full logs in logs/):
  swift --version
  kits/199r/1nstinct-02/tools/verify-pinned.sh        -> PIN_BYTES_MATCH, exit 0
  swift test --package-path kits/199r/1nstinct-02     -> 10/10 passed, exit 0 (debug)
  swift test -c release --package-path kits/199r/1nstinct-02 -> 10/10 passed, exit 0
Negative controls (mutants over the staged production copy, tests must fail):
  M1 capacity check removed        -> exit 1 (over-capacity + UInt64 boundary tests fail)
  M2 double release accepted       -> exit 1 (double-release test fails)
  M3 reset keeps generation        -> exit 1 (stale-generation + replay tests fail)
  Restore: verify-pinned PASS, swift test green again (logs/199r-02-restored-final.log).
Existing portable tests: the pinned tree available here contains no pre-existing test
package (only the supplied baseline source), so there were none to run; recorded as
NOT_RUN rather than passed. Build output (.build) excluded from the return tree.

Patch against the pin (new files only; git apply --check verified; post-apply tree
byte-matches the tested tree):
  199r-1nstinct-02.patch sha256 d5c459de5848300ba33c95846dfe0bce2bc248b93f6c6c292b9c0cfa3d817954

NOT_RUN: Darwin/macOS, owner Mac, UI, playback, live cache wiring, eviction, mpv, any
integration. This is support accounting only.

Contents: VERIFY.md, 199r-1nstinct-02.patch, SHA256-MANIFEST.txt, files/ (full tree:
production + kit), logs/ (swift test debug+release, 3 mutant runs, restored final run).
