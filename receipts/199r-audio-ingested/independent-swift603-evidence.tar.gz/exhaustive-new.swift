import GorAVPlaybackCore
func show(_ value:AudioTrackRefusal)->String {
 switch value {
 case .duplicateIndex:return "duplicate"
 case .noAudioTracks:return "empty"
 case .requestedIndexAbsent:return "index"
 case .requestedLanguageAbsent:return "language"
 }
}
