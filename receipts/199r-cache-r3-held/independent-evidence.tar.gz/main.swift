// STRICT semantic harness (not XCTest): exercises r3 production semantics compiled
// under -swift-version 6 -strict-concurrency=complete. The full-package strict
// swift test run is blocked by SwiftPM's Linux XCTest discovery codegen, so the
// semantic strict signal comes from this harness over the same production bytes.
import Foundation

var failures = 0
@MainActor func check(_ ok: Bool, _ label: String) { print((ok ? "PASS " : "FAIL ") + label); if !ok { failures += 1 } }

// own-token lifecycle
do {
    let acct = CacheAccounting(capacity: 1024)
    let t = try acct.reserve(identifier: "h-item", bytes: 100)
    try acct.commit(t)
    try acct.release(t)
    check(acct.accountedBytes == 0, "own-token reserve/commit/release")
} catch { check(false, "own-token reserve/commit/release threw") }

// cross-instance refusal before state mutation
do {
    let a = CacheAccounting(capacity: 1000)
    let b = CacheAccounting(capacity: 1000)
    let tokA = try a.reserve(identifier: "a-item", bytes: 100)
    _ = try b.reserve(identifier: "b-item", bytes: 200)
    do {
        try b.release(tokA)
        check(false, "B.release(A.token) refused")
    } catch let e as CacheAccountingError {
        check(e == .foreignInstance, "B.release(A.token) refused typed foreignInstance")
    } catch { check(false, "B.release(A.token) refused typed foreignInstance") }
    do {
        try b.commit(tokA)
        check(false, "B.commit(A.token) refused")
    } catch let e as CacheAccountingError {
        check(e == .foreignInstance, "B.commit(A.token) refused typed foreignInstance")
    } catch { check(false, "B.commit(A.token) refused typed foreignInstance") }
    check(b.accountedBytes == 200 && a.accountedBytes == 100, "foreign refusal mutated no counters")
} catch { check(false, "cross-instance setup threw") }

// instance counter exhaustion: fail closed, no trap
do {
    let saved = CacheAccounting.nextInstanceID.withLock { $0 }
    CacheAccounting.nextInstanceID.withLock { $0 = UInt64.max }
    let poisoned = CacheAccounting(capacity: 100)
    CacheAccounting.nextInstanceID.withLock { $0 = saved }
    check(poisoned.isExhausted, "poisoned instance flagged at counter exhaustion")
    do {
        _ = try poisoned.reserve(identifier: "x", bytes: 1)
        check(false, "poisoned reserve refused")
    } catch let e as CacheAccountingError {
        check(e == .overflow && poisoned.accountedBytes == 0 && poisoned.nextTokenID == 0, "poisoned reserve typed overflow, no mutation")
    } catch { check(false, "poisoned reserve typed overflow") }
}

// reset exhaustion: explicit refusal, state unchanged (labeled internal seam)
do {
    let acct = CacheAccounting(capacity: 10, generation: UInt64.max)
    let t = try acct.reserve(identifier: "edge", bytes: 5)
    do {
        try acct.reset()
        check(false, "reset at generation max refused")
    } catch let e as CacheAccountingError {
        check(e == .overflow, "reset exhaustion typed overflow")
    } catch { check(false, "reset exhaustion typed overflow") }
    check(acct.generation == UInt64.max && acct.accountedBytes == 5, "refused reset left state unchanged")
    try acct.release(t)
    check(acct.accountedBytes == 0, "live token still releases after refused reset")
} catch { check(false, "reset-exhaustion setup threw") }

// checked arithmetic at UInt64.max capacity
do {
    let acct = CacheAccounting(capacity: UInt64.max)
    let t = try acct.reserve(identifier: "big", bytes: UInt64.max)
    do {
        _ = try acct.reserve(identifier: "wrap", bytes: 1)
        check(false, "UInt64 wrap reserve refused")
    } catch let e as CacheAccountingError {
        check(e == .overflow, "UInt64 wrap reserve typed overflow")
    } catch { check(false, "UInt64 wrap reserve typed overflow") }
    try acct.release(t)
    check(acct.accountedBytes == 0, "UInt64.max lifecycle exact")
} catch { check(false, "UInt64 boundary setup threw") }

exit(failures == 0 ? 0 : 1)
