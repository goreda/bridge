# wt v22.6 + swap/fallback harness (Linux synthetic, not a Mac result)

Base: goreda/instinct gor/Resources/vendor/wt_server/wt_server.mjs v22.5. Only change: added the magnet-fallback request block (+ version strings). Diff: wt_server_v22.5_to_v22.6.diff

## Harness results (webtorrent 2.8.4, local tracker, 96x256KB fixtures, node 22)
Stage 1 swap race (swap.mjs mimics TorrentManager.streamTorrent: generation coalescing, pkill, reap, 0.3s, spawn; overlap mode = SIGTERM + immediate spawn, no wait):
- swift mode 0,1,2,0 @3s: 4 launched, all exit 0, final stream sha-correct, no leaked procs/tmp/boot stamps, no errors.
- swift mode 8 swaps @0/50/200/600ms: coalesced to 2 launches, final sha-correct, clean.
- overlap mode 8 swaps same gaps: 8 launched, 4 killed by SIGTERM before handlers (boot window), final sha-correct, 0 leaks, 0 errors.
=> No swap race reproduced at node level. Swift-side swap logic (generation guard) read, not executed (no swiftc here).
Stage 2/3 wt side (fb.mjs, thresholds shortened by env for the test; defaults 90s starve / 120s metadata / 60s re-emit):
- no-metadata magnet: REQ:magnet-fallback emitted at 10s, re-emitted at 20s, query built "Some Show s02e07 1080p".
- no-holder (seeder lacks piece 40+, reader waiting): emitted after 8s starvation, reason=no-holder, play=40, re-emit 10s later.
- healthy stream: zero fallback events (metadata threshold raised for the slow local fixture).
Not tested: all-choked classification (code path only), no-peers classification, skip/hard-reset-under-peer-loss rows (covered by earlier v22.5 matrix, not rerun), anything Swift.

## Not done
Swift consumer of REQ:magnet-fallback (TorrentManager stdout parser) + headless search in MagnetBrowserController (search() is panel/throttle-coupled; needs a headless path using providers, rank by seeds, skip current infoHash and .exe rows, pick 2nd-best, call streamTorrent). Not written blind: no compiler available.
Env note: webtorrent 2.8.4 needs uint8-util@2.2.5 (2.3.x crashes arr2hex on string infoHash).
