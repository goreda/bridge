import { spawn } from 'child_process'; import http from 'http'; import fs from 'fs';
const M = JSON.parse(fs.readFileSync('/tmp/w/h/magnets.json'));
const SCRIPT = process.env.WT || '/tmp/w/wt_server/wt_server.mjs';
const which = process.argv[2]; const sleep = ms => new Promise(r => setTimeout(r, ms));
const magnet = which === 'nometa' ? 'magnet:?xt=urn:btih:0123456789abcdef0123456789abcdef01234567&dn=Some.Show.S02E07.1080p.WEB-DL.x265-GRP.mkv' : M[which === 'holder' ? 3 : 0].magnet;
const p = spawn('node', ['--expose-gc', SCRIPT, '2222', magnet], { env: { PATH: process.env.PATH, HOME: '/tmp', NODE_PATH: '/tmp/w/webtorrent-cli/node_modules', GOR_WT_FALLBACK_STARVE_MS: '8000', GOR_WT_FALLBACK_META_MS: process.env.META || '10000', GOR_WT_FALLBACK_REEMIT_MS: '10000' }, stdio: ['pipe', 'pipe', 'pipe'] });
let out = '', stream = null; const t0 = Date.now(); const evs = [];
p.stdout.on('data', d => { out += d; for (const l of String(d).split('\n')) if (l.startsWith('REQ:magnet-fallback')) evs.push([Date.now() - t0, l.slice(0, 400)]); const x = /STREAM:(http:\/\/localhost:\d+)/.exec(out); if (x) stream = x[1]; });
let reads = 0, readBytes = 0;
const tEnd = Date.now() + (which === 'healthy' ? 75000 : 100000);
if (which !== 'nometa') {
  while (!stream && Date.now() < tEnd) await sleep(300);
  if (stream) {
    const start = which === 'holder' ? 12 * 262144 : 0; // piece 48: seeder lacks it
    const rq = http.get(stream, { headers: { Range: `bytes=${start}-` } }, r => { r.on('data', d => { readBytes += d.length; }); r.on('error', () => {}); });
    rq.on('error', () => {});
    while (Date.now() < tEnd) { await sleep(500); if (which === 'healthy' && readBytes >= 96 * 262144) { await sleep(12000); break; } if (which === 'holder' && evs.length >= 2) break; }
  }
} else { while (Date.now() < tEnd && evs.length < 2) await sleep(500); }
p.kill('SIGTERM'); await sleep(1500);
console.log(JSON.stringify({ which, streamAtMs: stream ? 'yes' : 'no', readBytes, events: evs }, null, 1));
process.exit(0);
