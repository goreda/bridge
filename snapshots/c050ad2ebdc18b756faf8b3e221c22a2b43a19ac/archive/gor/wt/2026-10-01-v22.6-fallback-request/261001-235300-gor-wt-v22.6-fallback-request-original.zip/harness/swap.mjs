// swap stress: mimics TorrentManager.streamTorrent (generation coalescing, pkill, reap, 0.3s, spawn)
import { spawn, execSync, spawnSync } from 'child_process';
import http from 'http'; import fs from 'fs'; import crypto from 'crypto';
const M = JSON.parse(fs.readFileSync('/tmp/w/h/magnets.json'));
const SCRIPT = process.env.WT || '/tmp/w/wt_server/wt_server.mjs';
const mode = process.argv[2] || 'swift';       // swift | overlap
const seq = (process.argv[3] || '0,1,2,0').split(',').map(Number);
const gaps = (process.argv[4] || '3000').split(',').map(Number);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let gen = 0, cur = null, curOut = '', curStream = null, all = [];
const pgrepN = () => { try { return execSync("pgrep -f 'node .*wt_server\\.mjs' || true", { encoding: 'utf8' }).split('\n').filter(x => x.trim()).length; } catch { return 0; } };
function launch(m) {
  const p = spawn('node', ['--expose-gc', '--max-old-space-size=512', SCRIPT, '2222', m.magnet],
    { env: { PATH: process.env.PATH, HOME: '/tmp', NODE_PATH: '/tmp/w/webtorrent-cli/node_modules' }, stdio: ['pipe', 'pipe', 'pipe'] });
  const rec = { p, m, out: '', stream: null, t0: Date.now(), tStream: null, exited: null };
  p.stdout.on('data', d => { rec.out += d; const x = /STREAM:(http:\/\/localhost:\d+)/.exec(rec.out); if (x && !rec.stream) { rec.stream = x[1]; rec.tStream = Date.now() - rec.t0; } });
  p.stderr.on('data', d => { rec.out += '[stderr]' + d; });
  p.on('exit', (c, s) => { rec.exited = { c, s, at: Date.now() }; });
  all.push(rec); cur = rec; return rec;
}
async function swiftSwap(m) {
  const g = ++gen; const old = cur;
  await queue; // serialized swapQueue
  queue = (async () => {
    spawnSync('pkill', ['-f', 'wt_server.mjs']);
    if (old && !old.exited) await new Promise(r => { old.p.once('exit', r); old.p.kill('SIGTERM'); });
    const dl = Date.now() + 6000; while (pgrepN() > 0 && Date.now() < dl) await sleep(250);
    if (pgrepN() > 0) { spawnSync('pkill', ['-9', '-f', 'wt_server.mjs']); await sleep(200); }
    await sleep(300);
    if (g === gen) launch(m);
  })();
}
let queue = Promise.resolve();
async function overlapSwap(m) { const old = cur; if (old && !old.exited) old.p.kill('SIGTERM'); launch(m); }
const getRange = (url, a) => new Promise((res, rej) => {
  const chunks = []; const rq = http.get(url, { headers: { Range: `bytes=${a}-` } }, r => { r.on('data', d => chunks.push(d)); r.on('end', () => res({ buf: Buffer.concat(chunks), status: r.statusCode, cr: r.headers['content-range'] })); });
  rq.on('error', rej); rq.setTimeout(60000, () => rq.destroy(new Error('timeout')));
});
const fetchAll = async (url) => { // mpv-style: follow ranges until total
  const parts = []; let pos = 0, req = 0; const total = 96 * 262144;
  while (pos < total && req++ < 200) { const r = await getRange(url, pos); if (!r.buf.length) break; parts.push(r.buf); pos += r.buf.length; }
  const all = Buffer.concat(parts); return { n: all.length, sha: crypto.createHash('sha1').update(all).digest('hex'), status: 206, reqs: req };
};
const t00 = Date.now();
for (let i = 0; i < seq.length; i++) {
  const m = M[seq[i]]; (mode === 'overlap' ? overlapSwap : swiftSwap)(m);
  await sleep(gaps[i % gaps.length]);
}
// settle on last
const last = M[seq[seq.length - 1]];
const dl = Date.now() + 90000;
await queue; while (Date.now() < dl && !(cur && cur.stream && cur.m === last)) await sleep(200);
let result = { mode, seq: seq.join(','), gaps: gaps.join(','), ok: false };
if (cur && cur.stream && cur.m === last) {
  try { const r = await fetchAll(cur.stream); result = { ...result, tStreamMs: cur.tStream, bytes: r.n, status: r.status, shaOk: r.sha === last.sha, ok: r.sha === last.sha && r.n === 96 * 262144 }; }
  catch (e) { result.fetchErr = String(e); }
} else result.noStream = true;
await sleep(500);
// teardown everything, then audit leaks
for (const r of all) if (!r.exited) r.p.kill('SIGTERM');
await sleep(2500);
spawnSync('pkill', ['-9', '-f', 'wt_server.mjs']);
const launched = all.length;
const alive = all.filter(r => !r.exited && r !== cur).length;
const bad = all.flatMap(r => r.out.split('\n').filter(l => /SERVER_ERR|uncaught|Unhandled|ReferenceError|TypeError|EADDRINUSE|FATAL|crash/i.test(l)).map(l => l.slice(0, 160)));
const stampsLeft = fs.existsSync('/tmp/wt_boot') ? fs.readdirSync('/tmp/wt_boot').length : 0;
const tmpLeft = fs.readdirSync('/tmp').filter(x => /^wt_\d+$/.test(x)).length;
const tS = all.map(r => r.tStream).join(',');
const exits = all.map(r => r.exited ? (r.exited.s || r.exited.c) : 'alive').join(',');
console.log(JSON.stringify({ ...result, launched, errs: bad.slice(0, 6), errCount: bad.length, exits, tS, stampsLeft, tmpLeft, wallS: ((Date.now() - t00) / 1000) | 0 }));
process.exit(0);
