// fixture: local HTTP tracker + seeders for N synthetic torrents. prints magnets as JSON.


const { Server: Tracker } = await import('bittorrent-tracker').catch(()=>import('/tmp/w/webtorrent-cli/node_modules/bittorrent-tracker/index.js'));
const { default: WebTorrent } = await import('webtorrent');
import crypto from 'crypto'; import fs from 'fs';
const N = parseInt(process.argv[2] || '3');
const tracker = new Tracker({ udp: false, http: true, ws: false, stats: false });
await new Promise(r => { tracker.listen(8000, '127.0.0.1', r); });
const client = new WebTorrent({ dht: false, lsd: false, tracker: true, utp: false, torrentPort: 6881 });
const out = [];
for (let i = 0; i < N; i++) {
  const buf = Buffer.alloc(96 * 262144); let s = crypto.createHash('sha256').update('seed' + i).digest();
  for (let o = 0; o < buf.length; o += 32) { s = crypto.createHash('sha256').update(s).digest(); s.copy(buf, o); }
  fs.mkdirSync('/tmp/w/h/media', { recursive: true });
  const name = `fix${i}.mkv`;
  fs.writeFileSync(`/tmp/w/h/media/${name}`, buf);
  const full = Buffer.from(buf);
  const { default: createTorrent } = await import('create-torrent');
  const tb = await new Promise((res, rej) => createTorrent(`/tmp/w/h/media/${name}`, { announce: ['http://127.0.0.1:8000/announce'], pieceLength: 262144 }, (e, b) => e ? rej(e) : res(b)));
  if (i === 3) { fs.writeFileSync(`/tmp/w/h/media/${name}`, Buffer.concat([full.subarray(0, 40 * 262144), Buffer.alloc(56 * 262144)])); }
  const pt = await (await import('parse-torrent')).default(tb);
  const t = await new Promise(r => client.add(pt, { path: '/tmp/w/h/media' }, r));
  out.push({ name, magnet: t.magnetURI + '&x.pe=127.0.0.1:6881', sha: crypto.createHash('sha1').update(full).digest('hex') });
}
fs.writeFileSync('/tmp/w/h/magnets.json', JSON.stringify(out));
console.log('READY'); setInterval(() => {}, 1e6);
