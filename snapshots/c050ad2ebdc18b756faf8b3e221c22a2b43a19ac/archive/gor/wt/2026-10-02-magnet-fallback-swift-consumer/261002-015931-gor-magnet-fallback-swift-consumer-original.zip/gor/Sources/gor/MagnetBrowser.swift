// Magnet metadata browser. No torrent content is fetched here.
import AppKit
import Foundation
import CoreFoundation
import Darwin

fileprivate struct MagnetResult: Decodable {
    let title: String
    let sizeBytes: Int64?
    let seeds: Int?
    let magnetUri: String?
    let uploadedAt: String?
    let uploadedLabel: String?
    let infoHash: String?
    let source: String
    let detailUrl: String

    var hasExecutableTitle: Bool {
        title.range(of: #"(?i)\.exe(?![a-z0-9])"#, options: .regularExpression) != nil
    }
}
fileprivate struct ProviderStatus: Decodable {
    let status: String
    let reason: String?
    let pending: [String]?
}
fileprivate struct SearchResponse: Decodable {
    let results: [MagnetResult]
    let pendingRows: [MagnetResult]
    let providers: [String: ProviderStatus]
}

// Direct JSON only. Refuse cross-host redirects before sending a query elsewhere.
private final class MagnetJSONRedirectGuard: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

// Keep the first result at the top of the scroll view even when the list is short.
private final class MagnetResultStack: NSView {
    override var isFlipped: Bool { true }
}

// A separate full-height floating field follows gor's existing archive search
// style. The results panel remains in the video frame while the field is key.
final class MagnetResultsPanel: NSView, NSTextFieldDelegate {
    var onClose: (() -> Void)?
    var onQuery: ((String) -> Void)?
    var onSelect: ((String) -> Void)?
    var onPendingSelect: ((String) -> Void)?
    var onSort: ((String, Bool) -> Void)?
    private var fieldPanel: NSPanel?
    private var rows: [MagnetResult] = []
    private var queryText = ""
    private let scroll = NSScrollView()
    private let stack = MagnetResultStack()
    private let statusLayer = CATextLayer()
    private let time = NSButton(title: "time", target: nil, action: nil)
    private let size = NSButton(title: "size", target: nil, action: nil)
    private let seed = NSButton(title: "seed", target: nil, action: nil)
    private let source = NSButton(title: "source", target: nil, action: nil)
    private let titleSort = NSButton(title: "title", target: nil, action: nil)
    private let close = NSButton(title: "×", target: nil, action: nil)
    private var sortKey = "seeds"
    private var descending = true
    private var currentSort = "seeds"
    private var descendingSort = true
    // The header and rows share these exact column starts; widths scale
    // with the loaded variable font, rather than fixed pixels.
    private var rowHeight: CGFloat { PhotonFont.lineH + 3 }
    private var sourceWidth: CGFloat { max(88, PhotonFont.charW * 7 + 12) }
    // Fit the date actually drawn (yy.MM.dd HH:mm), not a fixed 176pt slot.
    // A right-aligned value in an oversized slot made source and time look far apart.
    private var timeWidth: CGFloat { textWidth("26.09.29 13:00", font: PhotonFont.ns()) + 8 }
    private var seedWidth: CGFloat { max(78, PhotonFont.charW * 5 + 12) }
    private var sizeWidth: CGFloat { max(88, PhotonFont.charW * 8 + 12) }
    private var columnGap: CGFloat { max(14, PhotonFont.pad) }
    private let displayDate = DateFormatter()
    private let isoDate = ISO8601DateFormatter()
    private var variationToken: UUID?
    private var fieldVariationToken: UUID?

    override init(frame: NSRect) {
        super.init(frame: frame)
        wantsLayer = true; layer?.backgroundColor = NSColor.clear.cgColor
        displayDate.dateFormat = "yy.MM.dd HH:mm"
        displayDate.timeZone = .current
        isoDate.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        scroll.documentView = stack; scroll.drawsBackground = false
        scroll.hasVerticalScroller = false
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        addSubview(scroll)
        [source,time,seed,size,titleSort,close].forEach { addSubview($0) }
        statusLayer.contentsScale = NSScreen.main?.backingScaleFactor ?? 2
        statusLayer.foregroundColor = NSColor(white:0.31,alpha:1).cgColor
        statusLayer.font = PhotonFont.ct()
        statusLayer.fontSize = PhotonFont.size
        statusLayer.truncationMode = .end
        layer?.addSublayer(statusLayer)
        for (button, key) in [(source,"source"),(time,"uploadedAt"),(seed,"seeds"),(size,"sizeBytes"),(titleSort,"title")] {
            button.isBordered = false; button.font = PhotonFont.ns()
            button.contentTintColor = .white
            button.cell?.lineBreakMode = .byTruncatingTail
            button.alignment = key == "title" ? .left : .right
            button.target = self; button.action = #selector(sortTapped(_:))
            button.identifier = NSUserInterfaceItemIdentifier(key)
        }
        close.isBordered = false; close.contentTintColor = .white
        close.font = PhotonFont.ns()
        close.target = self; close.action = #selector(closeTapped)
        // Use the same point size and driven face as the rest of the UI.
        addTrackingArea(NSTrackingArea(rect: .zero,
            options: [.activeAlways, .mouseMoved, .mouseEnteredAndExited, .inVisibleRect],
            owner: self, userInfo: nil))
        variationToken = VariationBroadcaster.shared.addListener(weakLifetime: self) { [weak self] in
            guard let self, self.window != nil, !self.isHidden else { return }
            let headerFont = PhotonFont.ctDriven(view: self, profile: .panel)
            PhotonFont.setIfChanged(headerFont, on: self.statusLayer)
            for button in [self.source, self.time, self.seed, self.size, self.titleSort, self.close] {
                let driven = PhotonFont.nsDriven(view: button, profile: .button)
                if button.font != driven { button.font = driven }
            }
            for row in self.stack.subviews {
                if let button = row.subviews.compactMap({ $0 as? NSButton }).first,
                   let attributed = button.attributedTitle.mutableCopy() as? NSMutableAttributedString {
                    let driven = PhotonFont.nsDriven(view: row, profile: .row)
                    if attributed.attribute(.font, at: 0, effectiveRange: nil) as? NSFont != driven {
                        attributed.addAttribute(.font, value: driven, range: NSRange(location: 0, length: attributed.length))
                        button.attributedTitle = attributed
                    }
                }
                for cell in row.subviews.compactMap({ $0 as? NSTextField }) {
                    let driven = PhotonFont.nsDriven(view: row, profile: .row)
                    if cell.font != driven { cell.font = driven }
                }
            }
        }
    }
    required init?(coder: NSCoder) { fatalError() }
    deinit {
        if let variationToken { VariationBroadcaster.shared.removeListener(variationToken) }
        if let fieldVariationToken { VariationBroadcaster.shared.removeListener(fieldVariationToken) }
    }
    override func mouseMoved(with event: NSEvent) {
        if let pt = window?.contentView?.convert(event.locationInWindow, from: nil) {
            VariationBroadcaster.shared.update(windowPt: pt)
        }
        super.mouseMoved(with: event)
    }
    // Header and rows share these starts. The sort block packs from the
    // right edge and the title keeps a usable share of the panel; the
    // secondary columns contract before the title is allowed to collapse.
    private func columns(_ width: CGFloat) -> (source: CGFloat, time: CGFloat, seed: CGFloat, size: CGFloat, titleWidth: CGFloat, widths: [CGFloat]) {
        let gap = columnGap
        let titleMin: CGFloat = max(75, PhotonFont.charW * 5)
        let reserve = max(titleMin, width * 0.28)
        let available = max(0, width - 56 - reserve - gap * 4)
        let ideal = [sourceWidth,timeWidth,seedWidth,sizeWidth]
        let sum = ideal.reduce(0,+)
        let scale = min(1, available / sum)
        let ws = ideal.map { floor($0 * scale) }
        let sizeX = width - 42 - ws[3]
        let seedX = sizeX - gap - ws[2]
        let timeX = seedX - gap - ws[1]
        let sourceX = timeX - gap - ws[0]
        // The title button begins at x=14; leave only a 6pt gutter to source.
        return (sourceX,timeX,seedX,sizeX,max(0,sourceX - 14 - 6),ws)
    }
    private func textWidth(_ text: String, font: NSFont) -> CGFloat {
        ceil((text as NSString).size(withAttributes:[.font:font]).width) + 3
    }
    override func layout() {
        super.layout()
        // The panel is always inset inside the window (applyVideoFrame fits
        // the video frame, and any crop target, to the window bounds), so
        // layout uses the panel bounds directly - there is no off-screen
        // region to clamp against.
        let w = bounds.width, h = bounds.height
        let c = columns(w)
        // The panel is inset inside the video frame. Derive Quit's real
        // frame through the shared overlay coordinates, not from panel h.
        let headerY: CGFloat
        if let spine = (NSApp.delegate as? AppDelegate)?.controller?.spineUI,
           spine.superview != nil, spine.btnQ.superview != nil {
            headerY = spine.convert(spine.btnQ.frame, to: self).minY
        } else {
            headerY = h - PhotonFont.pad + 5 - PhotonFont.lineH
        }
        let lineH = PhotonFont.lineH + 4
        // Title stays left. Each sort label hugs its column's right edge so
        // it sits directly over the right-aligned row values; the size label
        // ends immediately left of the close button. Hit targets stay the
        // label glyphs (plus a small slack), never the inter-column gaps.
        let titleMeasure = textWidth(titleSort.title,font:titleSort.font ?? PhotonFont.ns())
        titleSort.frame = CGRect(x:14,y:headerY-4,
                                 width:max(0,min(titleMeasure,c.titleWidth)),height:lineH)
        let sortStarts = [c.source,c.time,c.seed,c.size]
        for (index,button) in [source,time,seed,size].enumerated() {
            let measure = textWidth(button.title,font:button.font ?? PhotonFont.ns()) + 6
            let rightEdge = sortStarts[index] + c.widths[index]
            button.frame = CGRect(x:rightEdge - measure,y:headerY-4,
                                  width:max(0,measure),height:lineH)
        }
        close.frame = CGRect(x:max(0,w - 26),y:headerY-4,width:22,height:lineH)
        let statusX = titleSort.frame.maxX + 7
        statusLayer.frame = CGRect(x:statusX,y:headerY,
                                   width:max(0,c.source - columnGap - statusX),height:PhotonFont.charH + 3)
        scroll.frame = CGRect(x:10,y:8,width:max(0,w-20),height:max(0,headerY-12))
        layoutResultRows()
    }
    private func layoutResultRows() {
        let contentWidth = max(0, scroll.contentSize.width)
        stack.frame = CGRect(x:0,y:0,width:contentWidth,height:CGFloat(rows.count)*rowHeight)
        let c = columns(bounds.width)
        let starts = [c.source,c.time,c.seed,c.size].map { $0 - scroll.frame.minX }
        for (i, view) in stack.subviews.enumerated() {
            view.frame = CGRect(x:0,y:CGFloat(i)*rowHeight,width:stack.frame.width,height:rowHeight)
            guard let title = view.subviews.compactMap({ $0 as? NSButton }).first else { continue }
            title.frame = CGRect(x:4,y:0,width:max(0,c.titleWidth),height:rowHeight)
            for (j, label) in view.subviews.compactMap({ $0 as? NSTextField }).enumerated() where j < 4 {
                label.frame = CGRect(x:starts[j],y:0,width:max(0,c.widths[j]),height:rowHeight)
            }
        }
    }
    var visibleResultCount: Int { rows.count }
    func setStatus(_ value: String) { statusLayer.string = "· " + value }
    func setQuery(_ value: String) { queryText = value; setStatus("searching providers") }
    // Keep the panel safe even if a different caller bypasses the controller.
    fileprivate func show(_ response: SearchResponse) {
        rows = (response.results + response.pendingRows).filter { !$0.hasExecutableTitle }.sorted { a,b in
            let left: String, right: String
            switch currentSort {
            case "title": left = a.title; right = b.title
            case "source": left = a.source; right = b.source
            default: left = ""; right = ""
            }
            if currentSort == "title" || currentSort == "source" {
                let compared = left.localizedStandardCompare(right)
                if compared != .orderedSame { return descendingSort ? compared == .orderedDescending : compared == .orderedAscending }
                return a.title.localizedStandardCompare(b.title) == .orderedAscending
            }
            if currentSort == "sizeBytes" || currentSort == "seeds" {
                let x = currentSort == "seeds" ? a.seeds.map(Int64.init) : a.sizeBytes
                let y = currentSort == "seeds" ? b.seeds.map(Int64.init) : b.sizeBytes
                if x == nil || y == nil { return x != nil && y == nil }
                if x != y { return descendingSort ? x! > y! : x! < y! }
            } else {
                let x = a.uploadedAt.flatMap { isoDate.date(from:$0) ?? ISO8601DateFormatter().date(from:$0) }
                let y = b.uploadedAt.flatMap { isoDate.date(from:$0) ?? ISO8601DateFormatter().date(from:$0) }
                if x == nil || y == nil { return x != nil && y == nil }
                if x != y { return descendingSort ? x! > y! : x! < y! }
            }
            return a.title.localizedStandardCompare(b.title) == .orderedAscending
        }
        stack.subviews.forEach { $0.removeFromSuperview() }
        for (i, row) in rows.enumerated() {
            let view = NSView(frame: .zero)
            let title = NSButton(title: row.title, target: self, action: #selector(rowTapped(_:)))
            title.toolTip = row.infoHash == nil ? "Verify magnet before playback" : row.title
            title.identifier = NSUserInterfaceItemIdentifier(String(i))
            title.isBordered = false; title.alignment = .left; title.font = PhotonFont.ns()
            title.cell?.lineBreakMode = .byTruncatingTail
            title.contentTintColor = .white
            view.addSubview(title)
            let timestamp = row.uploadedAt ?? ""
            let parsedDate = isoDate.date(from: timestamp) ?? ISO8601DateFormatter().date(from: timestamp)
            let timeText = parsedDate.map { displayDate.string(from: $0) } ?? "-"
            let sizeText = row.sizeBytes.map { ByteCountFormatter.string(fromByteCount:$0, countStyle:.file) } ?? "-"
            let cells = [row.source,timeText,row.seeds.map { String($0) } ?? "-",sizeText]
            for (index,value) in cells.enumerated() {
                let label = NSTextField(labelWithString: value)
                label.font = PhotonFont.ns()
                label.textColor = index == 0 ? NSColor(white:0.24,alpha:1) : NSColor.white.withAlphaComponent(0.5)
                label.alignment = .right
                label.lineBreakMode = .byTruncatingTail
                view.addSubview(label)
            }
            stack.addSubview(view)
        }
        setStatus("\(rows.count) results")
        // Adding document subviews does not guarantee this panel gets a layout
        // pass when its frame stays fixed. Size each row now, not just on resize.
        needsLayout = true
        layoutSubtreeIfNeeded()
        layoutResultRows()
        scroll.contentView.scroll(to:NSPoint(x:0,y:0))
        scroll.reflectScrolledClipView(scroll.contentView)
    }
    @objc private func rowTapped(_ sender: NSButton) {
        guard let id = sender.identifier?.rawValue, let index = Int(id), rows.indices.contains(index) else { return }
        let row = rows[index]
        guard !row.hasExecutableTitle else { return }
        // The parsed hash must still match the selected magnet before WT.
        guard let hash = row.infoHash, let magnet = row.magnetUri else {
            onPendingSelect?(row.detailUrl); return
        }
        guard hash.range(of: "^[0-9a-f]{40}$", options: .regularExpression) != nil,
              URLComponents(string:magnet)?.queryItems?.first(where: { $0.name == "xt" })?.value == "urn:btih:\(hash)" else { return }
        // Dismiss before playback takes focus; closing also cancels pending
        // metadata requests and restores the parent overlay event routing.
        let select = onSelect
        onClose?()
        select?(magnet)
    }
    @objc private func sortTapped(_ sender: NSButton) {
        let key = sender.identifier?.rawValue ?? "seeds"
        descending = key == sortKey ? !descending : (key == "seeds" || key == "sizeBytes" || key == "uploadedAt")
        sortKey = key
        currentSort = key; descendingSort = descending
        onSort?(sortKey, descending)
    }
    @objc private func closeTapped() { onClose?() }
    var isSearchOpen: Bool { fieldPanel?.isVisible == true }
    func setChromeAlpha(_ alpha: CGFloat, animated: Bool = false) {
        if animated {
            animator().alphaValue = alpha
            if fieldPanel?.isVisible != true { fieldPanel?.animator().alphaValue = alpha }
        } else {
            alphaValue = alpha
            if fieldPanel?.isVisible != true { fieldPanel?.alphaValue = alpha }
        }
    }
    func closeSearch() {
        guard let panel = fieldPanel else { return }
        fieldPanel = nil
        if let fieldVariationToken { VariationBroadcaster.shared.removeListener(fieldVariationToken) }
        fieldVariationToken = nil
        panel.close()
        (NSApp.delegate as? AppDelegate)?.overlayWin?.ignoresMouseEvents = false
    }
    func openSearch() {
        if let panel = fieldPanel, panel.isVisible {
            panel.makeKeyAndOrderFront(nil)
            if let field = panel.contentView?.subviews.flatMap(\.subviews).first(where: { $0 is NSTextField }) { panel.makeFirstResponder(field) }
            return
        }
        guard let parent = window else { return }
        // FileBrowserTopBar.openSearchPanel is the literal panel pattern.
        // The only geometry difference requested here is player centering.
        let pw: CGFloat = max(280, bounds.width / 3); let ph: CGFloat = 54
        let frame = CGRect(x: parent.frame.midX - pw / 2,
                           y: parent.frame.midY - ph / 2, width: pw, height: ph)
        let panel = NSPanel(
            contentRect: frame,
            styleMask: [.titled, .closable, .fullSizeContentView],
            backing: .buffered, defer: false)
        panel.isFloatingPanel = true
        panel.becomesKeyOnlyIfNeeded = false
        panel.hidesOnDeactivate = false
        panel.title = ""
        panel.level = .modalPanel
        panel.isMovableByWindowBackground = true
        panel.backgroundColor = NSColor.black
        panel.isOpaque = true
        panel.titlebarAppearsTransparent = true
        panel.appearance = NSAppearance(named: .darkAqua)
        panel.standardWindowButton(.closeButton)?.isHidden = true
        panel.standardWindowButton(.miniaturizeButton)?.isHidden = true
        panel.standardWindowButton(.zoomButton)?.isHidden = true
        NotificationCenter.default.addObserver(forName:NSWindow.willCloseNotification, object:panel, queue:.main) { [weak self, weak parent] _ in
            if self?.fieldPanel === panel {
                self?.fieldPanel = nil
                if let token = self?.fieldVariationToken { VariationBroadcaster.shared.removeListener(token) }
                self?.fieldVariationToken = nil
            }
            parent?.ignoresMouseEvents = false
        }
        let bg = NSView(frame: CGRect(x: 0, y: 0, width: pw, height: ph))
        bg.wantsLayer = true
        bg.layer?.backgroundColor = NSColor.black.cgColor
        let field = NSTextField(frame: CGRect(x: 20, y: 14, width: pw - 40, height: 28))
        field.stringValue = queryText
        field.font = PhotonFont.ns(); field.textColor = .white
        field.backgroundColor = .clear; field.drawsBackground = false
        field.isBordered = false; field.focusRingType = .none
        field.isEditable = true; field.isSelectable = true
        field.refusesFirstResponder = false
        field.placeholderString = "search"
        field.target = self; field.action = #selector(commitSearch(_:))
        field.delegate = self
        fieldVariationToken = VariationBroadcaster.shared.addListener(weakLifetime: field) { [weak field] in
            guard let field, field.window != nil else { return }
            // The search field is in its own NSPanel, not the player window.
            // Measure the pointer in screen space rather than reusing the
            // broadcaster's player-window point or a fixed proximity.
            guard let window = field.window else { return }
            let rect = window.convertToScreen(field.convert(field.bounds, to: nil))
            let pointer = NSEvent.mouseLocation
            let dx = max(rect.minX - pointer.x, 0, pointer.x - rect.maxX)
            let dy = max(rect.minY - pointer.y, 0, pointer.y - rect.maxY)
            let p = max(0, min(1, 1 - hypot(dx, dy) / DriveProfile.panel.radius))
            let vb = VariationBroadcaster.shared
            let curve = vb.curve(p, power: DriveProfile.panel.power)
            let driven = PhotonFont.nsDriven(p: p, t_audio: Double(vb.audioBlend(curve)))
            if field.font != driven { field.font = driven }
        }
        bg.addSubview(field)
        panel.contentView = bg
        fieldPanel = panel
        // The floating key window is independent of the idle mouse-hide timer.
        // Do not inherit the hidden spine alpha while the user is typing.
        panel.alphaValue = 1
        parent.ignoresMouseEvents = true
        panel.makeKeyAndOrderFront(nil); panel.assertKeyAndFocus(field)
    }
    @objc private func commitSearch(_ sender: NSTextField) {
        let query = sender.stringValue.trimmingCharacters(in:.whitespacesAndNewlines)
        closeSearch()
        if !query.isEmpty { queryText = query; onQuery?(query) }
    }
    func control(_ control: NSControl, textView: NSTextView, doCommandBy selector: Selector) -> Bool {
        if selector == #selector(NSResponder.cancelOperation(_:)) { closeSearch(); return true }
        return false
    }
}

final class MagnetBrowserController {
    let panel: MagnetResultsPanel
    private var generation = 0
    private var query = ""
    private var sort = "seeds"
    private var descending = true
    private var parsedProviders: [String:Any] = [:]
    private var failures: [String:String] = [:]
    private var pendingProviders: Set<String> = []
    private var tasks: [URLSessionDataTask] = []
    private var sessions: [URLSession] = []
    private var parseSerial = 0
    private var lastResponse: SearchResponse?
    private var trackerSeeds: [String:Int] = [:]
    private var scrapedHashes = Set<String>()
    private let trackerQueue: OperationQueue = {
        let queue = OperationQueue(); queue.maxConcurrentOperationCount = 8
        queue.qualityOfService = .utility; return queue
    }()
    private var throttledUntil = Date.distantPast
    init(app: AppDelegate, panel: MagnetResultsPanel) {
        self.panel = panel
        panel.onQuery = { [weak self] in self?.search($0) }
        panel.onSort = { [weak self] key, desc in
            guard let self else { return }
            self.sort = key; self.descending = desc
            if let response = self.lastResponse { self.panel.show(response) }
        }
        panel.onSelect = { [weak app] in app?.streamTorrent($0) }
    }
    func stop() {
        generation += 1; parseSerial += 1
        pendingProviders.removeAll()
        tasks.forEach { $0.cancel() }; tasks.removeAll()
        sessions.forEach { $0.invalidateAndCancel() }; sessions.removeAll()
        trackerQueue.cancelAllOperations()
        panel.closeSearch()
    }
    func openSearch() { panel.openSearch() }
    private func search(_ value: String) {
        let q = value.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !q.isEmpty, q.count <= 120 else { panel.setStatus("enter a shorter search"); return }
        guard Date() >= throttledUntil else { panel.setStatus("wait before searching again"); return }
        throttledUntil = Date().addingTimeInterval(20)
        generation += 1; parseSerial += 1; let token = generation
        tasks.forEach { $0.cancel() }; tasks.removeAll()
        sessions.forEach { $0.invalidateAndCancel() }; sessions.removeAll()
        query = q; parsedProviders = [:]; failures = [:]
        pendingProviders = ["apibay", "bitsearch", "magnetz", "bt4g", "bt4gRecent", "nyaa", "knaben", "eztv"]
        failures["uindex"] = "cloudflare_unresolved"
        lastResponse = nil
        trackerQueue.cancelAllOperations(); trackerSeeds = [:]; scrapedHashes = []
        panel.isHidden = false
        (NSApp.delegate as? AppDelegate)?.controller?.wakeUI()
        panel.setQuery(q)
        let encoded = q.addingPercentEncoding(withAllowedCharacters:.alphanumerics) ?? ""
        guard let primary = URL(string:"https://apibay.org/q.php?q=\(encoded)"),
              let secondary = URL(string:"https://bitsearch.eu/api/v1/search?q=\(encoded)"),
              let tertiary = URL(string:"https://magnetz.eu/api/magnets/search?query=\(encoded)&page=1"),
              let bt4g = URL(string:"https://bt4gprx.com/search?q=\(encoded)&orderby=seeders&p=1&page=rss"),
              let bt4gRecent = URL(string:"https://bt4gprx.com/search?q=\(encoded)&orderby=time&p=1&page=rss"),
              let nyaa = URL(string:"https://nyaa.si/?page=rss&q=\(encoded)"),
              let knaben = URL(string:"https://api.knaben.org/v1"),
              let eztv = URL(string:"https://eztvx.to/api/get-torrents?limit=100&page=1") else {
            panel.setStatus("invalid search"); return
        }
        // Independent providers must not wait on one another's 15s timeout.
        // Every completed source refreshes the same generation's merged rows.
        let body: [String:Any] = ["search_type":"100%", "search_field":"title",
                                 "query":q, "order_by":"seeders",
                                 "order_direction":"desc", "size":50]
        let knabenBody = try? JSONSerialization.data(withJSONObject:body)
        fetch(primary, provider:"apibay", token:token) { [weak self] in self?.parse() }
        fetch(secondary, provider:"bitsearch", token:token) { [weak self] in self?.parse() }
        fetch(tertiary, provider:"magnetz", token:token) { [weak self] in self?.parse() }
        fetch(bt4g, provider:"bt4g", token:token, mime:"application/xml") { [weak self] in self?.parse() }
        fetch(bt4gRecent, provider:"bt4gRecent", token:token, mime:"application/xml") { [weak self] in self?.parse() }
        fetch(nyaa, provider:"nyaa", token:token, mime:"application/xml") { [weak self] in self?.parse() }
        if let knabenBody {
            fetch(knaben, provider:"knaben", token:token, body:knabenBody) { [weak self] in self?.parse() }
        } else { failures["knaben"] = "request_format"; pendingProviders.remove("knaben"); parse() }
        // TV-only: one latest page. A match here does not imply whole-catalogue coverage.
        fetch(eztv, provider:"eztv", token:token) { [weak self] in self?.parse() }
    }
    private func fetch(_ url: URL, provider: String, token: Int, mime: String = "application/json", body: Data? = nil, done: @escaping () -> Void) {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 18
        let session = URLSession(configuration:config, delegate:MagnetJSONRedirectGuard(), delegateQueue:nil)
        var request = URLRequest(url:url, cachePolicy:.reloadIgnoringLocalCacheData, timeoutInterval:15)
        request.setValue(mime, forHTTPHeaderField:"Accept")
        if let body { request.httpMethod = "POST"; request.setValue("application/json", forHTTPHeaderField:"Content-Type"); request.httpBody = body }
        let task = session.dataTask(with:request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self, self.generation == token else { session.invalidateAndCancel(); return }
                self.pendingProviders.remove(provider)
                session.finishTasksAndInvalidate()
                guard error == nil, let http = response as? HTTPURLResponse,
                      http.statusCode == 200, http.url?.scheme == "https", http.url?.host == url.host,
                      http.url?.path == url.path,
                      (http.mimeType?.lowercased() == mime || (mime == "application/xml" && http.mimeType?.lowercased() == "text/xml")),
                      let data, data.count <= 1_000_000,
                      let object: Any = (mime == "application/json" ? (try? JSONSerialization.jsonObject(with:data)) : String(data:data,encoding:.utf8)) else {
                    self.failures[provider] = (response as? HTTPURLResponse)?.statusCode == 429 ? "rate_limited" : "http_or_network"
                    done(); return
                }
                self.parsedProviders[provider] = object
                done()
            }
        }
        sessions.append(session); tasks.append(task); task.resume()
    }
    private func parse() {
        var statuses: [String: ProviderStatus] = [:]
        var groups: [[MagnetResult]] = []
        for provider in parsedProviders.keys.sorted() {
            do {
                let rows = try MagnetNative.parse(provider, parsedProviders[provider]!)
                groups.append(rows)
                statuses[provider] = ProviderStatus(status: "ok", reason: nil, pending: nil)
            } catch {
                statuses[provider] = ProviderStatus(status: "unavailable", reason: String(describing:error), pending:nil)
            }
        }
        for (provider, reason) in failures {
            statuses[provider] = ProviderStatus(status:"unavailable", reason:reason, pending:nil)
        }
        for provider in pendingProviders {
            statuses[provider] = ProviderStatus(status:"pending", reason:nil, pending:nil)
        }
        let merged = MagnetNative.merge(groups,query:query)
        let enriched = merged.map { row -> MagnetResult in
            guard row.seeds == nil, let hash = row.infoHash, let seeds = trackerSeeds[hash] else { return row }
            return MagnetResult(title:row.title, sizeBytes:row.sizeBytes, seeds:seeds,
                magnetUri:row.magnetUri, uploadedAt:row.uploadedAt, uploadedLabel:row.uploadedLabel,
                infoHash:row.infoHash, source:row.source, detailUrl:row.detailUrl)
        }
        let response = SearchResponse(results:enriched, pendingRows:[], providers:statuses)
        enrichTrackerSeeds(merged)
        lastResponse = response
        panel.show(response)
        let failed = statuses.filter { $0.value.status == "unavailable" }.keys.sorted()
        let loading = pendingProviders.isEmpty ? "" : " / searching"
        panel.setStatus("\(panel.visibleResultCount) rows" + loading + (failed.isEmpty ? "" : " / unavailable: " + failed.joined(separator:", ")))
    }
    private func enrichTrackerSeeds(_ rows: [MagnetResult]) {
        let token = generation
        for row in rows where row.seeds == nil {
            guard scrapedHashes.count < 25, let hash = row.infoHash, !scrapedHashes.contains(hash),
                  let uri = row.magnetUri else { continue }
            scrapedHashes.insert(hash)
            for tracker in MagnetTracker.trackers(uri) {
                trackerQueue.addOperation { [weak self] in
                    guard let seeds = MagnetTracker.scrape(tracker,hash:hash) else { return }
                    DispatchQueue.main.async {
                        guard let self, self.generation == token else { return }
                        self.trackerSeeds[hash] = max(self.trackerSeeds[hash] ?? 0,seeds)
                        self.parse()
                    }
                }
            }
        }
    }
}

// All magnet metadata normalization lives with the panel. Reject a provider
// batch on schema drift rather than silently presenting a partial, wrong list.
private enum MagnetFormatError: Error { case layout(String) }
private enum MagnetNative {
    static func fail(_ reason: String) -> MagnetFormatError { .layout(reason) }
    static func text(_ value: Any?, _ label: String) throws -> String {
        guard let s = value as? String, !s.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, s.count <= 300 else { throw fail(label) }
        return s.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    static func num(_ value: Any?, _ label: String) throws -> Int64 {
        let number: Int64?
        if let n = value as? NSNumber, CFGetTypeID(n) != CFBooleanGetTypeID() { number = Int64(exactly: n) }
        else if let s = value as? String, s.range(of: #"^(0|[1-9][0-9]*)$"#, options: .regularExpression) != nil { number = Int64(s) }
        else { number = nil }
        guard let n = number, n >= 0 else { throw fail(label) }; return n
    }
    static func hash(_ value: Any?, _ label: String) throws -> String {
        guard let s = value as? String, s.range(of: #"^[0-9a-fA-F]{40}$"#, options: .regularExpression) != nil else { throw fail(label) }
        return s.lowercased()
    }
    static func iso(_ value: Any?, _ label: String) throws -> String {
        guard let s = value as? String, s.range(of: #"^[0-9]{4}-[0-9]{2}-[0-9]{2}T"#, options: .regularExpression) != nil else { throw fail(label) }
        let fmt = ISO8601DateFormatter(); fmt.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        guard let date = fmt.date(from: s) ?? ISO8601DateFormatter().date(from: s) else { throw fail(label) }
        return fmt.string(from: date)
    }
    static func magnet(_ name: String, _ hash: String) -> String {
        "magnet:?xt=urn:btih:\(hash)&dn=\(name.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "")"
    }
    static func row(_ source: String, _ name: String, _ hash: String, _ size: Int64?, _ seeds: Int?, _ date: String?, _ detail: String = "", uri: String? = nil) -> MagnetResult {
        MagnetResult(title: name, sizeBytes: size, seeds: seeds, magnetUri: uri ?? magnet(name,hash), uploadedAt: date, uploadedLabel: nil, infoHash: hash, source: source, detailUrl: detail)
    }
    static func dict(_ value: Any?, _ label: String) throws -> [String: Any] {
        guard let d = value as? [String: Any] else { throw fail(label) }; return d
    }
    static func array(_ value: Any?, _ max: Int, _ label: String) throws -> [[String:Any]] {
        guard let a = value as? [[String:Any]], a.count <= max else { throw fail(label) }; return a
    }
    static func matches(_ pattern: String, _ input: String) -> [[String]] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return [] }
        let ns = input as NSString
        return re.matches(in: input, range: NSRange(location:0,length:ns.length)).map { m in
            (0..<m.numberOfRanges).map { m.range(at:$0).location == NSNotFound ? "" : ns.substring(with:m.range(at:$0)) }
        }
    }
    static func first(_ pattern: String, _ input: String) -> String? { matches(pattern,input).first?.dropFirst().first }
    static func unescape(_ s: String) -> String {
        var result=s
        for (a,b) in [("&amp;","&"),("&quot;","\""),("&apos;","'"),("&lt;","<"),("&gt;",">")] { result=result.replacingOccurrences(of:a,with:b) }
        return result
    }
    static func field(_ tag: String, _ xml: String) -> String {
        unescape(first("<\(NSRegularExpression.escapedPattern(for:tag))(?:\\s+[^>]*)?>([\\s\\S]*?)</\(NSRegularExpression.escapedPattern(for:tag))>",xml) ?? "").trimmingCharacters(in:.whitespacesAndNewlines)
    }
    static func date(_ value: Any?, _ label: String) throws -> String {
        guard let s=value as? String, let d=DateFormatter.rfc2822.date(from:s) else { throw fail(label) }
        return ISO8601DateFormatter().string(from:d)
    }
    static func size(_ s:String, binary:Bool=false, _ label:String) throws -> Int64 {
        guard let m=matches(#"^([0-9]+(?:\.[0-9]+)?)\s*(B|KiB|MiB|GiB|TiB|KB|MB|GB|TB)$"#,s).first,
              let n=Double(m[1]), n >= 0 else {throw fail(label)}
        let unit=m[2].lowercased(), power=["b":0,"kb":1,"mb":2,"gb":3,"tb":4,"kib":1,"mib":2,"gib":3,"tib":4][unit] ?? 0
        let result=n*pow((binary || unit.contains("i")) ? 1024.0 : 1000.0,Double(power))
        guard result.isFinite, result <= Double(Int64.max) else {throw fail(label)}
        return Int64(result.rounded())
    }
    static func normalized(_ s:String) -> [String] {
        s.folding(options:[.diacriticInsensitive,.caseInsensitive],locale:Locale(identifier:"en_US_POSIX"))
         .lowercased().components(separatedBy:CharacterSet.alphanumerics.inverted).filter{ !$0.isEmpty }
    }
    static func merge(_ groups:[[MagnetResult]], query:String) -> [MagnetResult] {
        let terms=normalized(query)
        var rows:[String:MagnetResult]=[:]
        for r in groups.flatMap({$0}) where !r.hasExecutableTitle && !terms.isEmpty && terms.allSatisfy({normalized(r.title).contains($0)}) {
            guard let h=r.infoHash, h.range(of:#"^[0-9a-f]{40}$"#,options:.regularExpression) != nil,
                  let u=r.magnetUri, URLComponents(string:u)?.queryItems?.first(where:{$0.name=="xt"})?.value?.lowercased()=="urn:btih:\(h)" else {continue}
            if rows[h] == nil || (r.seeds ?? -1) > (rows[h]?.seeds ?? -1) {rows[h]=r}
        }
        return Array(rows.values)
    }
    static func parse(_ provider:String, _ payload:Any) throws -> [MagnetResult] {
        switch provider {
        case "apibay":
            let a=try array(payload,100,"apibay:envelope")
            if a.count==1, (a[0]["id"] as? String)=="0", (a[0]["name"] as? String)=="No results returned", (a[0]["info_hash"] as? String)==String(repeating:"0",count:40) {return []}
            return try a.map { x in
                let id=try num(x["id"],"apibay:id"); if id==0 {throw fail("apibay:id")}
                let ts=try num(x["added"],"apibay:date"); if ts > 4102444800 {throw fail("apibay:date")}
                return try row("apibay",text(x["name"],"apibay:title"),hash(x["info_hash"],"apibay:hash"),num(x["size"],"apibay:size"),Int(num(x["seeders"],"apibay:seeds")),ISO8601DateFormatter().string(from:Date(timeIntervalSince1970:Double(ts))))
            }
        case "bitsearch":
            let root=try dict(payload,"bitsearch:envelope")
            guard (root["success"] as? Bool)==true, root["pagination"] is [String:Any] else {throw fail("bitsearch:envelope")}
            return try array(root["results"],20,"bitsearch:results").map {x in
                guard let id=x["id"] as? String,id.range(of:#"^[a-fA-F0-9]{24}$"#,options:.regularExpression) != nil else {throw fail("bitsearch:id")}
                return try row("bitsearch",text(x["title"],"bitsearch:title"),hash(x["infohash"],"bitsearch:hash"),num(x["size"],"bitsearch:size"),Int(num(x["seeders"],"bitsearch:seeds")),iso(x["updatedAt"],"bitsearch:date"))
            }
        case "magnetz":
            let root=try dict(payload,"magnetz:envelope")
            guard root["meta"] is [String:Any] else {throw fail("magnetz:meta")}
            return try array(root["data"],25,"magnetz:data").map {x in
                guard let id=x["sqid"] as? String,id.range(of:#"^[a-zA-Z0-9]{4,24}$"#,options:.regularExpression) != nil else {throw fail("magnetz:id")}
                let h=try hash(x["info_hash"],"magnetz:hash")
                guard let uri=x["magnet_link"] as? String, URLComponents(string:uri)?.queryItems?.first(where:{$0.name=="xt"})?.value?.lowercased()=="urn:btih:\(h)" else {throw fail("magnetz:magnet")}
                return try row("magnetz",text(x["name"],"magnetz:title"),h,num(x["size"],"magnetz:size"),Int(num(x["seeders"],"magnetz:seeds")),iso(x["created_at"],"magnetz:date"))
            }
        case "knaben":
            let root=try dict(payload,"knaben:envelope")
            guard root["total"] is [String:Any] else {throw fail("knaben:total")}
            return try array(root["hits"],50,"knaben:hits").compactMap {x -> MagnetResult? in
                // The API documents non-magnet indexer hits with both fields null.
                // They are not magnets; do not let them invalidate valid neighbours.
                if (x["hash"] == nil || x["hash"] is NSNull) && (x["magnetUrl"] == nil || x["magnetUrl"] is NSNull) { return nil }
                let h=try hash(x["hash"],"knaben:hash")
                guard let uri=x["magnetUrl"] as? String, uri.hasPrefix("magnet:?"),URLComponents(string:uri)?.queryItems?.first(where:{$0.name=="xt"})?.value?.lowercased()=="urn:btih:\(h)" else {throw fail("knaben:magnet")}
                return try row("knaben",text(x["title"],"knaben:title"),h,num(x["bytes"],"knaben:bytes"),Int(num(x["seeders"],"knaben:seeds")),iso(x["date"],"knaben:date"),x["details"] as? String ?? "")
            }
        case "eztv":
            let root=try dict(payload,"eztv:envelope")
            _=try num(root["torrents_count"],"eztv:count"); _=try num(root["limit"],"eztv:limit"); _=try num(root["page"],"eztv:page")
            return try array(root["torrents"],100,"eztv:torrents").map {x in
                _=try num(x["id"],"eztv:id"); let h=try hash(x["hash"],"eztv:hash")
                guard let uri=x["magnet_url"] as? String,uri.hasPrefix("magnet:?"),URLComponents(string:uri)?.queryItems?.first(where:{$0.name=="xt"})?.value?.lowercased()=="urn:btih:\(h)" else {throw fail("eztv:magnet")}
                let ts=try num(x["date_released_unix"],"eztv:date");if ts>4102444800 {throw fail("eztv:date")}
                return try row("eztv",text(x["title"],"eztv:title"),h,num(x["size_bytes"],"eztv:size"),Int(num(x["seeds"],"eztv:seeds")),ISO8601DateFormatter().string(from:Date(timeIntervalSince1970:Double(ts))))
            }
        case "bt4g","bt4gRecent":
            guard let xml=payload as? String,xml.count <= 1_000_000,xml.range(of:#"^\s*<rss\s+version="2\.0""#,options:.regularExpression) != nil else {throw fail("bt4g:rss")}
            let items=matches(#"<item>[\s\S]*?</item>"#,xml).map{$0[0]};if items.count>100 {throw fail("bt4g:items")}
            return try items.map { item in
                let name=try text(field("title",item),"bt4g:title")
                let uri=field("link",item)
                guard uri.hasPrefix("magnet:?"),let h=URLComponents(string:uri)?.queryItems?.first(where:{$0.name=="xt"})?.value?.lowercased().replacingOccurrences(of:"urn:btih:",with:"") else {throw fail("bt4g:magnet")}
                let validHash=try hash(h,"bt4g:hash")
                let detail=field("guid",item)
                guard let url=URL(string:detail),url.scheme=="https",url.host=="bt4gprx.com",url.path.range(of:#"^/magnet/[a-zA-Z0-9]+$"#,options:.regularExpression) != nil else {throw fail("bt4g:guid")}
                guard let desc=first(#"<description><!\[CDATA\[([\s\S]*?)\]\]></description>"#,item) else {throw fail("bt4g:description")}
                let pieces=desc.replacingOccurrences(of:#"(?i)<br\s*/?>"#,with:"\u{0001}",options:.regularExpression).components(separatedBy:"\u{0001}").map{$0.trimmingCharacters(in:.whitespacesAndNewlines)}
                guard pieces.count==4,pieces[3].lowercased()==validHash else {throw fail("bt4g:description")}
                return try row("bt4g",name,validHash,size(pieces[1],"bt4g:size"),nil,date(field("pubDate",item),"bt4g:date"),detail,uri:uri)
            }
        case "nyaa":
            guard let xml=payload as? String,xml.count<=1_000_000,xml.contains("<rss") else {throw fail("nyaa:rss")}
            let items=matches(#"<item>[\s\S]*?</item>"#,xml).map{$0[0]};if items.count>100 {throw fail("nyaa:items")}
            return try items.map {item in
                let name=try text(field("title",item),"nyaa:title")
                let h=try hash(field("nyaa:infoHash",item),"nyaa:hash")
                let link=field("link",item)
                guard link.range(of:#"^https://nyaa\.si/(view|download)/[0-9]+(?:\.torrent)?$"#,options:.regularExpression) != nil else {throw fail("nyaa:link")}
                return try row("nyaa",name,h,size(field("nyaa:size",item),binary:true,"nyaa:size"),Int(num(field("nyaa:seeders",item),"nyaa:seeds")),date(field("pubDate",item),"nyaa:date"))
            }
        default: throw fail("unknown provider")
        }
    }
}
private extension DateFormatter {
    static var rfc2822: DateFormatter {
        let f=DateFormatter();f.locale=Locale(identifier:"en_US_POSIX");f.timeZone=TimeZone(secondsFromGMT:0)
        f.dateFormat="EEE,dd MMM yyyy HH:mm:ss Z";return f
    }
}

// BEP 15 swarm metadata only. No torrent payload is downloaded.
private enum MagnetTracker {
    static func scrape(_ tracker: String, hash: String, timeoutMS: Int32 = 4000) -> Int? {
        guard let url = URL(string:tracker), url.scheme == "udp", let host = url.host,
              let port = url.port, (1...65535).contains(port),
              hash.range(of:#"^[0-9a-f]{40}$"#,options:.regularExpression) != nil else { return nil }
        var hints = addrinfo()
        hints.ai_family = AF_INET
        #if os(Linux)
        hints.ai_socktype = Int32(SOCK_DGRAM.rawValue)
        #else
        hints.ai_socktype = SOCK_DGRAM
        #endif
        hints.ai_protocol = Int32(IPPROTO_UDP)
        var info: UnsafeMutablePointer<addrinfo>?
        guard getaddrinfo(host, String(port), &hints, &info) == 0, let address = info else { return nil }
        defer { freeaddrinfo(info) }
        let fd = socket(address.pointee.ai_family, address.pointee.ai_socktype, address.pointee.ai_protocol)
        guard fd >= 0 else { return nil }
        defer { close(fd) }
        guard connect(fd, address.pointee.ai_addr, address.pointee.ai_addrlen) == 0 else { return nil }
        let deadline = Date().addingTimeInterval(Double(timeoutMS)/1000)
        func word(_ value: UInt32) -> [UInt8] {
            [UInt8(truncatingIfNeeded:value >> 24), UInt8(truncatingIfNeeded:value >> 16),
             UInt8(truncatingIfNeeded:value >> 8), UInt8(truncatingIfNeeded:value)]
        }
        func number(_ bytes: [UInt8], _ at: Int) -> UInt32 {
            (UInt32(bytes[at]) << 24) | (UInt32(bytes[at+1]) << 16) | (UInt32(bytes[at+2]) << 8) | UInt32(bytes[at+3])
        }
        func exchange(_ packet: [UInt8], action: UInt32, transaction: UInt32, minimum: Int) -> [UInt8]? {
            let sent = packet.withUnsafeBytes { send(fd,$0.baseAddress,packet.count,0) }
            guard sent == packet.count else { return nil }
            while Date() < deadline {
                var waiter = pollfd(fd:fd,events:Int16(POLLIN),revents:0)
                let remaining = Int32(max(1,deadline.timeIntervalSinceNow*1000))
                guard poll(&waiter,1,remaining) > 0 else { return nil }
                var bytes = [UInt8](repeating:0,count:2048)
                let length = bytes.withUnsafeMutableBytes { recv(fd,$0.baseAddress,2048,0) }
                guard length >= 8 else { continue }
                if number(bytes,4) != transaction { continue }
                guard number(bytes,0) == action, length >= minimum else { return nil }
                return Array(bytes.prefix(length))
            }
            return nil
        }
        let connectID = UInt32.random(in:UInt32.min...UInt32.max)
        let request:[UInt8] = [0,0,4,23,39,16,25,128] + word(0) + word(connectID)
        guard let response = exchange(request,action:0,transaction:connectID,minimum:16) else { return nil }
        let scrapeID = UInt32.random(in:UInt32.min...UInt32.max)
        var hashBytes:[UInt8] = []
        var index = hash.startIndex
        for _ in 0..<20 {
            let end = hash.index(index,offsetBy:2)
            guard let byte = UInt8(hash[index..<end],radix:16) else { return nil }
            hashBytes.append(byte); index = end
        }
        let scrapePacket = Array(response[8..<16]) + word(2) + word(scrapeID) + hashBytes
        guard let answer = exchange(scrapePacket,action:2,transaction:scrapeID,minimum:20) else { return nil }
        return Int(number(answer,8))
    }
    static func trackers(_ uri: String) -> [String] {
        Array((URLComponents(string:uri)?.queryItems ?? []).filter{$0.name == "tr"}
            .compactMap(\.value).filter{$0.hasPrefix("udp://")}.prefix(3))
    }
}


// ================================================================
//  MagnetFallbackSearch - automatic background fallback (wt v22.6)
// ================================================================
// wt_server emits REQ:magnet-fallback {json} when a stream is starved for
// good (no-holder / all-choked / no-peers / no-metadata / stalled). This
// searches the same providers as the panel, headless, by media name
// (+sXXeYY or year, +resolution), then swaps silently to the best eligible
// candidate that is not the current or an already-tried magnet.
// Lives in this file because MagnetResult / MagnetNative are fileprivate.
// Guards: one search at a time, 45s cooldown after a swap, max 3 swaps per
// origin title, and the result is dropped if the user started or stopped a
// stream while the search ran.
final class MagnetFallbackSearch {
    static let shared = MagnetFallbackSearch()
    private var inFlight = false
    private var originKey = ""
    private var tried = Set<String>()
    private var swaps = 0
    private var lastSwapAt = Date.distantPast
    private let maxSwaps = 3
    private let cooldown: TimeInterval = 45
    private let minSeeds = 2

    func handle(requestLine: String, app: AppDelegate) {
        guard !inFlight, Date().timeIntervalSince(lastSwapAt) >= cooldown else { return }
        guard let data = requestLine.data(using: .utf8),
              let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let title = obj["title"] as? String, title.count >= 3,
              let query = obj["query"] as? String, !query.isEmpty else { return }
        let episode = obj["episode"] as? String
        let year = obj["year"] as? String
        let resolution = obj["resolution"] as? String
        let reason = obj["reason"] as? String ?? "unknown"
        let key = [title.lowercased(), episode ?? year ?? ""].joined(separator: "|")
        if key != originKey { originKey = key; tried = []; swaps = 0 }
        guard swaps < maxSwaps else { return }
        if let current = (obj["infoHash"] as? String)?.lowercased() { tried.insert(current) }
        let origin = app.lastMagnetURL
        guard !origin.isEmpty, app.torrentProcess != nil else { return }
        inFlight = true
        var queries = [query]
        let relaxed = [title, episode ?? year].compactMap { $0 }.joined(separator: " ")
        if resolution != nil, relaxed != query { queries.append(relaxed) }
        print("[wt-fallback] request reason=\(reason) query=\"\(query)\" swaps=\(swaps)/\(maxSwaps)")
        run(queries: queries, resolution: resolution) { [weak self, weak app] picked in
            guard let self else { return }
            self.inFlight = false
            // The user started, replaced or stopped a stream meanwhile: do nothing.
            guard let app, app.lastMagnetURL == origin, app.torrentProcess != nil else {
                print("[wt-fallback] dropped: stream changed during search"); return
            }
            guard let picked else { print("[wt-fallback] no eligible candidate"); return }
            self.tried.insert(picked.hash)
            self.swaps += 1
            self.lastSwapAt = Date()
            if let c = app.controller, c.currentTime > 5 { c.pendingStreamStartPos = max(0, c.currentTime - 3) }
            print("[wt-fallback] swap -> \(picked.hash) seeds=\(picked.seeds) \"\(picked.title)\"")
            app.streamTorrent(picked.magnet)
        }
    }

    private func run(queries: [String], resolution: String?,
                     done: @escaping ((hash: String, magnet: String, seeds: Int, title: String)?) -> Void) {
        guard let q = queries.first else { done(nil); return }
        fetchAll(query: q) { [weak self] rows in
            guard let self else { done(nil); return }
            if let best = self.pick(rows, resolution: resolution) { done(best); return }
            self.run(queries: Array(queries.dropFirst()), resolution: resolution, done: done)
        }
    }

    private func pick(_ rows: [MagnetResult], resolution: String?) -> (hash: String, magnet: String, seeds: Int, title: String)? {
        let eligible = rows.filter { r in
            guard let h = r.infoHash, !tried.contains(h), r.magnetUri != nil, (r.seeds ?? 0) >= minSeeds else { return false }
            return true
        }
        func resMatch(_ r: MagnetResult) -> Int {
            guard let res = resolution else { return 0 }
            return r.title.lowercased().contains(res) ? 1 : 0
        }
        let sorted = eligible.sorted { (resMatch($0), $0.seeds ?? 0) > (resMatch($1), $1.seeds ?? 0) }
        guard let r = sorted.first, let h = r.infoHash, let m = r.magnetUri else { return nil }
        return (h, m, r.seeds ?? 0, r.title)
    }

    private struct Job { let provider: String; let url: URL; let mime: String; let body: Data? }

    private func fetchAll(query: String, done: @escaping ([MagnetResult]) -> Void) {
        let encoded = query.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? ""
        var jobs: [Job] = []
        func add(_ provider: String, _ urlString: String, mime: String = "application/json", body: Data? = nil) {
            if let url = URL(string: urlString) { jobs.append(Job(provider: provider, url: url, mime: mime, body: body)) }
        }
        add("apibay", "https://apibay.org/q.php?q=\(encoded)")
        add("bitsearch", "https://bitsearch.eu/api/v1/search?q=\(encoded)")
        add("magnetz", "https://magnetz.eu/api/magnets/search?query=\(encoded)&page=1")
        add("bt4g", "https://bt4gprx.com/search?q=\(encoded)&orderby=seeders&p=1&page=rss", mime: "application/xml")
        add("nyaa", "https://nyaa.si/?page=rss&q=\(encoded)", mime: "application/xml")
        let knabenBody: [String: Any] = ["search_type": "100%", "search_field": "title", "query": query,
                                         "order_by": "seeders", "order_direction": "desc", "size": 50]
        add("knaben", "https://api.knaben.org/v1", body: try? JSONSerialization.data(withJSONObject: knabenBody))
        add("eztv", "https://eztvx.to/api/get-torrents?limit=100&page=1")

        var groups: [[MagnetResult]] = []
        let group = DispatchGroup()
        for job in jobs {
            group.enter()
            let config = URLSessionConfiguration.ephemeral
            config.timeoutIntervalForRequest = 15
            config.timeoutIntervalForResource = 18
            let session = URLSession(configuration: config, delegate: MagnetJSONRedirectGuard(), delegateQueue: nil)
            var request = URLRequest(url: job.url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
            request.setValue(job.mime, forHTTPHeaderField: "Accept")
            if let body = job.body {
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = body
            }
            session.dataTask(with: request) { data, response, error in
                DispatchQueue.main.async {
                    defer { session.finishTasksAndInvalidate(); group.leave() }
                    // Same response checks as the panel's fetch(): https, same host and path, expected mime, 1 MB cap.
                    guard error == nil, let http = response as? HTTPURLResponse, http.statusCode == 200,
                          http.url?.scheme == "https", http.url?.host == job.url.host, http.url?.path == job.url.path,
                          (http.mimeType?.lowercased() == job.mime
                           || (job.mime == "application/xml" && http.mimeType?.lowercased() == "text/xml")),
                          let data, data.count <= 1_000_000,
                          let object: Any = (job.mime == "application/json"
                                             ? (try? JSONSerialization.jsonObject(with: data))
                                             : String(data: data, encoding: .utf8)),
                          let rows = try? MagnetNative.parse(job.provider, object) else { return }
                    groups.append(rows)
                }
            }.resume()
        }
        group.notify(queue: .main) { done(MagnetNative.merge(groups, query: query)) }
    }
}
