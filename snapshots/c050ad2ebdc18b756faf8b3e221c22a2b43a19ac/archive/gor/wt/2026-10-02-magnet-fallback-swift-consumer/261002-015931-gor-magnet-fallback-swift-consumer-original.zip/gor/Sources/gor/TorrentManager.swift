// ================================================================
//  TorrentManager.swift - torrent streaming bridge
//  Owns: webtorrent process, stdout protocol, stream setup
//  Contract: Buffer stdout until newline before decoding UTF-8
// ================================================================

import AppKit
import Foundation

// ================================================================
//  StdoutLineBuffer - UTF-8 pipe framing
// ================================================================
// A pipe read returns at most ~64 KB, so one long line (FILES: for a big
// torrent) arrives in pieces; splitting each read on its own cut the JSON
// mid-string. Bytes are held until a newline, which also keeps a multi-byte
// character that straddles two reads intact. A class, not a captured var:
// the readabilityHandler closure may be @Sendable and cannot mutate a var.
private final class StdoutLineBuffer {
    private var data = Data()
    
    func lines(appending chunk: Data) -> [String] {
        data.append(chunk)
        guard chunk.contains(0x0A) else { return [] }
        var out: [String] = []
        while let nl = data.firstIndex(of: 0x0A) {
            if let s = String(data: data[data.startIndex..<nl], encoding: .utf8) {
                out.append(s)
            }
            data.removeSubrange(data.startIndex...nl)
        }
        return out
    }
}

// ================================================================
//  AppDelegate - application lifecycle
// ================================================================
extension AppDelegate {
    // MARK: - Properties
    
    
    // PARAMS/METADATA lines are written on the pipe-handler queue and read
    // on main - a lock owns the handshake.
    private static let paramsLock = NSLock()
    private static var _pendingDemuxerMaxBytes: Int = 500_000_000
    private static var _pendingCacheSecs: Int = 30
    private static var _isHDRTorrent: Bool = false

    static var pendingDemuxerMaxBytes: Int {
        get { paramsLock.lock(); defer { paramsLock.unlock() }; return _pendingDemuxerMaxBytes }
        set { paramsLock.lock(); _pendingDemuxerMaxBytes = newValue; paramsLock.unlock() }
    }
    static var pendingCacheSecs: Int {
        get { paramsLock.lock(); defer { paramsLock.unlock() }; return _pendingCacheSecs }
        set { paramsLock.lock(); _pendingCacheSecs = newValue; paramsLock.unlock() }
    }
    static var isHDRTorrent: Bool {
        get { paramsLock.lock(); defer { paramsLock.unlock() }; return _isHDRTorrent }
        set { paramsLock.lock(); _isHDRTorrent = newValue; paramsLock.unlock() }
    }
    
    // MARK: - Stream
    
    private static let swapQueue = DispatchQueue(label: "gor.torrent.swap", qos: .utility)
    private static var swapGeneration = 0

    func streamTorrent(_ magnetOrURL: String) {
        Self.swapGeneration += 1
        let generation = Self.swapGeneration
        let old = torrentProcess
        Self.swapQueue.async { [weak self] in
            let killTask = Process()
            killTask.executableURL = URL(fileURLWithPath: "/usr/bin/pkill")
            killTask.arguments = ["-f", "wt_server.mjs"]
            try? killTask.run()
            if killTask.isRunning { killTask.waitUntilExit() }
            if let old, old.isRunning { old.terminate(); old.waitUntilExit() }
            Self.reapWtServerZombies()
            Thread.sleep(forTimeInterval: 0.3)
            DispatchQueue.main.async {
                guard let self, generation == Self.swapGeneration else { return }
                self.torrentProcess = nil
                self.torrentStdinPipe = nil
                self.startTorrentAfterSwap(magnetOrURL)
            }
        }
    }

    /// pkill only *sends* SIGTERM — handle-less zombies (orphaned by a crashed
    /// gor) still hold 2222/51413/6771 for up to their 5s shutdown watchdog while
    /// the new process probes them. Wait until pgrep finds none, SIGKILL after 6s.
    private static func reapWtServerZombies(timeout: TimeInterval = 6.0) {
        func survivors() -> Int {
            let p = Process()
            let pipe = Pipe()
            p.executableURL = URL(fileURLWithPath: "/usr/bin/pgrep")
            p.arguments = ["-f", "wt_server.mjs"]
            p.standardOutput = pipe
            p.standardError = FileHandle.nullDevice
            guard (try? p.run()) != nil else { return 0 }
            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            p.waitUntilExit()
            return String(decoding: data, as: UTF8.self)
                .split(separator: "\n")
                .filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
                .count
        }
        let deadline = Date().addingTimeInterval(timeout)
        while survivors() > 0, Date() < deadline {
            Thread.sleep(forTimeInterval: 0.25)
        }
        guard survivors() > 0 else { return }
        let hard = Process()
        hard.executableURL = URL(fileURLWithPath: "/usr/bin/pkill")
        hard.arguments = ["-9", "-f", "wt_server.mjs"]
        try? hard.run()
        if hard.isRunning { hard.waitUntilExit() }
        let hardDeadline = Date().addingTimeInterval(2)
        while survivors() > 0, Date() < hardDeadline {
            Thread.sleep(forTimeInterval: 0.1)
        }
    }

    private func startTorrentAfterSwap(_ magnetOrURL: String) {
        // Node stays bundled; the script and its relative dependencies share one root.
        let resources = Bundle.main.resourceURL
        let node = resources?.appendingPathComponent("vendor/node/node").path
        let candidate = AppDelegate.devVendorRoot()
        let devVendor = candidate.flatMap { vendor -> URL? in
            let script = vendor.appendingPathComponent("wt_server/wt_server.mjs").path
            let dependency = vendor.appendingPathComponent("webtorrent-cli/node_modules/webtorrent/index.js").path
            return FileManager.default.isReadableFile(atPath: script)
                && FileManager.default.isReadableFile(atPath: dependency) ? vendor : nil
        }
        let script = devVendor?
            .appendingPathComponent("wt_server/wt_server.mjs").path
            ?? resources?.appendingPathComponent("vendor/wt_server/wt_server.mjs").path
        let dependency = devVendor?
            .appendingPathComponent("webtorrent-cli/node_modules/webtorrent/index.js").path
            ?? resources?.appendingPathComponent("vendor/webtorrent-cli/node_modules/webtorrent/index.js").path
        if let node, let script, let dependency,
           FileManager.default.isExecutableFile(atPath: node),
           FileManager.default.fileExists(atPath: script),
           FileManager.default.fileExists(atPath: dependency) {
            streamWithWebTorrent(source: magnetOrURL)
        } else {
            showTorrentOverlay(status: "torrent backend missing (Node, wt_server or WebTorrent)")
        }
    }

    private func streamWithWebTorrent(source: String) {
        stopTorrent()
        lastMagnetURL = source
        try? FileManager.default.removeItem(atPath: "/tmp/gor_watch_later")
        try? FileManager.default.createDirectory(atPath: "/tmp/gor_watch_later", withIntermediateDirectories: true)
        showTorrentOverlay(status: "connecting to peers...")
        
        let candidate = AppDelegate.devVendorRoot()
        let devVendor = candidate.flatMap { vendor -> URL? in
            let script = vendor.appendingPathComponent("wt_server/wt_server.mjs").path
            let dependency = vendor.appendingPathComponent("webtorrent-cli/node_modules/webtorrent/index.js").path
            return FileManager.default.isReadableFile(atPath: script)
                && FileManager.default.isReadableFile(atPath: dependency) ? vendor : nil
        }
        let scriptPath = devVendor?
            .appendingPathComponent("wt_server/wt_server.mjs").path
            ?? Bundle.main.path(forResource: "vendor/wt_server/wt_server", ofType: "mjs")
        guard let scriptPath else {
            showTorrentOverlay(status: "wt_server.mjs not found")
            return
        }
        
        let nodePath = Bundle.main.path(forResource: "node", ofType: nil, inDirectory: "vendor/node") ?? "/opt/homebrew/bin/node"
        guard FileManager.default.isExecutableFile(atPath: nodePath) else {
            showTorrentOverlay(status: "node not found")
            return
        }
        
        var nodeSource = source
        if source.lowercased().hasPrefix("file://") {
            if let u = URL(string: source), u.isFileURL {
                nodeSource = u.path
            } else {
                nodeSource = String(source.dropFirst("file://".count))
            }
        }
        
        let p = Process()
        p.executableURL = URL(fileURLWithPath: nodePath)
        p.arguments = ["--expose-gc", "--max-old-space-size=512", scriptPath, "2222", nodeSource]
        p.environment = [
            "PATH": "/opt/homebrew/bin:/usr/bin:/bin",
            "HOME": NSHomeDirectory(),
            "NODE_PATH": (devVendor?.path ?? Bundle.main.resourcePath! + "/vendor")
                + "/webtorrent-cli/node_modules",
        ]
        
        let stdoutPipe = Pipe()
        let stdinPipe = Pipe()
        let stderrPipe = Pipe()
        p.standardOutput = stdoutPipe
        p.standardError  = stderrPipe
        p.standardInput = stdinPipe
        torrentProcess = p
        torrentStdinPipe = stdinPipe
        torrentStdoutPipe = stdoutPipe
        torrentStderrPipe = stderrPipe
        
        let stdoutLines = StdoutLineBuffer()
        stdoutPipe.fileHandleForReading.readabilityHandler = { [weak self, weak p] handle in
            let data = handle.availableData
            guard !data.isEmpty else { return }
            for line in stdoutLines.lines(appending: data) {
                let l = line.trimmingCharacters(in: .whitespacesAndNewlines)
                if l.hasPrefix("FILES:") {
                    let json = String(l.dropFirst("FILES:".count))
                    DispatchQueue.main.async { [weak self] in
                        self?.openTorrentBrowserPanel()
                        self?.torrentBrowserPanel?.showTorrentFiles(json: json) { [weak self] index in
                            guard let pipe = self?.torrentStdinPipe else { return }
                            if let d = "SELECT:\(index)\n".data(using: .utf8) {
                                pipe.fileHandleForWriting.write(d)
                            }
                        }
                    }
                } else if l.hasPrefix("STATS:") {
                    let json = String(l.dropFirst("STATS:".count))
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self,
                              let spineUI = self.controller?.spineUI,
                              spineUI.alphaValue > 0 else { return }
                        guard let data = json.data(using: .utf8),
                              let stats = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
                        // A dying previous wt_server keeps this pipe handler alive
                        // and can paint zeroed STATS over the new session's HUD.
                        // v20.2 stamps each STATS with its process pid — drop mismatches.
                        if let session = stats["session"] as? Int,
                           session != Int(self.torrentProcess?.processIdentifier ?? -1) { return }
                        let dl = stats["downloadSpeed"] as? Double ?? 0
                        let peers = stats["numPeers"] as? Int ?? 0
                        let dlStr = dl > 1_000_000 ? String(format: "%.1f MB/s", dl / 1_000_000) :
                        dl > 1_000 ? String(format: "%.0f KB/s", dl / 1_000) :
                        "\(Int(dl)) B/s"
                        let downloaded = stats["downloaded"] as? Double ?? 0
                        let dlTotalStr = downloaded > 1_000_000_000 ? String(format: "%.1f GB", downloaded / 1_000_000_000) :
                        downloaded > 1_000_000 ? String(format: "%.0f MB", downloaded / 1_000_000) :
                        downloaded > 1_000 ? String(format: "%.0f KB", downloaded / 1_000) :
                        "\(Int(downloaded)) B"
                        let fileLen = stats["fileLength"] as? Double ?? 0
                        let totalStr = fileLen > 1_000_000_000 ? String(format: "%.1f GB", fileLen / 1_000_000_000) :
                        fileLen > 1_000_000 ? String(format: "%.0f MB", fileLen / 1_000_000) :
                        "\(Int(fileLen)) B"

                        let osdFont = PhotonFont.ns()
                        let spaceW = " ".width(using: osdFont)

                        func splitVal(_ str: String) -> (num: String, unit: String) {
                            let parts = str.components(separatedBy: " ")
                            if parts.count >= 2, Double(parts[0]) != nil {
                                return (parts[0], parts.dropFirst().joined(separator: " "))
                            }
                            return (str, "")
                        }

                        let dlSplit = splitVal(dlStr)
                        let dlTotalSplit = splitVal(dlTotalStr)
                        let totalSplit = splitVal(totalStr)

                        let peersStr = String(peers)

                        let numColW: CGFloat = 60
                        let unitColW: CGFloat = 50

                        func alignRight(_ s: String, width: CGFloat) -> String {
                            let w = s.width(using: osdFont)
                            let pad = Int(ceil((width - w) / spaceW))
                            return String(repeating: " ", count: max(0, pad)) + s
                        }

                        func alignLeft(_ s: String, width: CGFloat) -> String {
                            let w = s.width(using: osdFont)
                            let pad = Int(ceil((width - w) / spaceW))
                            return s + String(repeating: " ", count: max(0, pad))
                        }

                        let msg = """
                        ░  \(alignRight(peersStr, width: numColW))  \(alignLeft("peers", width: unitColW))
                        ↓  \(alignRight(dlSplit.num, width: numColW))  \(alignLeft(dlSplit.unit, width: unitColW))
                        ↴  \(alignRight(dlTotalSplit.num, width: numColW))  \(alignLeft(dlTotalSplit.unit, width: unitColW))
                          \(alignRight(totalSplit.num, width: numColW))  \(alignLeft(totalSplit.unit, width: unitColW))
                        """
                        
                        self.controller?.spineUI.showMPVOSD(msg, animated: false)
                    }
                } else if l.hasPrefix("VERDICT:") {
                    // v21.0: wt_server suspects a corrupt swarm (a piece keeps
                    // failing hash from every peer) — name it on the HUD
                    // instead of letting the stats grid spin silently.
                    let payload = String(l.dropFirst("VERDICT:".count))
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self,
                              let spineUI = self.controller?.spineUI,
                              spineUI.alphaValue > 0 else { return }
                        let piece = payload.components(separatedBy: "piece=").dropFirst().first?
                            .components(separatedBy: .whitespaces).first ?? "?"
                        let fails = payload.components(separatedBy: "fails=").dropFirst().first?
                            .components(separatedBy: .whitespaces).first ?? "?"
                        spineUI.showMPVOSD("piece \(piece) failed hash \(fails)x — swarm looks corrupt, try another release", animated: false)
                    }
                } else if l.hasPrefix("STORE:") {
                    let json = String(l.dropFirst("STORE:".count))
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self,
                              let spineUI = self.controller?.spineUI,
                              let data = json.data(using: .utf8),
                              let store = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
                        spineUI.torrentStalling = store["stalling"] as? Bool ?? false
                        spineUI.torrentStalledPiece = store["stalledPiece"] as? Int
                        spineUI.torrentWindowActive = store["windowActive"] as? Bool ?? false
                    }
                } else if l.hasPrefix("CMD:") {
                    let cmdLine = String(l.dropFirst("CMD:".count))
                    print("[Torrent] CMD received: \(cmdLine)")
                    let parts = cmdLine.components(separatedBy: " ")
                    let cmd = parts.first ?? ""
                    let text = parts.dropFirst().joined(separator: " ")
                    DispatchQueue.main.async { [weak self] in
                        self?.controller?.spineUI.reportTorrentCommandFeedback(forCmd: cmd, text: text)
                    }
                } else if l.hasPrefix("PARAMS:") {
                    let json = String(l.dropFirst("PARAMS:".count))
                    if let data = json.data(using: .utf8),
                       let params = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                        if let demux = params["demuxerMaxBytes"] as? Int {
                            AppDelegate.pendingDemuxerMaxBytes = demux
                        }
                        if let cache = params["cacheSecs"] as? Int {
                            AppDelegate.pendingCacheSecs = cache
                        }
                    }
                } else if l.hasPrefix("METADATA:") {
                    AppDelegate.isHDRTorrent = l.contains("HDR")
                } else if l.hasPrefix("STREAM:") {
                    let url = String(l.dropFirst("STREAM:".count))
                    self?.currentTorrentURL = url
                    let demuxerMaxBytes = AppDelegate.pendingDemuxerMaxBytes
                    let cacheSecs = AppDelegate.pendingCacheSecs
                    self?.controller?.ipcCommand(#"{"command":["script-message-to","photon","set-live","true"]}"#)
                    DispatchQueue.main.async { [weak self] in
                        // Baseline first so a previous file's branch profile
                        // (pixeldrain/MEGA) cannot leak in; PARAMS then owns
                        // cache/demuxer/decode for this torrent (pass-5 #4/#7).
                        self?.restoreDefaultProfile()
                        self?.controller?.ipcCommand(#"{"command":["set","cache","yes"]}"#)
                        self?.controller?.ipcCommand(#"{"command":["set","cache-secs","\#(cacheSecs)"]}"#)
                        self?.controller?.ipcCommand(#"{"command":["set","cache-pause-initial","yes"]}"#)
                        self?.controller?.ipcCommand(#"{"command":["set","demuxer-readahead-secs","\#(cacheSecs)"]}"#)
                        self?.controller?.ipcCommand(#"{"command":["set","demuxer-max-bytes","\#(demuxerMaxBytes / 1_000_000)M"]}"#)
                        // Live SDR photon samples an occasional screenshot instead of
                        // running signalstats as a per-frame vf. Keep hardware decode
                        // available for both SDR and HDR magnets (runtime fallback remains mpv's).
                        self?.controller?.ipcCommand(#"{"command":["set","hwdec","auto-safe"]}"#)
                        self?.controller?.ipcCommand(#"{"command":["set","cache-pause","no"]}"#)
                        self?.controller?.ipcCommand(#"{"command":["set","vd-lavc-skiploopfilter","all"]}"#)
                        
                        self?.torrentBrowserPanel?.removeFromSuperview()
                        self?.torrentBrowserPanel = nil
                        self?.isShowingInputPanel = false
                        self?.overlayWin?.ignoresMouseEvents = false
                        if let tap = self?.eventTap { CGEvent.tapEnable(tap: tap, enable: true) }
                        self?.showTorrentOverlay(status: "stream ready")
                        
                        let pos = self?.controller?.pendingStreamStartPos
                        self?.controller?.pendingStreamStartPos = nil
                        self?.playMedia(url: url, title: self?.torrentTitle ?? "Torrent", startPos: pos)
                        
                        self?.controller?.spineUI.showStreamControls()
                    }
                } else if l.hasPrefix("TITLE:") {
                    let title = String(l.dropFirst("TITLE:".count))
                    self?.torrentTitle = title
                    DispatchQueue.main.async { [weak self] in
                        self?.showTorrentOverlay(status: title)
                    }
                } else if l.hasPrefix("REQ:magnet-fallback ") {
                    // wt v22.6 dead-end request: search by media name, swap silently.
                    let payload = String(l.dropFirst("REQ:magnet-fallback ".count))
                    print("[wt] \(l)")
                    DispatchQueue.main.async { [weak self] in
                        // A dying previous wt_server must not trigger a swap for the new session.
                        guard let self, let p, self.torrentProcess === p else { return }
                        MagnetFallbackSearch.shared.handle(requestLine: payload, app: self)
                    }
                } else if l.hasPrefix("REQ:") {
                    print("[wt] \(l)")
                }
            }
        }
        
        stderrPipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let data = handle.availableData
            guard !data.isEmpty, let text = String(data: data, encoding: .utf8) else { return }
            let line = text.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.hasPrefix("ERROR:") {
                DispatchQueue.main.async { [weak self] in
                    self?.showTorrentOverlay(status: line.dropFirst(6).trimmingCharacters(in: .whitespaces))
                }
            }
        }
        
        do {
            try p.run()
        } catch {
            showTorrentOverlay(status: "failed to start node: \(error.localizedDescription)")
        }
    }
    
    private func streamWithPeerflix(_ path: String, source: String) {
        showTorrentOverlay(status: "starting peerflix...")
        
        let p = Process()
        p.executableURL = URL(fileURLWithPath: path)
        p.arguments = [source, "-p", "8888", "-q"]
        
        let pipe = Pipe()
        p.standardOutput = pipe
        p.standardError = pipe
        
        torrentProcess = p
        
        pipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let data = handle.availableData
            guard !data.isEmpty, let line = String(data: data, encoding: .utf8) else { return }
            
            if let range = line.range(of: #"https?://[^\s]+"#, options: .regularExpression) {
                let streamURL = String(line[range]).trimmingCharacters(in: .init(charactersIn: "\r\n "))
                DispatchQueue.main.async { [weak self] in
                    self?.showTorrentOverlay(status: "stream ready")
                    self?.playMedia(url: streamURL, title: "Torrent")
                }
                pipe.fileHandleForReading.readabilityHandler = nil
            }
        }
        
        p.terminationHandler = { _ in
            try? FileManager.default.removeItem(atPath: "/tmp/webtorrent_stream")
        }
        
        do {
            try p.run()
        } catch {
            showTorrentOverlay(status: "failed to start peerflix: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Helpers
    
    func stopTorrent() {
        Self.swapGeneration += 1
        let hadActiveSession = torrentProcess != nil
            || torrentBrowserPanel != nil
            || !currentTorrentURL.isEmpty

        // Detach pipe handlers before teardown: a handler that outlives
        // the process keeps its captured buffers and the FileHandle alive.
        torrentStdoutPipe?.fileHandleForReading.readabilityHandler = nil
        torrentStderrPipe?.fileHandleForReading.readabilityHandler = nil
        torrentStdoutPipe = nil
        torrentStderrPipe = nil
        torrentStdinPipe = nil
        torrentBrowserPanel?.removeFromSuperview()
        torrentBrowserPanel = nil
        if let proc = torrentProcess {
            proc.terminate()
            // Reap off-main; wt_server's own watchdog exits within seconds.
            DispatchQueue.global(qos: .utility).async { proc.waitUntilExit() }
        }
        torrentProcess = nil
        torrentTitle = ""
        currentTorrentURL = ""

        guard hadActiveSession else { return }

        controller?.spineUI.hideStreamControls()
        controller?.ipcCommand(#"{"command":["script-message-to","photon","set-live","false"]}"#)
        controller?.ipcCommand(#"{"command":["set","hwdec","auto-safe"]}"#)
    }
    
    private func showTorrentOverlay(status: String) {
        controller?.spineUI.showMPVOSD(status)
    }
    
    private func openTorrentBrowserPanel() {
        guard let parentWin = overlayWin, let contentView = parentWin.contentView,
              let ctrl = controller else { return }
        
        let padL: CGFloat = 40; let padR: CGFloat = 54; let padT: CGFloat = 9
        let base = ctrl.appliedVideoFrame == .zero ? contentView.bounds : ctrl.appliedVideoFrame
        let frame = CGRect(x: base.minX + padL, y: base.minY + padT,
                           width: base.width - padL - padR, height: base.height - padT * 2)
        let panel = ArchiveBrowserPanel(frame: frame)
        panel.wantsLayer = true
        panel.layer?.backgroundColor = NSColor.clear.cgColor
        panel.autoresizingMask = [.width, .height]
        panel.onClose = { [weak self] in
            panel.removeFromSuperview()
            self?.torrentProcess?.terminate()
            self?.torrentBrowserPanel = nil
            self?.isShowingInputPanel = false
            self?.overlayWin?.ignoresMouseEvents = false
            if let tap = self?.eventTap { CGEvent.tapEnable(tap: tap, enable: true) }
        }
        torrentBrowserPanel = panel
        contentView.addSubview(panel)
        isShowingInputPanel = true
        setEventTapEnabled(false)
        parentWin.ignoresMouseEvents = false
        _ = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak panel] event in
            if event.keyCode == 53, panel?.superview != nil {
                panel?.removeFromSuperview(); return nil
            }
            return event
        }
    }
    
    
}

// ================================================================
//  String - String
// ================================================================
private extension String {
    func width(using font: NSFont) -> CGFloat {
        (self as NSString).size(withAttributes: [.font: font]).width
    }
}

