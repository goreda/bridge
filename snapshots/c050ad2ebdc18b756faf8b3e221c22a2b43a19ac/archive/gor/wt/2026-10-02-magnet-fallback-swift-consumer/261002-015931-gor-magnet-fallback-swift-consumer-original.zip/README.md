# gor auto magnet fallback: wt v22.6 + Swift consumer (NOT compiled, NOT run on a Mac)

Drop-in tree (paths relative to gor/): Sources/gor/MagnetBrowser.swift, Sources/gor/TorrentManager.swift, Resources/vendor/wt_server/wt_server.mjs (v22.6). Diff of the Swift files: swift_fallback.diff (base: goreda/instinct main as read 2026-10-02).

Flow: wt_server v22.6 prints REQ:magnet-fallback {json} when a waiting reader makes no progress for 90s (120s without metadata), re-emits every 60s. TorrentManager parses it (only if the line comes from the current torrentProcess) and calls MagnetFallbackSearch.shared.handle. That searches 7 providers headless (apibay, bitsearch, magnetz, bt4g, nyaa, knaben, eztv) with "title sXXeYY|year resolution", retries without resolution, drops the current/tried hashes, needs seeds>=2, prefers resolution match then seeds, then app.streamTorrent(magnet) silently, resuming at currentTime-3s.
Guards: one search at a time, 45s cooldown, max 3 swaps per title, dropped if the user changed/stopped the stream during search.

Known limits (read before trusting):
- Never compiled. Review done by reading only (fileprivate access is why the class sits inside MagnetBrowser.swift).
- Candidates without a seed count are excluded (some providers give none). Uindex stays unavailable (cloudflare_unresolved).
- "second-best" is implemented as best eligible after excluding the current and already-tried magnets.
- Resume position assumes the replacement file has the same cut; a different cut will land at the wrong scene.
- A swap shows the normal "connecting to peers" overlay (existing streamTorrent path), it is silent only in that no prompt appears.
- Linux harness proved the wt side only (see previous zip README). Swap race: not reproduced.
