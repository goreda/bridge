# W-0218 photon source-noise: PARTIAL solver candidate v5 (revision of v4-partial after review H0356) (for independent review; not accepted, not published)

This does NOT fix W-0218 overall. It is a bounded set of producer-side changes in photon.lua. Core gaps are listed below.

## Scope and rights
- Baseline: files in src_orig/, taken from the public packet goreda/bridge at pin 3e5b0f43c94b85d5ec761cd40259a906151b29f0, packets/w-0218-photon-source-noise/source/. Packet archive sha256 75bf31f2061ac8fe09368651bdba89bbbb8aff8fc8280204e7fa89f92de9ebf4.
- Changed: src_cand/photon.lua only (patch: w0218-photon-v5.patch, diff -ruN src_orig src_cand). The other four files are byte-identical to baseline.
- The solver-authored changes, tests and runtime scripts here are offered for review only. No license or source right is granted on behalf of the owner or any third party; the baseline source rights stay with their owner. No reviewer script or case text is bundled.
- Nothing here has been published.

## Hashes (sha256)
baseline: photon.lua 7346978487b11c08481546c356b4f014221c0a9fad579486f4cf498e98338860; photon-common 220fa27b886187d69d839a3c67ed3b32d9836bcc748a6535db1a956004082ce6; photon-grain fdf82eb8f86f13da7b205ae920a0a905c8f4b7afab38870ef472b31a2d28a70f; photon-hud fcd543b6e7ed969313fc1f76476f9a00645246f55badcdbc10b6cfd4bb401025; photon-sharp fc460715970776cbc691ecac0b3f61dcfbfaacf8aa21a0e5f6a07cf28c93a647.
candidate v5: photon.lua 063a67c0d2b8ef765770696a6dd5aa3180eea8b9645b3d24e7ed935d74c31c5a (others as baseline). Patch w0218-photon-v5.patch sha256 ec9e565f8396aaa1acd241d8198dcfa2c71b550400e919d8ef675fd31c55c4d9. Previous v4-partial candidate photon.lua was 60b3605dba7fad5e1b13bb8f6e8f76f644517b22e4afd8e0a4f8f2ca3e305d4d.

## v5 changes (after review H0356; v4-partial is superseded)
1. HDR / engine-off seek (reviewer observation 3, confirmed by reading and by mock): the early seek handler cleared the latched feed without publishing, and the later SDR handler returns early on HDR or engine-off. The early handler now publishes the cleared state itself. Tests T22 (hdr, engine-off): v4-partial FAILS 4 checks, v5 passes. Mock only. No runtime run of the HDR path.
2. Manual look learning suppressed the source reading (found by tracing probe to feed in logs/f10_cand.log, my own v4 run): while a manual strength revision is being learned, the probe returns early for 3 samples. Those 3 valid readings (share 0.862, 0.704, 0.705) were neither stored nor cleared, the held reading expired and has_feed went false, then a proxy has_feed=true with noise 0.10 and from_source=false was published; no live source feed for about 16s (t=17.8 to 34.8 in that log). The original source has the same early return. v5 stores the reading before the learning block; the learning block itself is untouched. Test T23: v4-partial fails, v5 passes (mock). Change is one block moved in photon.lua.
3. F10 cause of the HUD strength dropping below 5.0, now diagnosed from logs, both trees: after the 3 learning samples, photon.lua sends photon-grain-strength-resume ("manual strength adopted as look; auto strength resumes", f10_orig.log line 149, f10_cand.log line 162), then later multipliers are applied (original 0.910/0.988 giving 4.369/4.740; candidate 0.948/0.848/0.748/0.648 giving 4.551/4.071/3.591/3.111). The "ignored" lines precede the resume. This is the existing documented learn-then-resume design, identical in the original, not a regression. The injected message was a synthetic harness action; mapping it to the production control-revision path is not done, and learn-then-resume is kept as is.

## What the candidate changes (engineering choices, labeled as such)
- Early sample (0.75s) at load, seek and toggle; overlap guard.
- Seek handler registered early: bumps a capture epoch, clears reading and smoother, drops the latched feed. A capture that finishes after an epoch change is dropped.
- Publish right after a reading is stored or cleared; a 12.05s expiry clears an unrenewed reading.
- Dedicated source-noise smoother (tau 0.5s) instead of the proxy-polluted shared value.
- Retry with backoff {0.5,1,2,2,2,2,2,2}s for capture-not-ready and stall holds.
- Cut-edge invalidation: rising is_cut from the existing detector, 1.0s min gap, bumps epoch, clears reading, drops latched feed, resamples.
- Trace lines W0218-feed/probe/drop/cut; payload bool noise_from_source (observability only, no consumer validates it, so not provenance).
- Receivers (photon-grain, photon-sharp) unchanged. Grain keep-last-good on corrupt input is a documented design and is left as is.

## How to run
- Regression (mock, LuaJIT via lupa): pip install lupa; sh tests/run_tests.sh. Exit 0 requires candidate 44/44 and the grain-receiver characterization to pass. Original tree fails 21/44 (informational). Log: logs/regression_run.txt.
- Runtime (user-space mpv v0.41.0, see BUILD-MPV.md): set MPV and library env, then runtime/run_case.sh PACKET_DIR src_cand CLIP OUT.log [observer variant]. Clips: runtime/make_clips.sh. Variant observers (separate from the pinned one): observer_nocut_seek.lua, observer_f10_manual.lua.

## Runtime evidence (single runs, llvmpipe, 1 visible CPU, about 1s media per 20s wall; wall times are not product latency)
- v4 candidate, 480p pinned clip (logs/pinned480_v4_run.log): first live feed 6.7s after load (C1 <=5s unmet); post-seek live feed 2.5s after the seek event with capture position 8..8 (same-position capture after seek).
- Earlier versions, 480p: original first live 10.8s. Candidate first live 6.4 to 11.8s across runs; post-seek 2.26s, 4.47s, 18.1s, 20.6s (slow cases coincide with playback stalled at the seek position).
- 1080p: no live feed in either tree.
- 2160p: original not run. v2b candidate: one probe took 8.85s and returned an invalid (nil) readback. v4 candidate: not run.
- Cut-early clip (v3 candidate vs original, logs/runtime_cutearly_*.log, timeline_*): single runs, not a root-cause proof. The real is_cut detector never fired in any run in either tree, so cut coverage is mock-only (T20/T21).
- F10 manual override, v4-partial candidate and original (runtime, logs/f10_orig.log and f10_cand.log, observer_f10_manual.lua injects photon-grain-set-strength 5 at 1s after load, 40s run, 480p): in both trees the receiver logs "strength mult received (0.500), ignored due to manual override" and the strength hint ignored, and the grain HUD strength moves 4.800 to 5.000. The later HUD strength drop below 5.0 is explained in v5 change 3 (learn-then-resume, both trees). Per-message ignore: 1 mult ignored then resume, later mults applied, consistent with the log. F10 injection case: suppression before resume is confirmed in both trees. The injection was synthetic; it is not mapped to a production control revision, so F10 is not closed.

## v5 runtime failure observations (480p, F10 observer variant, same clip and backend)
- v5 run 1 (logs/f10_v5cand.log): probes at t=13.6s (7.7s long), 41.2s (3.9s), 60.6s (4.2s), all valid_share=nil; the only W0218-feed line is has_feed=true from_source=false at t=67.5s. No live source feed.
- v5 run 2 (logs/f10_v5cand_run2.log): probes at t=15.3s (0.0s), 19.2s (7.8s), 37.3s (3.2s), 54.3s (5.0s), all valid_share=nil. No W0218-feed line.
- These two runs do not validate v5 changes 1 and 2 at runtime, and their cause is unresolved.
- One bounded comparison with the same observer, clip, backend and environment: original (logs/comparison_orig.log) produced 0 scene-feed and 0 strength-mult events, last playback position 0.70s. v4-partial candidate (logs/comparison_v4partial.log) probed at 15.5s (0.0s), 24.0s (3.2s), 46.4s (5.1s), 63.3s (0.0s), all nil, 0 scene-feed events, last position 0.70s. The earlier original F10 run (logs/f10_orig.log) had 3 strength-mult events and last position 2.30s. So original and v4-partial also produced no valid reading in this later comparison, and playback advanced less (0.70s vs 2.30s of media). This points away from a v5-only regression but does not establish the cause.
- The v4-partial runtime numbers elsewhere in this README belong to v4-partial and are not v5 results. No fresh-frame claim is made for any version.
- v5 1080p and 2160p: not run. v5 480p pinned C1/C2: not run.

Value correlation from the supplied v4-partial logs (probe to feed to consumer; not frame-level or causal proof): logs/pinned480_v4_run.log shows probe valid_share 0.6705 / 0.8188 / 0.9578 / 0.9696 matching W0218-feed raw_share and the consumer scene-feed noise, and consumer strength-mult share 0.671 / 0.819 / 0.958. In logs/f10_cand.log, has_feed=true with from_source=false and noise 0.10 is also seen (t=30.5 and 31.6 consumer time), which shows has_feed alone does not identify a source reading. Nothing in the consumers reads noise_from_source, so provenance is traced but not enforced.
Static fixture (F1): not run in any version of this package. An earlier static-clip runtime result from the v2 checkpoint is a different version and is not part of this package.

## Unresolved requirements (not met)
1. C1: 5s from start unmet in every run here; cause confounded (llvmpipe, timer starvation, probe cost).
2. Post-seek recovery is intermittent.
3. Per-frame source noise is not delivered: held estimates at probe cadence plus a 0.5s smoother. Real provenance is not delivered.
4. Cut readback: capture crossing a cut is open; the detector was never exercised at runtime.
5. A clean/flat source cannot be reported as a valid zero-noise reading (flat gray without noise gives share -7.04, falls back to has_feed=false, mult 1.0). Failure stands.
6. Fallback shader at noise 0.10 attenuates about 0.963 even at x1 (arithmetic from the packet GLSL excerpt; no render A/B, no neutrality claim).
7. Receiver stuck-feed risk is not closed; receivers unchanged.
8. Not run: 10-bit, HDR, rollback F9, noise-32 control, real film grain, real-GPU latency, 1080p/2160p v4.
9. The 12.05s expiry, 0.75s kick, 0.5s tau, backoff and 1.0s cut gap are engineering choices, not owner gates. No "calibrated" claim: smooth_noise is high-pass source-power share with a two-point synthetic characterization.
