# W-0218 photon source-noise: PARTIAL solver candidate v4 (for independent review; not accepted, not published)

This does NOT fix W-0218 overall. It is a bounded set of producer-side changes in photon.lua. Core gaps are listed below.

## Scope and rights
- Baseline: files in src_orig/, taken from the public packet goreda/bridge at pin 3e5b0f43c94b85d5ec761cd40259a906151b29f0, packets/w-0218-photon-source-noise/source/. Packet archive sha256 75bf31f2061ac8fe09368651bdba89bbbb8aff8fc8280204e7fa89f92de9ebf4.
- Changed: src_cand/photon.lua only (patch: w0218-photon-v4.patch, diff -ruN src_orig src_cand). The other four files are byte-identical to baseline.
- The solver-authored changes, tests and runtime scripts here are offered for review only. No license or source right is granted on behalf of the owner or any third party; the baseline source rights stay with their owner. No reviewer script or case text is bundled.
- Nothing here has been published.

## Hashes (sha256)
baseline: photon.lua 7346978487b11c08481546c356b4f014221c0a9fad579486f4cf498e98338860; photon-common 220fa27b886187d69d839a3c67ed3b32d9836bcc748a6535db1a956004082ce6; photon-grain fdf82eb8f86f13da7b205ae920a0a905c8f4b7afab38870ef472b31a2d28a70f; photon-hud fcd543b6e7ed969313fc1f76476f9a00645246f55badcdbc10b6cfd4bb401025; photon-sharp fc460715970776cbc691ecac0b3f61dcfbfaacf8aa21a0e5f6a07cf28c93a647.
candidate: photon.lua 60b3605dba7fad5e1b13bb8f6e8f76f644517b22e4afd8e0a4f8f2ca3e305d4d (others as baseline).

## What the candidate changes (engineering choices, labeled as such)
- Early sample (0.75s) at load, seek and toggle; overlap guard.
- Seek handler registered early: bumps a capture epoch, clears reading and smoother, drops the latched feed. A capture that finishes after an epoch change is dropped.
- Publish right after a reading is stored or cleared; a 12.05s expiry clears an unrenewed reading.
- Dedicated source-noise smoother (tau 0.5s) instead of the proxy-polluted shared value.
- Retry with backoff {0.5,1,2,2,2,2,2,2}s for capture-not-ready and stall holds.
- Cut-edge invalidation: rising is_cut from the existing detector, 1.0s min gap, bumps epoch, clears reading, drops latched feed, resamples.
- Trace lines W0218-feed/probe/drop/cut; payload bool noise_from_source (observability only, no consumer validates it, so not provenance).
- Receivers (photon-grain, photon-sharp) unchanged. Grain keep-last-good on corrupt input is a documented design and is left as is.

## How to run
- Regression (mock, LuaJIT via lupa): pip install lupa; sh tests/run_tests.sh. Exit 0 requires candidate 37/37 and the grain-receiver characterization to pass. Original tree fails 16/37 (informational). Log: logs/regression_run.txt.
- Runtime (user-space mpv v0.41.0, see BUILD-MPV.md): set MPV and library env, then runtime/run_case.sh PACKET_DIR src_cand CLIP OUT.log [observer variant]. Clips: runtime/make_clips.sh. Variant observers (separate from the pinned one): observer_nocut_seek.lua, observer_f10_manual.lua.

## Runtime evidence (single runs, llvmpipe, 1 visible CPU, about 1s media per 20s wall; wall times are not product latency)
- v4 candidate, 480p pinned clip (logs/pinned480_v4_run.log): first live feed 6.7s after load (C1 <=5s unmet); post-seek live feed 2.5s after the seek event with capture position 8..8 (same-position capture after seek).
- Earlier versions, 480p: original first live 10.8s. Candidate first live 6.4 to 11.8s across runs; post-seek 2.26s, 4.47s, 18.1s, 20.6s (slow cases coincide with playback stalled at the seek position).
- 1080p: no live feed in either tree.
- 2160p: original not run. v2b candidate: one probe took 8.85s and returned an invalid (nil) readback. v4 candidate: not run.
- Cut-early clip (v3 candidate vs original, logs/runtime_cutearly_*.log, timeline_*): single runs, not a root-cause proof. The real is_cut detector never fired in any run in either tree, so cut coverage is mock-only (T20/T21).
- F10 manual override (runtime, logs/f10_orig.log and f10_cand.log, observer_f10_manual.lua injects photon-grain-set-strength 5 at 1s after load, 40s run, 480p): in both trees the receiver logs "strength mult received (0.500), ignored due to manual override" and the strength hint ignored, and the grain HUD strength moves 4.800 to 5.000. Later in the run the HUD strength field drops below 5.0 in BOTH trees (original 4.369/4.740; candidate 4.551/4.071/3.591), cause not diagnosed. Candidate saw 5 strength-mult messages after injection, original 3, and only 2 "ignored" log lines appear per run, so per-message suppression is not individually confirmed. F10 is therefore NOT closed.

## Unresolved requirements (not met)
1. C1: 5s from start unmet in every run here; cause confounded (llvmpipe, timer starvation, probe cost).
2. Post-seek recovery is intermittent.
3. Per-frame source noise is not delivered: held estimates at probe cadence plus a 0.5s smoother. Real provenance is not delivered.
4. Cut readback: capture crossing a cut is open; the detector was never exercised at runtime.
5. A clean/flat source cannot be reported as a valid zero-noise reading (flat gray without noise gives share -7.04, falls back to has_feed=false, mult 1.0). Failure stands.
6. Fallback shader at noise 0.10 attenuates about 0.963 even at x1 (arithmetic from the packet GLSL excerpt; no render A/B, no neutrality claim).
7. Receiver stuck-feed risk is not closed; receivers unchanged.
8. Not run: 10-bit, HDR, rollback F9, noise-32 control, real film grain, real-GPU latency, 1080p/2160p v4.
9. The 12.05s expiry, 0.75s kick, 0.5s tau, backoff and 1.0s cut gap are engineering choices, not owner gates. No "calibrated" claim: smooth_noise is high-pass source-power share with a two-point synthetic characterization.
