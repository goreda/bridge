-- Isolated mock harness for photon.lua (W-0218). Loads the production file
-- under a fake `mp`, virtual clock and message log. No production edits.
local H = {}
function H.new(path, scriptdir)
  local now = 0
  local timers, handlers, msgs, props, evh, scriptmsg = {}, {}, {}, {}, {}, {}
  local mp = {opts={['photon-scriptdir']=scriptdir}}
  local function noop() end
  mp.msg = setmetatable({}, {__index=function() return noop end})
  mp.get_opt = function(k) return mp.opts[k] end
  mp.get_time = function() return now end
  mp.get_property_native = function(k) return props[k] end
  mp.get_property = function(k) return props[k] end
  mp.get_property_number = function(k) return props[k] end
  mp.get_property_bool = function(k) return props[k] end
  mp.set_property = noop; mp.set_property_number = noop; mp.set_property_native = noop; mp.set_property_bool=noop
  mp.observe_property = function(name,_,fn) handlers['prop:'..name]=fn end
  mp.register_event = function(n,fn) evh[n]=evh[n] or {}; table.insert(evh[n],fn) end
  mp.register_script_message = function(n,fn) scriptmsg[n]=fn end
  mp.add_key_binding = noop; mp.add_forced_key_binding = noop; mp.register_idle = noop
  mp.command = noop; mp.command_native = function() return {} end; mp.command_native_async = noop
  mp.commandv = function(...) local a={...}; msgs[#msgs+1]=a; return true end
  mp.get_script_name = function() return 'photon' end
  mp.get_script_directory = function() return scriptdir end
  mp.utils = nil
  local function mk(fire, interval)
    local t={at=fire, interval=interval, active=true}
    function t:stop() self.active=false end
    function t:kill() self.active=false end
    function t:resume() self.active=true; self.at=now+(self.interval or 0) end
    return t
  end
  mp.add_timeout = function(d,fn) local t=mk(now+d); t.fn=fn; timers[#timers+1]=t; return t end
  mp.add_periodic_timer = function(d,fn) local t=mk(now+d,d); t.fn=fn; t.periodic=true; timers[#timers+1]=t; return t end
  _G.mp = mp
  package.loaded['mp.utils']={format_json=function() return '{}' end,parse_json=function() return {} end,join_path=function(a,b) return a..'/'..b end,split_path=function(p) return p,'' end,file_info=function() return nil end,getcwd=function() return '/' end,subprocess=function() return {status=0,stdout=''} end,subprocess_detached=noop,readdir=function() return {} end,get_env_list=function() return {} end}
  package.loaded['mp.options']={read_options=noop}
  package.loaded['mp.msg']=mp.msg
  package.loaded['mp.assdraw']={ass_new=function() return setmetatable({}, {__index=function() return noop end}) end}
  local f = assert(loadfile(path))
  local ok, err = pcall(f)
  if not ok then error('load failed: '..tostring(err)) end
  local self={mp=mp, timers=timers, msgs=msgs, evh=evh, scriptmsg=scriptmsg, props=props}
  function self.advance(dt)
    local target=now+dt
    while true do
      local best
      for _,t in ipairs(timers) do if t.active and t.at<=target and (not best or t.at<best.at) then best=t end end
      if not best then break end
      now=best.at
      if best.periodic then best.at=now+best.interval else best.active=false end
      best.fn()
    end
    now=target
  end
  function self.now() return now end
  function self.fire(name,...) for _,fn in ipairs(evh[name] or {}) do fn(...) end end
  function self.feeds()
    local out={}
    for _,m in ipairs(msgs) do if m[1]=='script-message' and m[2]=='photon-scene-feed' then
      local d={} for k,v in tostring(m[3]):gmatch('([%w_]+)=([^;]*)') do d[k]=v end; out[#out+1]=d end end
    return out
  end
  -- upvalue access
  function self.up(fn,name)
    local i=1
    while true do local n,v=debug.getupvalue(fn,i); if not n then return nil end; if n==name then return v,i end; i=i+1 end
  end
  function self.setup(fn,name,val)
    local _,i=self.up(fn,name); assert(i,'no upvalue '..name); debug.setupvalue(fn,i,val)
  end
  return self
end
return H
