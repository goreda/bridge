#!/bin/sh
# Regression run from the extracted bundle. Needs python3 + lupa (pip install lupa).
# Candidate must pass (exit 0). The original tree is run for comparison only: its failures are the
# regression cases the original is EXPECTED to fail; that run never changes the exit status.
HERE=$(cd "$(dirname "$0")" && pwd); ROOT=$(dirname "$HERE")
SRC_CAND=${SRC_CAND:-$ROOT/src_cand}; SRC_ORIG=${SRC_ORIG:-$ROOT/src_orig}
echo "== original tree (informational)"; python3 "$HERE/run_lua.py" "$HERE/test_w0218.lua" "$SRC_ORIG" | grep -E "FAIL|SUMMARY"
echo "== candidate tree"; python3 "$HERE/run_lua.py" "$HERE/test_w0218.lua" "$SRC_CAND"; rc=$?
echo "== grain receiver characterization (documented keep-last-good; expected result asserted, not a fix)"
python3 "$HERE/run_lua.py" "$HERE/test_grain_recv.lua" "$SRC_CAND"; rc2=$?
[ $rc -ne 0 ] && exit $rc
exit $rc2
