package.path=TESTS_DIR..'/?.lua;'..package.path
local H=require('mock_harness')
local dir=ARGV[1]
local results={}
local function check(name,cond,detail) results[#results+1]={name,cond and 'PASS' or 'FAIL',detail or ''}; print(string.format('%-4s %-62s %s',cond and 'PASS' or 'FAIL',name,detail or '')) end

local function fresh()
  local S=H.new(dir..'/photon.lua', dir)
  local GS,seek
  for _,fn in ipairs(S.evh['seek']) do local g=S.up(fn,'GS'); if g then GS=g; seek=fn end end
  S.GS=GS
  local gs_tick=S.up(GS.paced_tick,'gs_tick')
  S.gs_tick=gs_tick
  S.DOC=S.up(gs_tick,'DOC'); S.GR=S.up(gs_tick,'GR'); S.SIZE_GOV=S.up(gs_tick,'SIZE_GOV')
  S.setup(gs_tick,'enabled',true); S.setup(gs_tick,'playback_active',true)
  S.DOC.active=true; S.GR.enabled=true; S.SIZE_GOV.program_on=true
  -- find the publisher
  local function scan(fn) if not fn then return end
    local p=S.up(fn,'photon_publish_scene_feed'); if p then S.pub=S.pub or p end end
  for _,l in pairs(S.evh) do for _,fn in ipairs(l) do scan(fn) end end
  for _,fn in pairs(S.scriptmsg) do scan(fn) end
  for _,t in ipairs(S.timers) do scan(t.fn) end
  -- scripted sample source: queue of {share=,vsrc=,pos=,cost=seconds}
  S.samples={}; S.calls={}
  local function fake()
    local q=table.remove(S.samples,1) or {share=0.4,vsrc=50,pos=S.now()}
    S.calls[#S.calls+1]=S.now()
    if q.during then q.during() end
    S.props['time-pos']=q.pos or (S.now()+1)
    return 1.5,0.8,480,100.0,q.share,q.vsrc
  end
  S.setup(gs_tick,'gs_sample_frame',fake)
  S.DOC.gen=S.DOC.gen or 1
  return S
end
local function lastfeed(S) local f=S.feeds(); return f[#f] end

-- T1: first valid source reading after load must be published within 5s, without a radar tick
do
  local S=fresh()
  local lf=S.evh['file-loaded']; for _,fn in ipairs(S.evh['start-file']) do pcall(fn) end
  for _,fn in ipairs(lf) do pcall(fn) end
  S.advance(5.0)
  local first=S.calls[1]
  check('T1 first source sample taken before 5s of virtual time',first~=nil and first<=5,'first sample at '..tostring(first))
  local f=lastfeed(S)
  check('T1 valid reading published with has_feed=true w/o external tick',f~=nil and f.has_feed=='true','feeds='..#S.feeds())
end
-- T2: seek clears reading; new valid reading and publish within 5s of seek
do
  local S=fresh()
  S.samples={{share=0.4,vsrc=50}}; S.gs_tick(); if S.pub then S.pub() end
  check('T2 pre-seek feed live',(lastfeed(S) or {}).has_feed=='true')
  local n0=#S.calls
  S.fire('seek'); S.advance(5.0)
  check('T2 sample taken within 5s after seek',#S.calls>n0,'calls after seek='..(#S.calls-n0))
  local f=lastfeed(S)
  check('T2 post-seek feed live within 5s',f~=nil and f.has_feed=='true' and (S.GS.last_noise_at or -1)>=0)
end
-- T3: invalid reading must clear feed (no stale latched has_feed)
do
  local S=fresh()
  S.samples={{share=0.4,vsrc=50},{share=0.02,vsrc=1.0,pos=S.now()+5}}
  S.gs_tick(); if S.pub then S.pub() end
  S.advance(1); S.gs_tick(); if S.pub then S.pub() end
  local f=lastfeed(S)
  check('T3 invalid reading clears cache',S.GS.last_noise_share==nil)
  check('T3 invalid reading: published feed is has_feed=false noise=0.1',f~=nil and f.has_feed=='false' and f.smooth_noise=='0.1000',f and (f.has_feed..'/'..f.smooth_noise) or 'nofeed')
end
-- T4: invalid reading must clear feed even if no radar tick runs
do
  local S=fresh()
  S.samples={{share=0.4,vsrc=50},{share=0.02,vsrc=1.0}}
  S.gs_tick(); S.advance(1); S.gs_tick()   -- NO pub() calls
  local f=lastfeed(S)
  check('T4 invalid reading publishes has_feed=false without external tick',f~=nil and f.has_feed=='false','last='..(f and f.has_feed or 'none'))
end
-- T5: stale reading (>12s, no new sample) is not republished as current
do
  local S=fresh()
  if S.GS.timer then S.GS.timer:stop() end   -- playback paused/frozen: no new samples
  S.samples={{share=0.4,vsrc=50}}; S.gs_tick(); if S.pub then S.pub() end
  S.advance(13); if S.pub then S.pub() end
  local f=lastfeed(S)
  check('T5 stale >12s reading drops source feed',f~=nil and f.has_feed=='false','last has_feed='..(f and f.has_feed or 'none'))
end
-- T6: out-of-order completion: sample finishes after document change => dropped
do
  local S=fresh()
  S.samples={{share=0.5,vsrc=60,during=function() S.DOC.gen=S.DOC.gen+1 end}}
  S.gs_tick()
  check('T6 stale-generation sample not stored',S.GS.last_noise_share==nil)
end
-- T7: single flight: re-entrant tick/kick while a probe runs never overlaps
do
  local S=fresh(); local depth,maxd=0,0
  S.samples={{share=0.4,vsrc=50,during=function() depth=depth+1; if depth>maxd then maxd=depth end
     S.GS.paced_tick(); if S.GS.kick then S.GS.kick(0) ; S.advance(0.01) end; depth=depth-1 end}}
  S.GS.paced_tick()
  check('T7 no overlapping probes (max depth 1)',maxd==1,'max depth='..maxd..' calls='..#S.calls)
end
-- T8: manual-identity. Scripted samples with an explicit manual control revision.
-- Reference tuple recorded from the ORIGINAL tree for the same scripted input:
-- (value, doc_gen, name, var_src, share, n, valid, revision) = 0.8000,0,-,50.0000,0.400,1,1,7
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.GR.control_revision=7; S.GR.strength_source='manual'
  S.samples={{share=0.4,vsrc=50},{share=0.4,vsrc=50,pos=S.now()+6},{share=0.4,vsrc=50,pos=S.now()+12}}
  for i=1,3 do S.gs_tick() end
  local sm={}
  for _,m in ipairs(S.msgs) do if m[2]=='photon-grain-set-strength-mult' then sm[#sm+1]=table.concat({m[3],m[4],m[5],m[6],m[7],m[8],m[9],m[10]},',') end end
  check('T8a exactly one strength-mult send (deadband) for 3 equal samples',#sm==1,'sends='..#sm)
  check('T8b strength-mult tuple equals the original-tree reference',sm[1]=='0.8000,0,-,50.0000,0.400,1,1,7',tostring(sm[1]))
  check('T8c revision field carries the control revision (7)',sm[1]~=nil and sm[1]:match(',7$')~=nil)
  check('T8d feed publishing did not alter look_R or consumed revision',S.GS.look_R==nil and S.GS.look_consumed_revision==nil,'look_R='..tostring(S.GS.look_R))
end
-- T8e: non-manual source with a revision never starts look learning
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.GR.control_revision=7; S.GR.strength_source='auto'
  S.samples={{share=0.4,vsrc=50},{share=0.4,vsrc=50,pos=S.now()+6},{share=0.4,vsrc=50,pos=S.now()+12}}
  for i=1,3 do S.gs_tick() end
  check('T8e non-manual source does not start look learning',S.GS.look_learn==nil and S.GS.look_R==nil)
end
-- T9: seek must not leave the frozen-position guard blocking the first post-seek sample
do
  local S=fresh()
  S.props['time-pos']=8.0; S.GS.last_pos=8.0
  S.samples={{share=0.4,vsrc=50,pos=8.0}}
  S.fire('seek'); S.advance(2.0)
  check('T9 post-seek sample at unchanged time-pos is not skipped as frozen',#S.calls>=1,'calls='..#S.calls)
end
-- T10: smoothed feed value converges to the source reading even when the shared
-- smoother is repeatedly pulled toward the radar/PQ proxy (observed 0.97 raw -> 0.53 smooth)
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.samples={{share=0.9,vsrc=50}}; S.gs_tick()
  local pub=S.pub
  local _,iN=S.up(pub,'photon_scene_smooth_noise')
  for i=1,12 do
    S.advance(0.25)
    if iN then debug.setupvalue(pub,iN,0.10) end   -- simulate radar smoothing pull to proxy
    pub()
  end
  local f=lastfeed(S)
  check('T10 smooth_noise converges to source share under proxy pull',f~=nil and math.abs(tonumber(f.smooth_noise)-0.9)<0.05,'smooth='..(f and f.smooth_noise or 'none'))
end
-- T11: seek then invalid then valid: feed never reports a pre-seek value as current
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.samples={{share=0.8,vsrc=50}}; S.gs_tick()
  S.fire('seek')
  S.pub()
  local f=lastfeed(S)
  check('T11 after seek, pre-seek reading is not republished as current',f~=nil and f.has_feed=='false','has_feed='..(f and f.has_feed or 'none'))
end
-- T12: same-document delayed completion spanning a seek must be rejected
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.samples={{share=0.8,vsrc=60,during=function() S.fire('seek') end}}   -- seek lands while the capture is in flight
  S.gs_tick()
  local f=lastfeed(S)
  check('T12 pre-seek capture finishing after a seek (same doc gen) is not stored',S.GS.last_noise_share==nil,'share='..tostring(S.GS.last_noise_share))
  check('T12 ...and no source feed is published from it',f==nil or f.has_feed~='true','has_feed='..(f and f.has_feed or 'none'))
end
-- T13: after the rejected stale capture, the next sample (post-seek) is accepted
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.samples={{share=0.8,vsrc=60,during=function() S.fire('seek') end},{share=0.3,vsrc=40,pos=9.0}}
  S.gs_tick(); S.advance(2)   -- seek-kick takes the next scripted sample
  check('T13 post-seek capture accepted after stale one rejected',S.GS.last_noise_share~=nil and math.abs(S.GS.last_noise_share-0.3)<1e-6,'share='..tostring(S.GS.last_noise_share))
end
-- T14: file-load / adaptive-toggle during an in-flight sample are rejected too
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.samples={{share=0.8,vsrc=60,during=function() S.GS.epoch=(S.GS.epoch or 0)+1 end}}
  S.gs_tick()
  check('T14 epoch bump during sample rejects reading',S.GS.last_noise_share==nil)
end
-- T15: capture not ready (no frame yet) retries within 1s instead of waiting a full interval; bounded
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  local n=0
  local gs_tick=S.gs_tick
  local function notready() n=n+1; S.GS.nil_why='capture-tuple-unbound'; S.props['time-pos']=n; return nil end
  S.setup(gs_tick,'gs_sample_frame',notready)
  S.GS.paced_tick(); S.advance(1.2)
  check('T15 not-ready capture retries within 1.2s',n>=2,'attempts='..n)
  S.advance(60)
  check('T15 retries are bounded (<=1+8)',n<=9,'attempts='..n)
end
-- T16: feeds published by OTHER seek handlers at the seek event must not carry the pre-seek source value.
-- Uses the real SDR seek handler (the one that publishes the scene feed): is_sdr is forced true so it runs.
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  local other
  for _,fn in ipairs(S.evh['seek']) do if S.up(fn,'photon_publish_scene_feed') and not S.up(fn,'GS') then other=fn end end
  check('T16 found the real publishing seek handler',other~=nil)
  if other then
    S.setup(other,'is_sdr',true)
    S.samples={{share=0.8,vsrc=60}}; S.gs_tick()
    if S.pub then S.pub() end                       -- ensure a live source feed existed before the seek
    local n0=#S.feeds()
    S.fire('seek'); S.advance(0.01)
    local fs=S.feeds(); local bad=0
    for i=n0+1,#fs do if fs[i].has_feed=='true' and fs[i].smooth_noise~='0.1000' then bad=bad+1 end end
    check('T16 seek handler published feeds at the seek event (path exercised)',#fs>n0,'new feeds='..(#fs-n0))
    check('T16 none of them carries the pre-seek source value as live',bad==0,'stale='..bad)
  end
end
-- T17: backoff schedule is bounded and increasing (no busy loop) under a persistent not-ready capture
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  local times={}
  local function notready() times[#times+1]=S.now(); S.GS.nil_why='capture-tuple-unbound'; S.props['time-pos']=#times; return nil end
  S.setup(S.gs_tick,'gs_sample_frame',notready)
  S.GS.paced_tick(); S.advance(60)
  local ok=#times<=9
  for i=3,#times do if (times[i]-times[i-1])<(times[i-1]-times[i-2])-1e-9 then ok=false end end
  check('T17 retries bounded (<=9 attempts) with non-decreasing gaps',ok,'attempts='..#times)
  local min=1e9 for i=2,#times do if times[i]-times[i-1]<min then min=times[i]-times[i-1] end end
  check('T17 smallest retry gap >=0.5s (no busy loop)',#times<2 or min>=0.49,'min gap='..string.format('%.2f',min))
end
-- T18: a valid capture resets the retry budget
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  local n=0
  local function sample() n=n+1; S.props['time-pos']=n
    if n==3 then S.GS.nil_why=nil; return 1.5,0.8,480,100.0,0.4,50 end
    S.GS.nil_why='capture-tuple-unbound'; return nil end
  S.setup(S.gs_tick,'gs_sample_frame',sample)
  S.GS.paced_tick(); S.advance(10)
  check('T18 valid capture resets retry budget',S.GS.retry_n==0,'retry_n='..tostring(S.GS.retry_n))
end
-- T19: stall-hold (time-pos frozen) right after a seek retries with backoff instead of waiting a full interval
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  local calls=0
  S.setup(S.gs_tick,'gs_sample_frame',function() calls=calls+1; S.props['time-pos']=100+calls; return 1.5,0.8,480,100.0,0.4,50 end)
  S.props['time-pos']=8.0
  S.fire('seek')               -- early handler bumps the epoch and clears last_pos
  S.advance(0.8)               -- kick fires at 0.75, position 8.0 recorded as last_pos? (first tick samples)
  S.GS.last_pos=8.0; S.props['time-pos']=8.0   -- playback stalled at the seek position
  S.GS.next_probe_at=nil
  S.GS.paced_tick()            -- guard holds: frozen
  local before=calls
  S.props['time-pos']=8.5      -- renderer recovers
  S.advance(3.5)
  check('T19 frozen hold after a seek is retried within 3.5s once position advances',calls>before,'calls before='..before..' after='..calls)
end
-- T20: detector-reported cut (is_cut rising edge) invalidates the held reading and an in-flight capture
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.samples={{share=0.8,vsrc=60}}; S.gs_tick()
  local pub=S.pub
  local _,iC=S.up(pub,'photon_scene_is_cut')
  if not iC then check('T20 publisher exposes photon_scene_is_cut upvalue',false); else
    debug.setupvalue(pub,iC,true); pub()
    local f=lastfeed(S)
    check('T20 cut flag drops the held source feed',S.GS.last_noise_share==nil and f~=nil and f.has_feed=='false' and f.is_cut=='true','has_feed='..(f and f.has_feed or 'none'))
    -- same cut flag still true on the next publish: no second invalidation inside the gap
    local e1=S.GS.epoch; S.advance(0.1); pub()
    check('T20 sustained cut flag does not re-invalidate within the gap',S.GS.epoch==e1)
    -- capture in flight when the cut arrives is rejected
    debug.setupvalue(pub,iC,false); pub(); S.advance(2.0)
    S.samples={{share=0.7,vsrc=60,during=function() debug.setupvalue(pub,iC,true); pub() end}}
    S.gs_tick()
    check('T20 capture in flight across a cut is not stored',S.GS.last_noise_share==nil,'share='..tostring(S.GS.last_noise_share))
    -- an early post-cut capture is accepted
    S.samples={{share=0.3,vsrc=40,pos=50}}; S.advance(2.0)
    check('T20 post-cut capture accepted',S.GS.last_noise_share~=nil and math.abs(S.GS.last_noise_share-0.3)<1e-6,'share='..tostring(S.GS.last_noise_share))
  end
end
-- T21: a large luma change alone is NOT a cut: reading kept (existing luma-step skip only skips that sample)
do
  local S=fresh(); if S.GS.timer then S.GS.timer:stop() end
  S.samples={{share=0.8,vsrc=60}}; S.gs_tick(); local e=S.GS.epoch
  S.pub(); local f=lastfeed(S)
  check('T21 no cut flag: reading stays live and epoch unchanged',f~=nil and f.has_feed=='true' and S.GS.epoch==e)
end
local fails=0
for _,r in ipairs(results) do if r[2]=='FAIL' then fails=fails+1 end end
FAILED_CHECKS=fails
print('SUMMARY fails='..fails..' of '..#results)
