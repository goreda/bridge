#!/usr/bin/env python3
"""Run a Lua test under LuaJIT (lupa). Paths are passed as Lua values, never interpolated as code.
usage: run_lua.py SCRIPT.lua SRC_DIR   -> exit 1 if FAILED_CHECKS > 0"""
import os, sys
from lupa.luajit21 import LuaRuntime
def main():
    script, src = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
    lua = LuaRuntime(unpack_returned_tuples=True)
    g = lua.globals()
    g.TESTS_DIR = os.path.dirname(script)
    g.ARGV = lua.table_from([src])
    g.FAILED_CHECKS = 0
    with open(script, encoding="utf-8") as f:
        code = f.read()
    lua.execute(code)
    n = g.FAILED_CHECKS or 0
    sys.exit(1 if n else 0)
if __name__ == "__main__":
    main()
