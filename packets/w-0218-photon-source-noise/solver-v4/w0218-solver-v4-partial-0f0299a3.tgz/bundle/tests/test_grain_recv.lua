package.path=TESTS_DIR..'/?.lua;'..package.path
local H=require('mock_harness')
local dir=ARGV[1]
local S=H.new(dir..'/photon-grain.lua', dir)
local recv=S.scriptmsg['photon-scene-feed']
assert(recv,'no photon-scene-feed receiver')
local function payload(sn,hf) return 'peak=0.5;contrast=0.35;noise=0.5;smooth_peak=0.5;smooth_contrast=0.35;smooth_noise='..sn..';has_feed='..hf..';fps=24' end
local function level() return S.up(recv,'gr_noise_level') end
local fails=0
local function check(n,c,d) print((c and 'PASS ' or 'FAIL ')..n..' '..(d or '')); if not c then fails=fails+1 end end
recv(payload('0.8','true')); check('R1 valid value applied',math.abs(level()-0.8)<1e-9,tostring(level()))
for _,bad in ipairs({'nan','-0.5','1.5','abc','inf'}) do
  recv(payload('0.8','true')); recv(payload(bad,'true'))
  check('R2 CHARACTERIZATION corrupt "'..bad..'" after 0.8 keeps last good 0.8 (documented receiver design, unchanged)',math.abs(level()-0.8)<1e-9,tostring(level()))
end
recv(payload('0.8','true')); recv(payload('0.30','false'))
check('R3 has_feed=false with proxy value 0.30 is still applied (proxy path preserved)',math.abs(level()-0.30)<1e-9,tostring(level()))
recv(payload('0.0','true')); check('R4 legitimate 0.0 accepted',level()==0.0,tostring(level()))
print('GRAIN-RECV fails='..fails)
FAILED_CHECKS=fails
