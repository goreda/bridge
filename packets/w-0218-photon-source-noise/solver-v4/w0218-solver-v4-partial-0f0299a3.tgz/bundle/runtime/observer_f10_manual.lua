-- VARIANT (F10): observer_nocut_seek + manual photon-grain-set-strength 5 injected at 1s after file-loaded; 40s run.
-- Difference: no seek is issued, so a scene cut in the clip happens during normal playback.
-- It also records the clip-time of each frame position and quits at 20s after file-loaded.
local utils=require('mp.utils')
local started=mp.get_time()
local function record(kind,extra)
 mp.msg.info('HARNESS '..utils.format_json({kind=kind,wall=mp.get_time()-started,position=mp.get_property_number('time-pos'),osd=mp.get_property_native('osd-dimensions'),src=mp.get_property_native('video-dec-params'),extra=extra}))
end
mp.register_event('file-loaded',function()started=mp.get_time();record('file-loaded');mp.add_timeout(1,function()mp.commandv('script-message','photon-grain-set-strength','5');record('INJECT-manual-strength-5')end);mp.add_timeout(40,function()record('finish');mp.commandv('screenshot-to-file',mp.get_opt('harness-shot') or '/tmp/photon118-harness/results/frame.png','window');mp.commandv('quit')end)end)
mp.register_event('seek',function()record('seek')end)
mp.register_event('playback-restart',function()record('restart')end)
mp.register_script_message('photon-grain-hud-state',function(...)record('grain',{...})end)
mp.register_script_message('photon-sharp-hud-state',function(...)record('sharp',{...})end)
mp.observe_property('osd-dimensions','native',function()record('geometry')end)

mp.register_script_message('photon-scene-feed',function(payload)record('scene-feed',{payload})end)
mp.register_script_message('photon-grain-set-strength-mult',function(...)record('strength-mult',{...})end)
mp.register_script_message('photon-grain-size-evidence',function(...)record('size-evidence',{...})end)
mp.observe_property('time-pos','number',function(_,v)if v then record('frame-position',{v})end end)
