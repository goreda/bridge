#!/usr/bin/env python3
"""Print a compact event timeline from a harness stdout.log (HARNESS lines + photon trace lines)."""
import json,sys
def kv(p): return dict(x.split('=',1) for x in p.split(';') if '=' in x)
for l in open(sys.argv[1]):
    if 'HARNESS {' in l:
        try: x=json.loads(l[l.index('{'):])
        except ValueError: continue
        k=x['kind']
        if k in('file-loaded','seek-request','seek','restart','finish'): print(f"{x['wall']:8.3f} {k} pos={x.get('position')}")
        elif k=='scene-feed':
            d=kv(x['extra'][0]); print(f"{x['wall']:8.3f} feed has_feed={d.get('has_feed')} is_cut={d.get('is_cut')} noise={d.get('noise')} smooth={d.get('smooth_noise')}")
        elif k=='strength-mult': print(f"{x['wall']:8.3f} mult {x['extra']}")
    elif 'W0218-' in l: print('        '+l.strip()[:150])
