#!/bin/sh
# Builds the synthetic clips used in the W0218 diagnostic runs from the pinned 480p media.
# usage: make_clips.sh PINNED_480P.mp4 OUTDIR   (needs ffmpeg)
set -eu
IN=$1; OUT=$2; mkdir -p "$OUT"
ffmpeg -loglevel error -y -i "$IN" -frames:v 1 "$OUT/still.png"
ffmpeg -loglevel error -y -loop 1 -i "$OUT/still.png" -t 12 -r 24 -c:v libx264 -preset veryfast -crf 14 -pix_fmt yuv420p -an "$OUT/still.mp4"
for s in 0 16; do ffmpeg -loglevel error -y -f lavfi -i "color=c=gray:s=854x480:r=24:d=10,noise=alls=$s:allf=t+u" -c:v libx264 -preset veryfast -crf 14 -pix_fmt yuv420p -an "$OUT/flat_n$s.mp4"; done
# real scene cut at 5s of playback: NASA480 then noisy gray
ffmpeg -loglevel error -y -t 5 -i "$IN" -f lavfi -t 12 -i "color=c=gray:s=854x480:r=24000/1001,noise=alls=12:allf=t+u" -filter_complex "[0:v]fps=24000/1001,setsar=1[a];[1:v]setsar=1[b];[a][b]concat=n=2:v=1:a=0" -c:v libx264 -preset veryfast -crf 14 -pix_fmt yuv420p -an "$OUT/cut.mp4"
