#!/bin/sh
# Run one pinned-harness style case with a configurable mpv, source directory, clip and observer.
# usage: run_case.sh PACKET_DIR SRC_DIR CLIP.mp4 OUT.log [OBSERVER.lua]
#   PACKET_DIR  extracted packet (has harness/, source/, media/)
#   MPV         path to mpv (env, required). Caller sets LD_LIBRARY_PATH, LIBGL_DRIVERS_PATH,
#               __EGL_VENDOR_LIBRARY_FILENAMES if the build needs them (see BUILD-MPV.md).
#   Needs Xvfb, python3. Uses a private work dir; the packet tree is not modified.
set -eu
: "${MPV:?set MPV to the mpv binary}"
PK=$(cd "$1" && pwd); SRC=$(cd "$2" && pwd); CLIP=$(readlink -f "$3"); OUT=$4; OBS=${5:-}
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
mkdir -p "$W/media"; cp -r "$PK/harness" "$W/harness"; cp -r "$SRC" "$W/source"; cp "$CLIP" "$W/media/480p.mp4"
[ -n "$OBS" ] && cp "$OBS" "$W/harness/observer.lua"
( cd "$W" && python3 harness/run.py 480 on )
cp "$W/results/480-photon/stdout.log" "$OUT"
