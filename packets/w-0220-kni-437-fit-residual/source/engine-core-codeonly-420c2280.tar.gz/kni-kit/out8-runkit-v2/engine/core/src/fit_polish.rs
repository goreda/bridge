//! Card 437: generic post-fit integer polish of emitted rings.
//!
//! Measured loss anatomy on Marq Alternate (2026-10-24, HEAD 421cc5d8): the
//! capture stage is near-perfect (IoU 0.999354), ALL remaining IoU loss sits
//! in the float cubic-fit stage, and integer export rounding is pixel-free
//! (xor fit->round = 0). The float fit converges within its gate but lands
//! systematic sub-pixel offsets on thin/straight strokes and small
//! diacritics; at 3-4 px glyph widths a half-pixel offset costs >2% IoU.
//!
//! This pass is the generic fix: a deterministic coordinate descent on the
//! EMITTED integer rings, moving nodes and cubic controls by +-1 font unit,
//! minimising a VECTOR objective - the symmetric mean squared distance
//! between the flattened emitted outline and the captured (pre-RDP) source
//! polyline in pixel space. It is not a raster-IoU fit and not a rounding
//! correction: rounding is lossless on this path, so the descent targets
//! genuine fit misplacement only.
//!
//! Guarantees (enforced per accepted move, not by convention):
//! - node count and span structure never change (moves only edit coordinates);
//! - every coordinate stays on the integer emission grid (steps of exactly 1);
//! - the vector objective strictly decreases on every accepted move;
//! - lever_api::missing_extrema never increases for any polished ring;
//! - deterministic: fixed scan order (ring, point, direction), strict `<`
//!   acceptance, no randomness, no floating-point accumulation order changes.
//!
//!
//! Root cause of the observed per-glyph regressions (uni00B9 -0.0225,
//! quotesingle, fraction, bar, t, Lslash, H, uni2082): the traced raw
//! boundary is the iso-0.5 contour of the interpolated thresholded ink
//! field, and on a near-straight edge it sits ON the pixel edge between the
//! last ink sample and the first background sample (measured: uni00B9 right
//! stem edge traces at canvas x=764.496). The raster metric covers a pixel
//! iff its CENTER lies inside the emitted outline (centers at half-integer
//! canvas coordinates, nonzero winding), so a symmetric distance objective
//! can pull an edge onto or past the traced pixel edge and flip background
//! pixel centers into coverage: the vector objective improves while raster
//! IoU regresses. Two acceptance guards close this, adding no constants of
//! their own:
//! - coverage guard: a move may not increase the number of measured sample
//!   points (the capture's own thresholded ink field at the evaluator's
//!   pixel centers) whose emitted inside/outside decision disagrees with
//!   the measurement. The winding raster and crossing rule replicate
//!   ProductionEvaluator::render_mask exactly.
//! - join guard: a move may not change the emitted outline's join
//!   semantics: the corner/smooth classification at every node (turn angle
//!   against the acceptance metric's 10-degree tangent tolerance, the same
//!   constant the measurement harness uses) and the turn orientation.
//!
//! Wired as the final stage of fit_captured_economy_observed so every
//! fit_captured* entry point receives it; font-, style- and glyph-agnostic.
use crate::capture::CapturedRing;
use crate::reference_slice::{Point, ReferenceRing, Span};
use std::cell::RefCell;
use std::rc::Rc;

/// Flatten density for the objective's emitted-outline polyline (segments
/// per cubic span). Matches the evaluation flatten density (32) so the
/// objective measures the outline the evaluator actually renders.
pub const FLATTEN_STEPS: usize = 32;
/// Maximum full coordinate-descent sweeps per glyph. The prototype
/// converged within 2; 3 gives margin without changing results.
pub const MAX_SWEEPS: usize = 3;

#[derive(Clone, Copy, Debug, Default)]
pub struct PolishStats {
    pub rings_polished: usize,
    pub moves_accepted: usize,
    pub objective_before: f64,
    pub objective_after: f64,
}

fn dist_seg(p: Point, a: Point, b: Point) -> f64 {
    let dx = b.x - a.x;
    let dy = b.y - a.y;
    let l2 = dx * dx + dy * dy;
    let t = if l2 == 0.0 {
        0.0
    } else {
        (((p.x - a.x) * dx + (p.y - a.y) * dy) / l2).clamp(0.0, 1.0)
    };
    let (cx, cy) = (a.x + t * dx, a.y + t * dy);
    (p.x - cx).powi(2) + (p.y - cy).powi(2)
}

/// Squared distance from p to the closed polyline (segments i -> i+1 mod n).
fn dist_sq_poly(p: Point, poly: &[Point]) -> f64 {
    let n = poly.len();
    if n == 0 {
        return 0.0;
    }
    if n == 1 {
        return (p.x - poly[0].x).powi(2) + (p.y - poly[0].y).powi(2);
    }
    (0..n)
        .map(|i| dist_seg(p, poly[i], poly[(i + 1) % n]))
        .fold(f64::INFINITY, f64::min)
}

fn cubic(q: &[Point; 4], t: f64) -> Point {
    let v = 1.0 - t;
    let b = [v * v * v, 3.0 * t * v * v, 3.0 * t * t * v, t * t * t];
    Point {
        x: b[0] * q[0].x + b[1] * q[1].x + b[2] * q[2].x + b[3] * q[3].x,
        y: b[0] * q[0].y + b[1] * q[1].y + b[2] * q[2].y + b[3] * q[3].y,
    }
}

/// Flatten one emitted ring to a closed polyline in PIXEL space (/ scale).
fn flatten_ring_px(r: &ReferenceRing, scale: f64, steps: usize) -> Vec<Point> {
    let mut out = Vec::new();
    let mut cur = r.start;
    for s in &r.spans {
        match s {
            Span::Line { end } => {
                out.push(*end);
                cur = *end;
            }
            Span::Cubic { control_one, control_two, end } => {
                let q = [cur, *control_one, *control_two, *end];
                for i in 1..=steps {
                    out.push(cubic(&q, i as f64 / steps as f64));
                }
                cur = *end;
            }
        }
    }
    for p in &mut out {
        p.x /= scale;
        p.y /= scale;
    }
    out
}

/// Flatten one span exactly as flatten_ring_px does (same t grid, same
/// scale division), so incremental re-flattening is bit-identical.
fn flatten_span_px(start: Point, s: &Span, scale: f64, steps: usize) -> Vec<Point> {
    match s {
        Span::Line { end } => vec![Point { x: end.x / scale, y: end.y / scale }],
        Span::Cubic { control_one, control_two, end } => {
            let q = [start, *control_one, *control_two, *end];
            (1..=steps)
                .map(|i| {
                    let p = cubic(&q, i as f64 / steps as f64);
                    Point { x: p.x / scale, y: p.y / scale }
                })
                .collect()
        }
    }
}

/// Span indices whose flattened chunks change when movable point `idx`
/// moves. Mirrors the indexing of movable_points/apply_move exactly.
fn affected_spans(r: &ReferenceRing, idx: usize) -> Vec<usize> {
    let n = r.spans.len();
    if idx == 0 {
        let closed = r.spans.last().map_or(false, |s| end_of(s) == r.start);
        return if closed && n > 1 { vec![0, n - 1] } else { vec![0] };
    }
    let mut cur = 1usize;
    for (si, sp) in r.spans.iter().enumerate() {
        let pts = match sp {
            Span::Line { .. } => 1,
            Span::Cubic { .. } => 3,
        };
        if idx >= cur && idx < cur + pts {
            let is_end = idx == cur + pts - 1;
            if is_end {
                // The moved end is also the first endpoint of the following
                // span's first column segment (wrapping for the last span).
                let next = (si + 1) % n;
                return if next == si { vec![si] } else { vec![si, next] };
            }
            return vec![si];
        }
        cur += pts;
    }
    unreachable!("point index out of range")
}

/// Decision-identical cached objective for one ring. The descent evaluates
/// ~points x 4 candidates; each candidate moves one coordinate, which
/// changes only the flattened chunks of the one or two spans containing
/// that coordinate. The objective decomposes as
///   sum_raw min_over_segments d(raw_p, seg) + sum_flat d(flat_q, raw),
/// and the segment set partitions by span (segment k = flat[k]->flat[k+1]
/// assigned to the span whose chunk contains its SECOND endpoint), so a
/// candidate recomputes only the affected spans' columns. min over a
/// partition is exact, and both sums iterate in the same order as the
/// direct computation, so cached values are BIT-IDENTICAL to
/// ring_objective_poly on a full re-flatten.
struct RingOpt {
    chunks: Vec<Vec<Point>>,
    starts: Vec<usize>,
    flat: Vec<Point>,
    span_mins: Vec<f64>, // raw.len() rows x nspans cols, row-major
    contrib: Vec<f64>,   // per flat point: dist to raw polyline
    obj: f64,
}

impl RingOpt {
    fn new(raw: &[Point], ring: &ReferenceRing, scale: f64) -> Self {
        let mut chunks = Vec::with_capacity(ring.spans.len());
        let mut cur = ring.start;
        for sp in &ring.spans {
            let ch = flatten_span_px(cur, sp, scale, FLATTEN_STEPS);
            cur = end_of(sp);
            chunks.push(ch);
        }
        let mut starts = Vec::with_capacity(chunks.len());
        let mut flat = Vec::new();
        for ch in &chunks {
            starts.push(flat.len());
            flat.extend_from_slice(ch);
        }
        let mut o = RingOpt {
            chunks,
            starts,
            flat,
            span_mins: Vec::new(),
            contrib: Vec::new(),
            obj: 0.0,
        };
        o.span_mins = (0..raw.len() * o.chunks.len().max(1)).map(|_| 0.0).collect();
        for s in 0..o.chunks.len() {
            o.recompute_col(raw, s);
        }
        o.contrib = o.flat.iter().map(|q| dist_sq_poly(*q, raw)).collect();
        // One accumulator across both terms, raw first then flat in index
        // order: identical operation order to ring_objective_poly.
        let mut sum = o.raw_term(raw);
        for c in &o.contrib {
            sum += *c;
        }
        o.obj = sum;
        o
    }
    /// Segment first-indices whose second endpoint lies in span s's chunk.
    fn col_segments(&self, s: usize) -> impl Iterator<Item = (Point, Point)> + '_ {
        let n = self.flat.len();
        let lo = self.starts[s];
        let hi = lo + self.chunks[s].len();
        (lo..hi).map(move |k1| {
            let k = if k1 == 0 { n - 1 } else { k1 - 1 };
            (self.flat[k], self.flat[k1 % n])
        })
    }
    fn recompute_col(&mut self, raw: &[Point], s: usize) {
        let nspans = self.chunks.len();
        for (p, rp) in raw.iter().enumerate() {
            let mut m = f64::INFINITY;
            for (a, b) in self.col_segments(s) {
                m = m.min(dist_seg(*rp, a, b));
            }
            self.span_mins[p * nspans + s] = m;
        }
    }
    fn raw_term(&self, raw: &[Point]) -> f64 {
        let nspans = self.chunks.len();
        let mut sum = 0.0;
        for p in 0..raw.len() {
            let mut m = f64::INFINITY;
            for s in 0..nspans {
                m = m.min(self.span_mins[p * nspans + s]);
            }
            sum += m;
        }
        sum
    }
    /// Evaluate the objective after a hypothetical move affecting spans `a`,
    /// without mutating the cache. Returns (flat_new, obj_new).
    fn candidate(
        &self,
        raw: &[Point],
        ring: &ReferenceRing,
        scale: f64,
        a: &[usize],
    ) -> (Vec<Point>, f64) {
        let nspans = self.chunks.len();
        let mut flat_new = self.flat.clone();
        for &s in a {
            let start = if s == 0 { ring.start } else { end_of(&ring.spans[s - 1]) };
            let ch = flatten_span_px(start, &ring.spans[s], scale, FLATTEN_STEPS);
            flat_new.splice(self.starts[s]..self.starts[s] + self.chunks[s].len(), ch);
        }
        let n = flat_new.len();
        let raw_term = {
            let mut sum = 0.0;
            for (p, rp) in raw.iter().enumerate() {
                let mut m = f64::INFINITY;
                for s in 0..nspans {
                    if a.contains(&s) {
                        let lo = self.starts[s];
                        let hi = lo + self.chunks[s].len();
                        for k1 in lo..hi {
                            let k = if k1 == 0 { n - 1 } else { k1 - 1 };
                            m = m.min(dist_seg(*rp, flat_new[k], flat_new[k1 % n]));
                        }
                    } else {
                        m = m.min(self.span_mins[p * nspans + s]);
                    }
                }
                sum += m;
            }
            sum
        };
        let mut sum = raw_term;
        for (q, fq) in flat_new.iter().enumerate() {
            let in_affected = a
                .iter()
                .any(|&s| q >= self.starts[s] && q < self.starts[s] + self.chunks[s].len());
            sum += if in_affected {
                dist_sq_poly(*fq, raw)
            } else {
                self.contrib[q]
            };
        }
        (flat_new, sum)
    }
    /// Commit an accepted candidate: splice chunks, refresh affected columns
    /// and contributions, adopt obj_new.
    fn commit(&mut self, raw: &[Point], ring: &ReferenceRing, scale: f64, a: &[usize], flat_new: Vec<Point>, obj_new: f64) {
        for &s in a {
            let start = if s == 0 { ring.start } else { end_of(&ring.spans[s - 1]) };
            self.chunks[s] = flatten_span_px(start, &ring.spans[s], scale, FLATTEN_STEPS);
        }
        self.flat = flat_new;
        for &s in a {
            self.recompute_col(raw, s);
        }
        for &s in a {
            for q in self.starts[s]..self.starts[s] + self.chunks[s].len() {
                self.contrib[q] = dist_sq_poly(self.flat[q], raw);
            }
        }
        self.obj = obj_new;
    }
}

/// One ring's contribution to the objective numerator (symmetric squared
/// distance sums, un-normalized). The descent accepts on this directly: the
/// full objective is sum(contributions)/count, count is move-invariant, and
/// a move touches only its own ring, so per-ring comparison yields identical
/// accept/reject decisions at a fraction of the cost.
fn ring_objective_poly(raw: &[Point], poly: &[Point]) -> f64 {
    if raw.is_empty() {
        return 0.0;
    }
    let mut sum = 0.0;
    for p in raw.iter() {
        sum += dist_sq_poly(*p, poly);
    }
    for p in poly {
        sum += dist_sq_poly(*p, raw);
    }
    sum
}

/// Symmetric mean squared distance between emitted rings (flattened, px) and
/// the captured source polylines. Lower is a closer vector fit to the source.
pub fn polish_objective(raw: &[Vec<Point>], rings: &[ReferenceRing], scale: f64) -> f64 {
    let mut sum = 0.0;
    let mut count = 0usize;
    for (r, ring) in raw.iter().zip(rings.iter()) {
        if r.is_empty() {
            continue;
        }
        let poly = flatten_ring_px(ring, scale, FLATTEN_STEPS);
        count += r.len() + poly.len();
        for p in r.iter() {
            sum += dist_sq_poly(*p, &poly);
        }
        for p in &poly {
            sum += dist_sq_poly(*p, r);
        }
    }
    sum / count.max(1) as f64
}

/// Indices of movable coordinates: (ring, point) where point 0 is the ring
/// start and per span a cubic contributes (c1, c2, end), a line (end).
/// The closing end of a closed ring (last span end == start) is the SAME
/// point as the start: it is not listed separately, and get_pt moves both
/// together, so a polish move can never open a closed ring.
fn movable_points(rings: &[ReferenceRing]) -> Vec<(usize, usize)> {
    let mut v = Vec::new();
    for (ri, r) in rings.iter().enumerate() {
        v.push((ri, 0));
        let mut idx = 1;
        let n = r.spans.len();
        for (si, s) in r.spans.iter().enumerate() {
            let closing = si == n - 1 && end_of(s) == r.start;
            match s {
                Span::Line { .. } => {
                    if !closing {
                        v.push((ri, idx));
                    }
                    idx += 1;
                }
                Span::Cubic { .. } => {
                    v.push((ri, idx));
                    v.push((ri, idx + 1));
                    if !closing {
                        v.push((ri, idx + 2));
                    }
                    idx += 3;
                }
            }
        }
    }
    v
}

fn end_of(s: &Span) -> Point {
    match s {
        Span::Line { end } | Span::Cubic { end, .. } => *end,
    }
}

fn apply_move(rings: &mut [ReferenceRing], ri: usize, idx: usize, dx: f64, dy: f64) {
    if idx == 0 {
        // The start and the closing end are one logical point; move both.
        let closed = rings[ri]
            .spans
            .last()
            .map_or(false, |s| end_of(s) == rings[ri].start);
        {
            let p = &mut rings[ri].start;
            p.x += dx;
            p.y += dy;
        }
        if closed {
            let new_start = rings[ri].start;
            match rings[ri].spans.last_mut() {
                Some(Span::Line { end }) | Some(Span::Cubic { end, .. }) => *end = new_start,
                None => {}
            }
        }
        return;
    }
    let p = get_pt(rings, ri, idx);
    p.x += dx;
    p.y += dy;
}

fn get_pt(rings: &mut [ReferenceRing], ri: usize, mut idx: usize) -> &mut Point {
    if idx == 0 {
        return &mut rings[ri].start;
    }
    idx -= 1;
    for s in rings[ri].spans.iter_mut() {
        match s {
            Span::Line { end } => {
                if idx == 0 {
                    return end;
                }
                idx -= 1;
            }
            Span::Cubic { control_one, control_two, end } => {
                if idx == 0 {
                    return control_one;
                }
                if idx == 1 {
                    return control_two;
                }
                if idx == 2 {
                    return end;
                }
                idx -= 3;
            }
        }
    }
    unreachable!("point index out of range")
}

fn all_integer(rings: &[ReferenceRing]) -> bool {
    let ok = |p: &Point| p.x.is_finite() && p.x == p.x.round() && p.y.is_finite() && p.y == p.y.round();
    rings.iter().all(|r| {
        ok(&r.start)
            && r.spans.iter().all(|s| match s {
                Span::Line { end } => ok(end),
                Span::Cubic { control_one, control_two, end } => {
                    ok(control_one) && ok(control_two) && ok(end)
                }
            })
    })
}

/// Polish emitted integer rings against their captured source polylines.
///
/// `rings` are the final emitted rings (integer grid); `captured` are the
/// same glyph's CapturedRings in capture (pixel) space; `scale` maps pixels
/// to font units. Rings are aligned to captures by nearest start point
/// (one-to-one, in emitted order); captures with no partner are ignored.
/// Non-integer input (a caller outside the canonical emission path) is left
/// untouched - the pass is defined on the integer emission grid only.
/// Polish with an EXPLICIT per-ring capture index (engine wiring). Emitted
/// ring i is polished against captured[src_index[i]]; no geometric matching
/// is needed because fit_captured_economy_observed pushes output rings in
/// captured-ring order (dropped specks push nothing). Nearest-start matching
/// is unsound in multi-ring glyphs: the fitted start point of an outer ring
/// can sit nearer to a counter ring's start than to its own (measured on
/// Marq Alternate 'o' 2026-10-25, which mismatched and regressed IoU).
/// The capture's own measured ink field, made available to the coverage
/// guard by callers fitting a real capture. Mirrors the RawRingScope
/// pattern: entered by the fit caller, dropped after the fit.
pub struct CaptureInk {
    pub width: usize,
    pub height: usize,
    pub origin_x: f64,
    pub origin_y: f64,
    /// Sample at (row*r, col*c): 1 when the capture measured ink (gray<128).
    pub ink: Rc<Vec<u8>>,
}

thread_local! { static CAPTURE_INK: RefCell<Option<CaptureInk>> = const { RefCell::new(None) }; }

pub struct CaptureInkScope;
impl CaptureInkScope {
    pub fn enter(ci: CaptureInk) -> Self {
        CAPTURE_INK.with(|c| *c.borrow_mut() = Some(ci));
        CaptureInkScope
    }
    /// Enter from a real capture; None (guard inactive) for synthetic
    /// contours that carry no measured ink field.
    pub fn from_contour(c: &crate::capture::MeasuredContour) -> Option<Self> {
        if c.ink.len() != c.width * c.height || c.ink.is_empty() {
            return None;
        }
        Some(Self::enter(CaptureInk {
            width: c.width,
            height: c.height,
            origin_x: c.origin_x,
            origin_y: c.origin_y,
            ink: Rc::new(c.ink.clone()),
        }))
    }
}
impl Drop for CaptureInkScope {
    fn drop(&mut self) {
        CAPTURE_INK.with(|c| *c.borrow_mut() = None);
    }
}

/// The acceptance metric's tangent tolerance (degrees): the measurement
/// harness classifies a join as a corner when the turn angle across the node
/// meets or exceeds this. Reused here, not invented.
const JOIN_GUARD_TURN_DEG: f64 = 10.0;

/// A sample center changes coverage only if the outline crosses it. A
/// candidate move shifts the flattened outline by at most the 1-unit integer
/// step (0.585 px at the population's K); this band covers that with margin.
const COVERAGE_BAND: f64 = 2.0;

/// Winding raster replicating ProductionEvaluator::render_mask: canvas
/// coordinates x = q.x + ox, y = -q.y - oy; scanline samples at half-integer
/// centers; nonzero winding. Stores the winding number per pixel so a
/// candidate move can be delta-evaluated against only its moved segments.
struct CoverageGuard {
    w: usize,
    h: usize,
    ox: f64,
    oy: f64,
    ink: Rc<Vec<u8>>,
    wind: Vec<i16>,
}

impl CoverageGuard {
    fn new(ci: &CaptureInk, flat: &[Vec<Point>]) -> Self {
        let mut g = CoverageGuard {
            w: ci.width,
            h: ci.height,
            ox: ci.origin_x,
            oy: ci.origin_y,
            ink: ci.ink.clone(),
            wind: vec![0i16; ci.width * ci.height],
        };
        g.refill_rows(flat, 0, ci.height);
        g
    }
    /// Winding delta of one edge set at scanline yc, crossings with x <= cx.
    /// Exact replica of the evaluator's crossing rule.
    fn wind_at(segs: &[(Point, Point)], ox: f64, oy: f64, cx: f64, cy: f64) -> i32 {
        let mut wind = 0i32;
        for (a, b) in segs {
            let (ay, by) = (-a.y - oy, -b.y - oy);
            if (ay <= cy) != (by <= cy) {
                let x = (a.x + ox) + (cy - ay) / (by - ay) * (b.x - a.x);
                if x <= cx {
                    wind += if by > ay { 1 } else { -1 };
                }
            }
        }
        wind
    }
    fn refill_rows(&mut self, flat: &[Vec<Point>], row0: usize, row1: usize) {
        for r in row0..row1.min(self.h) {
            let yc = r as f64 + 0.5;
            let mut xs: Vec<(f64, i32)> = Vec::new();
            for ring in flat {
                let n = ring.len();
                if n < 2 {
                    continue;
                }
                for i in 0..n {
                    let a = ring[i];
                    let b = ring[(i + 1) % n];
                    let (ay, by) = (-a.y - self.oy, -b.y - self.oy);
                    if (ay <= yc) != (by <= yc) {
                        let x = (a.x + self.ox) + (yc - ay) / (by - ay) * (b.x - a.x);
                        xs.push((x, if by > ay { 1 } else { -1 }));
                    }
                }
            }
            xs.sort_unstable_by(|p, q| p.0.partial_cmp(&q.0).unwrap_or(std::cmp::Ordering::Equal));
            let mut wind = 0i16;
            let mut k = 0usize;
            for c in 0..self.w {
                let cx = c as f64 + 0.5;
                while k < xs.len() && xs[k].0 <= cx {
                    wind += xs[k].1 as i16;
                    k += 1;
                }
                self.wind[r * self.w + c] = wind;
            }
        }
    }
    /// Segments whose endpoints differ between two flattenings of the same
    /// ring (one candidate move): old and new versions, aligned.
    fn moved_segments(old: &[Point], new: &[Point]) -> (Vec<(Point, Point)>, Vec<(Point, Point)>) {
        let n = old.len().min(new.len());
        let (mut o, mut w) = (Vec::new(), Vec::new());
        for i in 0..n {
            let j = (i + 1) % n;
            if old[i] != new[i] || old[j] != new[j] {
                o.push((old[i], old[j]));
                w.push((new[i], new[j]));
            }
        }
        (o, w)
    }
    /// Sample centers within COVERAGE_BAND of any segment, deduped.
    fn band_centers(&self, segs: &[(Point, Point)]) -> Vec<(usize, usize)> {
        let mut out = Vec::new();
        for (a, b) in segs {
            let (ax, bx) = (a.x + self.ox, b.x + self.ox);
            let (ay, by) = (-a.y - self.oy, -b.y - self.oy);
            let c0 = (ax.min(bx) - COVERAGE_BAND - 0.5).floor().max(0.0) as usize;
            let c1 = (ax.max(bx) + COVERAGE_BAND - 0.5).ceil().min(self.w as f64 - 1.0).max(0.0) as usize;
            let r0 = (ay.min(by) - COVERAGE_BAND - 0.5).floor().max(0.0) as usize;
            let r1 = (ay.max(by) + COVERAGE_BAND - 0.5).ceil().min(self.h as f64 - 1.0).max(0.0) as usize;
            for r in r0..=r1 {
                for c in c0..=c1 {
                    let px = c as f64 + 0.5 - self.ox;
                    let py = -(r as f64 + 0.5) - self.oy;
                    if dist_seg(Point { x: px, y: py }, *a, *b) <= COVERAGE_BAND {
                        out.push((r, c));
                    }
                }
            }
        }
        out.sort_unstable();
        out.dedup();
        out
    }
    /// Refuse when the candidate increases disagreement with the measured
    /// ink field at sample centers the move could flip.
    fn allows(&self, old_flat: &[Point], new_flat: &[Point]) -> bool {
        let (old_segs, new_segs) = Self::moved_segments(old_flat, new_flat);
        if old_segs.is_empty() {
            return true;
        }
        let mut both: Vec<(Point, Point)> = old_segs.clone();
        both.extend(new_segs.iter().cloned());
        let centers = self.band_centers(&both);
        let (mut old_mis, mut new_mis) = (0usize, 0usize);
        for (r, c) in centers {
            let (cx, cy) = (c as f64 + 0.5, r as f64 + 0.5);
            let w0 = self.wind[r * self.w + c] as i32;
            let delta = Self::wind_at(&new_segs, self.ox, self.oy, cx, cy)
                - Self::wind_at(&old_segs, self.ox, self.oy, cx, cy);
            let ink = self.ink[r * self.w + c] == 1;
            if (w0 != 0) != ink {
                old_mis += 1;
            }
            if ((w0 + delta) != 0) != ink {
                new_mis += 1;
            }
        }
        new_mis <= old_mis
    }
    /// After a committed move, refresh rows its segments touched.
    fn commit(&mut self, flat_all: &[Vec<Point>], old_flat: &[Point], new_flat: &[Point]) {
        let (old_segs, new_segs) = Self::moved_segments(old_flat, new_flat);
        let mut r0 = self.h;
        let mut r1 = 0usize;
        for (a, b) in old_segs.iter().chain(new_segs.iter()) {
            let (ay, by) = (-a.y - self.oy, -b.y - self.oy);
            let hi = (ay.min(by) - COVERAGE_BAND - 0.5).floor().max(0.0) as usize;
            let lo = (ay.max(by) + COVERAGE_BAND + 0.5).ceil().min(self.h as f64) as usize;
            r0 = r0.min(hi);
            r1 = r1.max(lo);
        }
        if r0 < r1 {
            self.refill_rows(flat_all, r0, r1);
        }
    }
}

/// Join semantics of every emitted node: the acceptance metric's corner
/// classification. This replicates race_external's join_metrics EXACTLY:
/// true span tangents (cubic: handle direction; line: chord), corner when
/// the turn angle strictly exceeds JOIN_GUARD_TURN_DEG, zero-length tangent
/// counts as corner. Node i is the end of span i. A polish move must
/// preserve this vector exactly.
fn join_signature(r: &ReferenceRing) -> Vec<(bool, bool, bool)> {
    let n = r.spans.len();
    let tol = JOIN_GUARD_TURN_DEG.to_radians();
    let dir_out = |prev_end: Point, s: &Span| -> Point {
        match s {
            Span::Line { end } => Point { x: end.x - prev_end.x, y: end.y - prev_end.y },
            Span::Cubic { control_one, .. } => {
                Point { x: control_one.x - prev_end.x, y: control_one.y - prev_end.y }
            }
        }
    };
    let dir_in = |prev_end: Point, s: &Span| -> Point {
        match s {
            Span::Line { end } => Point { x: end.x - prev_end.x, y: end.y - prev_end.y },
            Span::Cubic { control_two, end, .. } => {
                Point { x: end.x - control_two.x, y: end.y - control_two.y }
            }
        }
    };
    let ends: Vec<Point> = r.spans.iter().map(end_of).collect();
    let mut out: Vec<(bool, bool, bool)> = Vec::with_capacity(n);
    for i in 0..n {
        let v = ends[(i + n - 1) % n];
        let s_prev = &r.spans[(i + n - 1) % n];
        let s_cur = &r.spans[i];
        let before_v = if i == 0 { r.start } else { ends[(i + n - 2) % n] };
        let din = dir_in(before_v, s_prev);
        let dout = dir_out(v, s_cur);
        let (li, lo) = (
            (din.x * din.x + din.y * din.y).sqrt(),
            (dout.x * dout.x + dout.y * dout.y).sqrt(),
        );
        if li == 0.0 || lo == 0.0 {
            // The metric's zero-length tangent branch counts a corner but
            // never a curvature break (it skips the cubic-cubic check), so
            // handle collapse/uncollapse is a semantic change even when the
            // corner classification itself is unchanged: guard it.
            out.push((true, li == 0.0, lo == 0.0));
            continue;
        }
        let cos = ((din.x * dout.x + din.y * dout.y) / (li * lo)).clamp(-1.0, 1.0);
        out.push((cos.acos() > tol, false, false));
    }
    out
}

pub fn polish_emitted_rings_indexed(
    rings: &mut [ReferenceRing],
    captured: &[CapturedRing],
    scale: f64,
    src_index: &[usize],
) -> PolishStats {
    if src_index.len() != rings.len() || src_index.iter().any(|&i| i >= captured.len()) {
        return PolishStats::default();
    }
    polish_aligned(rings, captured, scale, |r, used| {
        let i = src_index[r];
        if used[i] {
            return None;
        }
        Some(i)
    })
}

pub fn polish_emitted_rings(
    rings: &mut [ReferenceRing],
    captured: &[CapturedRing],
    scale: f64,
) -> PolishStats {
    polish_aligned(rings, captured, scale, |_r, _used| None)
}

fn polish_aligned(
    rings: &mut [ReferenceRing],
    captured: &[CapturedRing],
    scale: f64,
    indexed: impl Fn(usize, &[bool]) -> Option<usize>,
) -> PolishStats {
    let mut stats = PolishStats::default();
    if rings.is_empty() || captured.is_empty() || !(scale.is_finite() && scale > 0.0) {
        return stats;
    }
    if !all_integer(rings) {
        return stats;
    }
    // Align emitted rings to capture polylines. With an explicit index
    // (engine path) use it; the geometric fallback (standalone use) matches
    // by nearest start in pixel space and is only safe for single-ring or
    // well-separated glyphs.
    let mut raw: Vec<Vec<Point>> = Vec::with_capacity(rings.len());
    let mut used = vec![false; captured.len()];
    for (ri, r) in rings.iter().enumerate() {
        let i = match indexed(ri, &used) {
            Some(i) => i,
            None => {
                let sp = Point { x: r.start.x / scale, y: r.start.y / scale };
                let mut best = None;
                let mut bd = f64::INFINITY;
                for (i, cr) in captured.iter().enumerate() {
                    if used[i] {
                        continue;
                    }
                    let pts = if cr.raw.is_empty() { &cr.points } else { &cr.raw };
                    if pts.is_empty() {
                        continue;
                    }
                    let d = ((pts[0].x - sp.x).powi(2) + (pts[0].y - sp.y).powi(2)).sqrt();
                    if d < bd {
                        bd = d;
                        best = Some(i);
                    }
                }
                match best {
                    Some(i) => i,
                    None => return stats, // no capture partner: polish nothing
                }
            }
        };
        used[i] = true;
        let cr = &captured[i];
        raw.push(if cr.raw.is_empty() { cr.points.clone() } else { cr.raw.clone() });
    }

    stats.objective_before = polish_objective(&raw, rings, scale);
    // Per-ring extremum baseline: a move may not raise missing_extrema.
    let mut ext_floor: Vec<usize> = rings
        .iter()
        .map(|r| crate::lever_api::missing_extrema(std::slice::from_ref(r)))
        .collect();

    // Card 437 guards: the coverage guard rasterizes the current emitted
    // rings against the capture's measured ink field (evaluator-identical
    // frame and winding rule); the join guard needs no state. Per-ring
    // RingOpt caches make each candidate evaluation O(affected spans)
    // instead of O(whole ring) with bit-identical decisions.
    let mut opts: Vec<RingOpt> = rings
        .iter()
        .zip(raw.iter())
        .map(|(r, raw_r)| RingOpt::new(raw_r, r, scale))
        .collect();
    let mut flat_all: Vec<Vec<Point>> = opts.iter().map(|o| o.flat.clone()).collect();
    let mut cover: Option<CoverageGuard> =
        CAPTURE_INK.with(|c| c.borrow().as_ref().map(|ci| CoverageGuard::new(ci, &flat_all)));

    for _sweep in 0..MAX_SWEEPS {
        let mut improved = false;
        let idxs = movable_points(rings);
        for (ri, pi) in idxs {
            let a = affected_spans(&rings[ri], pi);
            for (dx, dy) in [(1.0f64, 0.0f64), (-1.0, 0.0), (0.0, 1.0), (0.0, -1.0)] {
                let sig_old = join_signature(&rings[ri]);
                let obj_cur = opts[ri].obj;
                let flat_cur = opts[ri].flat.clone();
                apply_move(rings, ri, pi, dx, dy);
                let (flat_new, obj_new) = opts[ri].candidate(&raw[ri], &rings[ri], scale, &a);
                let ext_after =
                    crate::lever_api::missing_extrema(std::slice::from_ref(&rings[ri]));
                let mut ok = obj_new < obj_cur && ext_after <= ext_floor[ri];
                if ok {
                    ok = sig_old == join_signature(&rings[ri]);
                }
                if ok {
                    if let Some(g) = cover.as_ref() {
                        ok = g.allows(&flat_cur, &flat_new);
                    }
                }
                if ok {
                    improved = true;
                    stats.moves_accepted += 1;
                    ext_floor[ri] = ext_floor[ri].min(ext_after);
                    opts[ri].commit(&raw[ri], &rings[ri], scale, &a, flat_new.clone(), obj_new);
                    if let Some(g) = cover.as_mut() {
                        flat_all[ri] = flat_new.clone();
                        g.commit(&flat_all, &flat_cur, &flat_new);
                    }
                } else {
                    apply_move(rings, ri, pi, -dx, -dy);
                }
            }
        }
        if !improved {
            break;
        }
        stats.rings_polished = rings.len();
    }
    stats.objective_after = polish_objective(&raw, rings, scale);
    stats
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capture::CapturedRing;

    fn pt(x: f64, y: f64) -> Point {
        Point { x, y }
    }

    fn square_ring(x0: f64, y0: f64, size: f64) -> ReferenceRing {
        ReferenceRing {
            start: pt(x0, y0),
            spans: vec![
                Span::Line { end: pt(x0 + size, y0) },
                Span::Line { end: pt(x0 + size, y0 + size) },
                Span::Line { end: pt(x0, y0 + size) },
                Span::Line { end: pt(x0, y0) },
            ],
        }
    }

    fn square_capture(x0: f64, y0: f64, size: f64) -> CapturedRing {
        let pts = vec![
            pt(x0, y0),
            pt(x0 + size, y0),
            pt(x0 + size, y0 + size),
            pt(x0, y0 + size),
        ];
        CapturedRing { points: pts.clone(), corners: vec![], hole: false, raw: pts }
    }

    fn node_count(rings: &[ReferenceRing]) -> usize {
        rings.iter().map(|r| r.spans.len()).sum()
    }

    fn span_kinds(rings: &[ReferenceRing]) -> Vec<u8> {
        rings
            .iter()
            .flat_map(|r| {
                r.spans.iter().map(|s| match s {
                    Span::Line { .. } => 0u8,
                    Span::Cubic { .. } => 1u8,
                })
            })
            .collect()
    }

    #[test]
    fn polish_improves_misaligned_square() {
        // Emitted square shifted +1 unit in x from the measured capture.
        let mut rings = vec![square_ring(1.0, 0.0, 10.0)];
        let captured = vec![square_capture(0.0, 0.0, 10.0)];
        let raw: Vec<Vec<Point>> = vec![captured[0].raw.clone()];
        let before = polish_objective(&raw, &rings, 1.0);
        let stats = polish_emitted_rings(&mut rings, &captured, 1.0);
        let after = polish_objective(&raw, &rings, 1.0);
        assert!(after < before, "objective must fall: {before} -> {after}");
        assert!(stats.moves_accepted > 0);
        // The square should converge onto the capture.
        assert!(after < 1e-9, "square converges exactly, got {after}");
    }

    #[test]
    fn polish_preserves_nodes_and_kinds() {
        let mut rings = vec![square_ring(1.0, 0.0, 10.0)];
        let captured = vec![square_capture(0.0, 0.0, 10.0)];
        let n0 = node_count(&rings);
        let k0 = span_kinds(&rings);
        polish_emitted_rings(&mut rings, &captured, 1.0);
        assert_eq!(node_count(&rings), n0);
        assert_eq!(span_kinds(&rings), k0);
    }

    #[test]
    fn polish_is_deterministic() {
        let run = || {
            let mut rings = vec![square_ring(1.0, 0.0, 10.0), square_ring(30.5, 30.0, 8.0)];
            let captured = vec![square_capture(0.0, 0.0, 10.0), square_capture(30.0, 30.0, 8.0)];
            polish_emitted_rings(&mut rings, &captured, 1.0);
            rings
        };
        let a = run();
        let b = run();
        for (ra, rb) in a.iter().zip(b.iter()) {
            assert_eq!(ra.start.x, rb.start.x);
            assert_eq!(ra.start.y, rb.start.y);
            assert_eq!(ra.spans.len(), rb.spans.len());
        }
    }

    #[test]
    fn polish_keeps_integer_grid() {
        let mut rings = vec![square_ring(1.0, 0.0, 10.0)];
        let captured = vec![square_capture(0.25, 0.25, 9.5)];
        polish_emitted_rings(&mut rings, &captured, 1.0);
        assert!(all_integer(&rings));
    }

    #[test]
    fn polish_leaves_exact_fit_untouched() {
        let mut rings = vec![square_ring(0.0, 0.0, 10.0)];
        let captured = vec![square_capture(0.0, 0.0, 10.0)];
        let orig = rings.clone();
        let stats = polish_emitted_rings(&mut rings, &captured, 1.0);
        assert_eq!(stats.moves_accepted, 0);
        assert_eq!(rings[0].start, orig[0].start);
    }

    #[test]
    fn polish_rejects_non_integer_input() {
        let mut rings = vec![square_ring(0.5, 0.0, 10.0)];
        let captured = vec![square_capture(0.0, 0.0, 10.0)];
        let stats = polish_emitted_rings(&mut rings, &captured, 1.0);
        assert_eq!(stats.moves_accepted, 0);
        assert_eq!(rings[0].start, pt(0.5, 0.0));
    }

    #[test]
    fn polish_never_raises_missing_extrema() {
        // A cubic ring whose nodes are axis extrema; polish must not create
        // a new interior extremum or drop the node extrema.
        let ring = ReferenceRing {
            start: pt(0.0, 10.0),
            spans: vec![
                Span::Cubic { control_one: pt(0.0, 20.0), control_two: pt(9.0, 20.0), end: pt(10.0, 10.0) },
                Span::Cubic { control_one: pt(11.0, 0.0), control_two: pt(0.0, 0.0), end: pt(0.0, 10.0) },
            ],
        };
        let mut rings = vec![ring];
        // Capture polyline near the flattened original.
        let raw_poly = flatten_ring_px(&rings[0], 1.0, 16);
        let captured = vec![CapturedRing {
            points: raw_poly.clone(),
            corners: vec![],
            hole: false,
            raw: raw_poly,
        }];
        let before = crate::lever_api::missing_extrema(&rings);
        polish_emitted_rings(&mut rings, &captured, 1.0);
        let after = crate::lever_api::missing_extrema(&rings);
        assert!(after <= before, "{before} -> {after}");
    }

    #[test]
    fn polish_never_opens_closed_ring() {
        // Closed ring (last end == start): any accepted start move must drag
        // the closing end with it.
        let mut rings = vec![square_ring(1.0, 0.0, 10.0)];
        let captured = vec![square_capture(0.0, 0.0, 10.0)];
        polish_emitted_rings(&mut rings, &captured, 1.0);
        for r in &rings {
            let last = r.spans.last().map(end_of).unwrap();
            assert_eq!(last, r.start, "ring must stay closed");
        }
    }

    /// Two-ring glyph where the outer ring's fitted start is NEARER the
    /// counter ring's capture start than its own (the Marq 'o' geometry that
    /// regressed IoU 0.99 -> 0.90 under nearest-start matching). The indexed
    /// path must polish each ring against its own capture; the geometric
    /// fallback's known limitation is documented, not relied on.
    #[test]
    fn indexed_alignment_handles_crossed_starts() {
        // Outer square 0..40 px (capture), counter square 18..22 px.
        // Fitted outer ring's start moved to (19, 19) units at scale 1 -
        // adjacent to the counter's start (18, 18), far from its own (0, 0).
        let outer = ReferenceRing {
            start: pt(19.0, 19.0),
            spans: vec![
                Span::Line { end: pt(40.0, 0.0) },
                Span::Line { end: pt(40.0, 40.0) },
                Span::Line { end: pt(0.0, 40.0) },
                Span::Line { end: pt(0.0, 0.0) },
                Span::Line { end: pt(19.0, 19.0) },
            ],
        };
        let counter = ReferenceRing {
            start: pt(18.0, 18.0),
            spans: vec![
                Span::Line { end: pt(22.0, 18.0) },
                Span::Line { end: pt(22.0, 22.0) },
                Span::Line { end: pt(18.0, 22.0) },
                Span::Line { end: pt(18.0, 18.0) },
            ],
        };
        // Captures: outer one unit bigger in x than the fitted outline
        // (polish should widen the outer ring toward 0..41), counter exact.
        let cap_outer = square_capture(0.0, 0.0, 41.0);
        let cap_counter = square_capture(18.0, 18.0, 4.0);
        let captured = vec![cap_outer, cap_counter];
        let mut rings = vec![outer, counter];
        let raw_t = vec![captured[0].raw.clone(), captured[1].raw.clone()];
        let before = polish_objective(&raw_t, &rings, 1.0);
        let stats =
            polish_emitted_rings_indexed(&mut rings, &captured, 1.0, &[0, 1]);
        let after = polish_objective(&raw_t, &rings, 1.0);
        assert!(after < before, "indexed objective must fall: {before} -> {after}");
        assert!(stats.moves_accepted > 0);
        // The counter ring is an exact fit already: it must NOT be moved
        // toward anything (it was the mismatch victim).
        let c = &rings[1];
        assert_eq!(c.start, pt(18.0, 18.0));
        // The outer ring must have moved TOWARD its own capture (widened),
        // not toward the counter.
        let outer_pts: Vec<Point> =
            rings[0].spans.iter().map(|s| end_of(s)).collect();
        assert!(outer_pts.contains(&pt(41.0, 0.0)) || outer_pts.contains(&pt(41.0, 40.0)),
            "outer ring widened toward its own capture: {:?}", outer_pts);
    }

    /// Indexed alignment with a DROPPED middle capture (speck collapse):
    /// emitted rings map to captures [0, 2]; ring for capture 2 must polish
    /// against capture 2, not capture 1.
    #[test]
    fn indexed_alignment_skips_dropped_capture() {
        let r0 = square_ring(1.0, 0.0, 10.0);   // emitted for capture 0, off by 1
        let r1 = square_ring(101.0, 100.0, 8.0); // emitted for capture 2, off by 1
        let captured = vec![
            square_capture(0.0, 0.0, 10.0),
            square_capture(50.0, 50.0, 1.0),     // "dropped speck" - no emitted ring
            square_capture(100.0, 100.0, 8.0),
        ];
        let mut rings = vec![r0, r1];
        let raw_t = vec![captured[0].raw.clone(), captured[2].raw.clone()];
        let before = polish_objective(&raw_t, &rings, 1.0);
        polish_emitted_rings_indexed(&mut rings, &captured, 1.0, &[0, 2]);
        let after = polish_objective(&raw_t, &rings, 1.0);
        assert!(after < 1e-9, "both rings converge on their own captures, got {after} (before {before})");
        assert_eq!(rings[1].start, pt(100.0, 100.0));
    }

    #[test]
    fn polish_scales_units_to_pixels() {
        // At scale 10 (10 font units per pixel), a 1-unit move is 0.1 px.
        let mut rings = vec![square_ring(10.0, 0.0, 100.0)];
        let captured = vec![square_capture(0.0, 0.0, 10.0)];
        let raw: Vec<Vec<Point>> = vec![captured[0].raw.clone()];
        let before = polish_objective(&raw, &rings, 10.0);
        let stats = polish_emitted_rings(&mut rings, &captured, 10.0);
        let after = polish_objective(&raw, &rings, 10.0);
        // Sub-pixel steps can end in a strict local minimum on a translated
        // square (no single +-1-unit move improves); the contract is only
        // that the objective never increases. Here it must strictly improve.
        assert!(after < before, "{before} -> {after}");
        assert!(stats.moves_accepted > 0);
    }

    /// Rect in the guard's canvas frame: canvas (x, y_down) maps to
    /// bbox-relative y-up (x - ox, -y_down - oy); here origin (0,0).
    fn rect_flat(x0: f64, x1: f64, ytop: f64, ybot: f64) -> Vec<Point> {
        // CCW in y-up: left-bottom, right-bottom, right-top, left-top.
        vec![
            pt(x0, -ybot),
            pt(x1, -ybot),
            pt(x1, -ytop),
            pt(x0, -ytop),
        ]
    }

    fn ink_rect(w: usize, h: usize, c0: usize, c1: usize, r0: usize, r1: usize) -> Vec<u8> {
        let mut ink = vec![0u8; w * h];
        for r in r0..r1 {
            for c in c0..c1 {
                ink[r * w + c] = 1;
            }
        }
        ink
    }

    #[test]
    fn coverage_guard_blocks_background_flip() {
        // The uni00B9 mechanism: the traced raw edge sits on the pixel edge
        // between the last ink column and the first background column
        // (x=9.5 between ink col 9 and bg col 10). Pulling the emitted edge
        // from 10 to 11 improves the vector distance to a tilted raw edge
        // but flips background column 10's centers into coverage. The guard
        // must refuse; without the measured ink field the move goes through.
        let ci = CaptureInk {
            width: 20,
            height: 20,
            origin_x: 0.0,
            origin_y: 0.0,
            ink: std::rc::Rc::new(ink_rect(20, 20, 5, 10, 5, 15)), // ink cols 5..=9
        };
        // Tilted raw right edge: mean distance prefers 11 over 10.
        let raw: Vec<Point> = vec![
            pt(4.5, -14.4),
            pt(10.9, -14.4),
            pt(10.3, -4.6),
            pt(4.5, -4.6),
        ];
        let mk = |rx: f64| ReferenceRing {
            start: pt(4.0, -14.0),
            spans: vec![
                Span::Line { end: pt(rx, -14.0) },
                Span::Line { end: pt(rx, -5.0) },
                Span::Line { end: pt(4.0, -5.0) },
                Span::Line { end: pt(4.0, -14.0) },
            ],
        };
        let captured = vec![CapturedRing { points: raw.clone(), corners: vec![], hole: false, raw }];
        // Control: no measured ink scope -> the move is accepted.
        let mut rings = vec![mk(10.0)];
        let stats = polish_emitted_rings(&mut rings, &captured, 1.0);
        assert!(stats.moves_accepted > 0, "objective alone accepts the outward move");
        let moved_to = match rings[0].spans[0] {
            Span::Line { end } => end.x,
            _ => panic!(),
        };
        assert_eq!(moved_to, 11.0, "control confirms the move improves the objective");
        // With the measured ink field in scope, the same move flips bg col 10
        // and must be refused.
        let _scope = CaptureInkScope::enter(ci);
        let mut rings = vec![mk(10.0)];
        let stats = polish_emitted_rings(&mut rings, &captured, 1.0);
        let moved_to = match rings[0].spans[0] {
            Span::Line { end } => end.x,
            _ => panic!(),
        };
        assert_eq!(moved_to, 10.0, "coverage guard refuses the background flip (accepted {})", stats.moves_accepted);
    }

    #[test]
    fn coverage_guard_allows_ink_restoring_move() {
        // Same geometry, but column 10 is ink in the measurement: covering it
        // REDUCES disagreement, so the guard allows the improving move.
        let ci = CaptureInk {
            width: 20,
            height: 20,
            origin_x: 0.0,
            origin_y: 0.0,
            ink: std::rc::Rc::new(ink_rect(20, 20, 5, 11, 5, 15)), // ink cols 5..=10
        };
        let _scope = CaptureInkScope::enter(ci);
        let raw: Vec<Point> = vec![
            pt(4.5, -14.4),
            pt(10.9, -14.4),
            pt(10.3, -4.6),
            pt(4.5, -4.6),
        ];
        let mut rings = vec![ReferenceRing {
            start: pt(4.0, -14.0),
            spans: vec![
                Span::Line { end: pt(10.0, -14.0) },
                Span::Line { end: pt(10.0, -5.0) },
                Span::Line { end: pt(4.0, -5.0) },
                Span::Line { end: pt(4.0, -14.0) },
            ],
        }];
        let captured = vec![CapturedRing { points: raw.clone(), corners: vec![], hole: false, raw }];
        let stats = polish_emitted_rings(&mut rings, &captured, 1.0);
        assert!(stats.moves_accepted > 0, "ink-restoring improving move is allowed");
    }

    #[test]
    fn ring_opt_cache_is_bit_identical_to_direct_objective() {
        // The cached descent objective must equal ring_objective_poly on a
        // full re-flatten at every step: same moves, same values, same bits.
        let raw: Vec<Point> = (0..40)
            .map(|i| {
                let t = i as f64 / 40.0 * std::f64::consts::TAU;
                pt(50.0 + 30.0 * t.cos(), -50.0 + 21.0 * t.sin())
            })
            .collect();
        let mk = |dy: f64| ReferenceRing {
            start: pt(20.0, -50.0),
            spans: vec![
                Span::Cubic {
                    control_one: pt(20.0, -30.0),
                    control_two: pt(40.0, -28.0),
                    end: pt(50.0, -29.0 + dy.trunc()),
                },
                Span::Line { end: pt(80.0, -50.0) },
                Span::Cubic {
                    control_one: pt(80.0, -70.0),
                    control_two: pt(40.0, -72.0),
                    end: pt(20.0, -49.0),
                },
            ],
        };
        let mut ring = mk(0.0);
        let mut opt = RingOpt::new(&raw, &ring, 1.0);
        let direct = ring_objective_poly(&raw, &flatten_ring_px(&ring, 1.0, FLATTEN_STEPS));
        assert_eq!(opt.obj, direct, "initial objective bits");
        // Walk a deterministic sequence of moves across point kinds (start,
        // cubic controls, cubic end, line end), committing every one, and
        // compare candidate and committed values against fresh computation.
        let moves: [(usize, f64, f64); 8] = [
            (0usize, 1.0, 0.0),
            (1, 0.0, 1.0),
            (2, -1.0, 0.0),
            (3, 0.0, -1.0),
            (4, 1.0, 0.0),
            (5, 0.0, 1.0),
            (6, -1.0, 0.0),
            (7, 1.0, 0.0),
        ];
        for &(pi, dx, dy) in &moves {
            let a = affected_spans(&ring, pi);
            apply_move(std::slice::from_mut(&mut ring), 0, pi, dx, dy);
            let (flat_new, obj_new) = opt.candidate(&raw, &ring, 1.0, &a);
            let flat_direct = flatten_ring_px(&ring, 1.0, FLATTEN_STEPS);
            assert_eq!(flat_new.len(), flat_direct.len());
            for (x, y) in flat_new.iter().zip(flat_direct.iter()) {
                assert_eq!(x.x.to_bits(), y.x.to_bits());
                assert_eq!(x.y.to_bits(), y.y.to_bits());
            }
            assert_eq!(obj_new.to_bits(), ring_objective_poly(&raw, &flat_direct).to_bits(), "candidate bits at move {pi}");
            opt.commit(&raw, &ring, 1.0, &a, flat_new, obj_new);
            assert_eq!(opt.obj.to_bits(), ring_objective_poly(&raw, &flatten_ring_px(&ring, 1.0, FLATTEN_STEPS)).to_bits(), "commit bits at move {pi}");
        }
    }

    #[test]
    fn join_guard_blocks_corner_reclassification() {
        // Emitted apex is smooth (0-degree turn); the measured capture has a
        // 11.4-degree corner. The vector objective rewards moving the apex
        // onto the capture, but the move reclassifies the join from smooth
        // to corner (10-degree tangent tolerance, the acceptance metric's
        // own constant): the join guard must refuse it.
        let raw: Vec<Point> = vec![pt(0.0, 0.0), pt(20.0, 0.0), pt(10.0, 1.0)];
        let mut rings = vec![ReferenceRing {
            start: pt(0.0, 0.0),
            spans: vec![
                Span::Line { end: pt(20.0, 0.0) },
                Span::Line { end: pt(10.0, 0.0) },
                Span::Line { end: pt(0.0, 0.0) },
            ],
        }];
        let captured = vec![CapturedRing { points: raw.clone(), corners: vec![], hole: false, raw }];
        polish_emitted_rings(&mut rings, &captured, 1.0);
        let apex = match rings[0].spans[1] {
            Span::Line { end } => end,
            _ => panic!(),
        };
        assert_eq!(apex, pt(10.0, 0.0), "corner reclassification refused");
    }
}
