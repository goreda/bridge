//! Canonical-path run harness (W2-3 / next-version work list item 4,
//! CANON-FIX-1 reconcile wiring).
//!
//! Runs the canonical chain capture_png -> fit_captured -> export-boundary
//! rounding reconcile -> integer charstring at fit scale K=1 and, for
//! measured comparison, the raw chain (no reconcile) at the manifest's
//! production scale K, exactly as W2-3 measured it
//! (docs/process/measurement-frame.md records the production path as
//! capture, fit_captured(rings, K), integer charstring in font units). The
//! reconcile stage is the landed kni_core::rounding_reconcile code: every
//! coordinate is quantized to the integer export grid (round half away from
//! zero, EXPORT_RESOLUTION, the same per-scalar rounding production applies
//! in prepare_generated_with_placement), then the W2-2 constant-cubic
//! cleanup runs with one typed ledger row per drop/hold. The W2-3 finding
//! was that the canonical chain alone cannot reach an integer charstring on
//! glyphs production ships (charstring_refused:UnrepresentableCoordinate);
//! the reconcile stage is the production mechanism that closes exactly that
//! gap, so the canonical arm wires it and re-measures. The production arm
//! is left byte-for-byte as W2-3 ran it (raw chain, its two typed refusals
//! documented in measurements.run2-7422a4ac.tsv). Per-glyph reconcile
//! outcomes are typed note tokens: reconcile_quantized:moved=N:max_delta=D:
//! non_finite=N, constant_cubic_dropped:ring=R:span=S,
//! constant_cubic_held:ring=R:span=S:why=W. Nothing drops silently.
//! Everything else in the two arms comes from the manifest; nothing in the
//! existing production paths is modified.
//!
//! Per glyph and arm it measures: segment counts (line/cubic) of the decoded
//! integer charstring outline, fit error against the capture's raw rings
//! (symmetric mean squared distance and max deviation, in px), scan-domain
//! IoU at the declared threshold (ProductionEvaluator rasterizer), and the
//! charstring bytes. The per-glyph byte diff compares the two arms'
//! charstrings; whole-font CFF bytes per arm are emitted for the font-level
//! byte diff. Every glyph failure is a typed row; nothing drops silently.
//!
//! Usage:
//!   canonical_path_run MANIFEST TILEDIR OUT_DIR THRESHOLD FLATTEN_STEPS \
//!       FLATTEN_TOL_PX MAX_WORKING_BYTES
//!
//! All parameters are explicit operational inputs; the harness declares no
//! numeric constants of its own. TILEDIR substitutes the @TILEDIR@ token in
//! manifest glyph paths (pass any existing directory when unused).
//! Frame pins follow the format pinned in economy_eval::ProductionEvaluator.

use kni_core::capture::capture_png;
use kni_core::capture_fit::fit_captured;
use kni_core::cff_container::{charstring, cff_one, CffGlyph};
use kni_core::cff_reader::sha256_hex;
use kni_core::cubic_fit::FitPolicy;
use kni_core::curve_stress::flatten_ring;
use kni_core::economy_eval::{EvalConfig, ProductionEvaluator, RenderLimits};
use kni_core::glyph_segments::segment_metrics;
use kni_core::reference_slice::{DrawnGlyph, Point, ReferenceRing, Span};

#[derive(Clone)]
struct GlyphRow { cp: String, name: String, path: String }

struct ManifestCfg {
    scale: f64, eps: f64, se: f64, refits: usize, upm: u16,
    ps_name: String, population: String, glyphs: Vec<GlyphRow>,
    ignored_keys: Vec<String>,
}

fn parse_manifest(text: &str, tiledir: &str, manifest_dir: &std::path::Path) -> Result<ManifestCfg, String> {
    let (mut scale, mut eps, mut se, mut refits, mut upm, mut ps, mut pop) = (None, None, None, None, None, None, String::new());
    let mut glyphs = Vec::new();
    let mut ignored = Vec::new();
    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        let p: Vec<&str> = line.split_whitespace().collect();
        match p[0] {
            "scale" => scale = Some(p[1].parse::<f64>().map_err(|_| "bad scale")?),
            "rdp_epsilon" => eps = Some(p[1].parse::<f64>().map_err(|_| "bad rdp_epsilon")?),
            "fit_squared_error" => se = Some(p[1].parse::<f64>().map_err(|_| "bad fit_squared_error")?),
            "fit_max_refits" => refits = Some(p[1].parse::<usize>().map_err(|_| "bad fit_max_refits")?),
            "upm" => upm = Some(p[1].parse::<u16>().map_err(|_| "bad upm")?),
            "postscript_name" => ps = Some(p[1].to_string()),
            "population_sha256" => pop = p[1].to_string(),
            "glyph" => {
                if p.len() < 4 { return Err(format!("bad glyph row: {line}")); }
                let raw = p[3];
                let resolved = if let Some(rest) = raw.strip_prefix("@TILEDIR@/") {
                    format!("{tiledir}/{rest}")
                } else if std::path::Path::new(raw).is_absolute() {
                    raw.to_string()
                } else {
                    manifest_dir.join(raw).to_string_lossy().into_owned()
                };
                glyphs.push(GlyphRow { cp: p[1].to_string(), name: p[2].to_string(), path: resolved });
            }
            other => ignored.push(other.to_string()),
        }
    }
    Ok(ManifestCfg {
        scale: scale.ok_or("manifest: missing scale")?,
        eps: eps.ok_or("manifest: missing rdp_epsilon")?,
        se: se.ok_or("manifest: missing fit_squared_error")?,
        refits: refits.ok_or("manifest: missing fit_max_refits")?,
        upm: upm.ok_or("manifest: missing upm")?,
        ps_name: ps.ok_or("manifest: missing postscript_name")?,
        population: pop, glyphs, ignored_keys: ignored,
    })
}

/// Point-to-polyline distance (closed polyline), same estimator family as
/// economy_eval::dist_to_poly (point-to-segment minimum over edges).
fn dist_to_poly(p: Point, poly: &[Point]) -> f64 {
    let n = poly.len();
    if n == 0 { return f64::INFINITY; }
    (0..n).map(|i| {
        let a = poly[i]; let b = poly[(i + 1) % n];
        let dx = b.x - a.x; let dy = b.y - a.y;
        let l2 = dx * dx + dy * dy;
        let t = if l2 == 0.0 { 0.0 } else { (((p.x - a.x) * dx + (p.y - a.y) * dy) / l2).clamp(0.0, 1.0) };
        let (cx, cy) = (a.x + t * dx, a.y + t * dy);
        ((p.x - cx).powi(2) + (p.y - cy).powi(2)).sqrt()
    }).fold(f64::INFINITY, f64::min)
}

/// Fit error of one emitted glyph against the capture's raw rings, in px.
/// Mirrors the economy_eval RegionAssessment quantities: symmetric mean
/// squared distance (both directions, averaged) and maximum deviation.
/// Rings align by index: fit_captured preserves capture order (subsequence
/// with drops). A count mismatch is reported as None (typed at the caller),
/// never silently re-aligned.
fn fit_error_px(raw: &[Vec<Point>], rings: &[ReferenceRing], k: f64, flatten_tol_px: f64) -> Option<(f64, f64)> {
    if raw.len() != rings.len() { return None; }
    let tol_font = flatten_tol_px * k;
    let mut sfe_sum = 0.0f64; let mut maxdev = 0.0f64;
    for (r, ring) in raw.iter().zip(rings.iter()) {
        if r.is_empty() { return None; }
        let poly: Vec<Point> = flatten_ring(ring, tol_font).iter().map(|p| Point { x: p.x / k, y: p.y / k }).collect();
        if poly.is_empty() { return None; }
        let d1: Vec<f64> = r.iter().map(|p| dist_to_poly(*p, &poly)).collect();
        let d2: Vec<f64> = poly.iter().map(|p| dist_to_poly(*p, r)).collect();
        let mean2 = |d: &[f64]| d.iter().map(|x| x * x).sum::<f64>() / d.len() as f64;
        let sfe = (mean2(&d1) + mean2(&d2)) / 2.0;
        let md = d1.iter().chain(d2.iter()).cloned().fold(0.0, f64::max);
        if !(sfe.is_finite() && md.is_finite()) { return None; }
        sfe_sum += sfe; if md > maxdev { maxdev = md; }
    }
    Some((sfe_sum / rings.len().max(1) as f64, maxdev))
}

struct ArmOut {
    rings: Vec<ReferenceRing>, fallback: bool, dropped: usize,
    cs: Vec<u8>, container_accepted: bool,
    line: usize, cubic: usize, sfe: Option<f64>, maxdev: Option<f64>, iou: Option<f64>,
    notes: Vec<String>,
}

fn run_arm(
    label: &str, mc: &kni_core::capture::MeasuredContour, png: &[u8], png_sha: &str,
    k: f64, policy: &FitPolicy, capture_eps: f64, upm: u16, glyph_name: &str,
    threshold: u8, flatten_steps: usize, flatten_tol_px: f64, max_working_bytes: usize,
    reconcile: bool,
) -> ArmOut {
    let mut notes = Vec::new();
    let _ink_scope = kni_core::fit_polish::CaptureInkScope::from_contour(mc);
    let (rings, spans, fallback, dropped) = fit_captured(&mc.rings, k, policy);
    // CANON-FIX-1: when this arm reconciles, run the landed export-boundary
    // rounding reconcile between fit and the integer container: quantize to
    // the export grid, then the W2-2 constant-cubic cleanup. Measurements
    // below (segments, fit error, IoU, charstring) describe the reconciled
    // outline, i.e. what this arm would actually ship; every effect is a
    // typed note token. The charstring gate still refuses non-finite or
    // out-of-range coordinates as typed rows; reconcile never hides them.
    let mut rings = rings;
    if reconcile {
        let mut drawn = DrawnGlyph { glyph_id: glyph_name.to_string(), rings };
        let q = kni_core::rounding_reconcile::quantize_outline(&mut drawn);
        notes.push(format!(
            "reconcile_quantized:moved={}:max_delta={:.6}:non_finite={}",
            q.moved, q.max_abs_delta, q.non_finite
        ));
        let mut cffs = vec![CffGlyph { name: glyph_name.to_string(), advance: upm, outline: drawn }];
        let cc = kni_core::rounding_reconcile::drop_constant_cubics(&mut cffs);
        for d in &cc.dropped {
            notes.push(format!("constant_cubic_dropped:ring={}:span={}", d.ring_index, d.span_index));
        }
        for h in &cc.held {
            notes.push(format!("constant_cubic_held:ring={}:span={}:why={:?}", h.ring_index, h.span_index, h.why));
        }
        rings = cffs.into_iter().next().map(|g| g.outline.rings).unwrap_or_default();
    }
    let glyph = DrawnGlyph { glyph_id: glyph_name.to_string(), rings: rings.clone() };
    let cff_glyph = CffGlyph { name: glyph_name.to_string(), advance: upm, outline: glyph.clone() };
    // The integer container accepts exact-integer coordinates only (its
    // delta encoding is then faithful by construction), so container
    // acceptance IS the integer-charstring gate: accepted glyphs measure
    // exactly what the charstring encodes. A refusal is a typed finding
    // (the canonical chain emitted a non-integer or out-of-range
    // coordinate), never a silent skip.
    let (cs, container_accepted) = match charstring(&cff_glyph) {
        Ok(b) => (b, true),
        Err(e) => { notes.push(format!("charstring_refused:{e:?}")); (Vec::new(), false) }
    };
    let measured = rings.clone();
    let m = segment_metrics(&measured);
    let raw: Vec<Vec<Point>> = mc.rings.iter().map(|r| r.raw.clone()).collect();
    let (sfe, maxdev) = match fit_error_px(&raw, &measured, k, flatten_tol_px) {
        Some((s, d)) => (Some(s), Some(d)),
        None => { notes.push("fit_error_unassessable:ring_alignment".into()); (None, None) }
    };
    let (w, h) = (mc.width, mc.height);
    let cfg = EvalConfig {
        frame_id: format!("CAP-{}-SCAN{}-FITK-CFFINTEGER-RAWORIGIN", label, threshold),
        scale_k: k, threshold, canvas: (w, h), capture_eps, flatten_steps,
        expected_source_sha256: png_sha.to_string(), advance: upm,
        render_limits: RenderLimits { max_pixels: w * h, max_flatten_steps: flatten_steps, max_edges: w * h, max_working_bytes },
    };
    let iou = match ProductionEvaluator::new(cfg, png) {
        Ok(ev) => {
            let cover = ev.render_mask(&DrawnGlyph { glyph_id: glyph_name.to_string(), rings: measured.clone() }).ok();
            match cover {
                Some(cover) => {
                    let src = ev.source_mask();
                    let (mut inter, mut uni) = (0u64, 0u64);
                    for (i, &c) in cover.iter().enumerate() {
                        let s = src[i];
                        if c && s { inter += 1; }
                        if c || s { uni += 1; }
                    }
                    if uni == 0 { notes.push("iou_unassessable:empty_union".into()); None } else { Some(inter as f64 / uni as f64) }
                }
                None => { notes.push("iou_unassessable:render_refused".into()); None }
            }
        }
        Err(e) => { notes.push(format!("evaluator_refused:{e}")); None }
    };
    let _ = spans;
    ArmOut { rings, fallback, dropped, cs, container_accepted, line: m.line, cubic: m.cubic, sfe, maxdev, iou, notes }
}

fn byte_diff(a: &[u8], b: &[u8]) -> (bool, usize, Option<usize>, usize) {
    let n = a.len().min(b.len());
    let mut first = None; let mut count = a.len().abs_diff(b.len());
    for i in 0..n {
        if a[i] != b[i] {
            if first.is_none() { first = Some(i); }
            count += 1;
        }
    }
    (a == b, a.len() + b.len(), first, count)
}

// ---- Card 437: resumable/checkpointed execution -------------------------
//
// The full-population run with the fit_polish stage exceeds the sandbox's
// per-invocation wall-clock cap, and detached processes are killed. This
// harness therefore checkpoints per glyph and resumes: every completed
// glyph writes OUT_DIR/checkpoint/<name>__<cp>/ atomically (tmp + rename)
// with its exact TSV rows, its emitted rings (for font assembly), and a
// meta file binding the tile bytes (png sha256), the run configuration and
// the engine build stamp. Final outputs (measurements.tsv, ledger.tsv,
// fonts.tsv, both OTFs) are assembled ONLY when every manifest glyph has a
// valid checkpoint - a missing glyph means no publish. Resume refuses
// (typed error, nothing overwritten) on a config/manifest/stamp mismatch
// or a checksum-corrupt checkpoint; it never silently recomputes against a
// mixed cache. KNI_CANON_GLYPH_BUDGET=n stops after n newly processed
// glyphs (incomplete -> no final outputs), which drives multi-invocation
// completion and makes the no-publish path testable. A fresh run on an
// empty directory produces byte-identical outputs to a resumed run.

const CHECKPOINT_VERSION: u32 = 1;

fn engine_stamp() -> String {
    option_env!("KNI_ENGINE_STAMP").unwrap_or("unstamped").to_string()
}

fn config_sha(cfg: &ManifestCfg, threshold: u8, flatten_steps: usize, flatten_tol_px: f64, max_working_bytes: usize) -> String {
    sha256_hex(format!(
        "v{}|{}|{}|{}|{}|{}|{}|{}|{}|{}|{}",
        CHECKPOINT_VERSION, threshold, flatten_steps, flatten_tol_px, max_working_bytes,
        cfg.scale, cfg.eps, cfg.se, cfg.refits, cfg.upm, cfg.ps_name
    ).as_bytes())
}

struct GlyphCheckpoint {
    rows: String,                       // exact TSV row text (1 or 2 lines)
    accepted: [bool; 2],                // [canonical_k1, production]
    rings: [Vec<ReferenceRing>; 2],     // empty when not accepted
}

fn encode_rings(rings: &[ReferenceRing]) -> String {
    let mut t = String::new();
    for r in rings {
        t.push_str(&format!("R {:.0} {:.0}
", r.start.x, r.start.y));
        for sp in &r.spans {
            match sp {
                Span::Line { end } => t.push_str(&format!("L {:.0} {:.0}
", end.x, end.y)),
                Span::Cubic { control_one, control_two, end } => t.push_str(&format!(
                    "C {:.0} {:.0} {:.0} {:.0} {:.0} {:.0}
",
                    control_one.x, control_one.y, control_two.x, control_two.y, end.x, end.y)),
            }
        }
    }
    t
}

fn decode_rings(t: &str) -> Result<Vec<ReferenceRing>, String> {
    let mut out = Vec::new();
    let mut cur: Option<ReferenceRing> = None;
    for line in t.lines() {
        let p: Vec<&str> = line.split_whitespace().collect();
        let num = |i: usize| -> Result<f64, String> {
            p.get(i).ok_or("checkpoint rings: short line")?.parse::<f64>().map_err(|_| "checkpoint rings: bad number".into())
        };
        match p.first().copied() {
            Some("R") => {
                if let Some(r) = cur.take() { out.push(r); }
                cur = Some(ReferenceRing { start: Point { x: num(1)?, y: num(2)? }, spans: vec![] });
            }
            Some("L") => {
                let r = cur.as_mut().ok_or("checkpoint rings: span before ring")?;
                r.spans.push(Span::Line { end: Point { x: num(1)?, y: num(2)? } });
            }
            Some("C") => {
                let r = cur.as_mut().ok_or("checkpoint rings: span before ring")?;
                r.spans.push(Span::Cubic {
                    control_one: Point { x: num(1)?, y: num(2)? },
                    control_two: Point { x: num(3)?, y: num(4)? },
                    end: Point { x: num(5)?, y: num(6)? },
                });
            }
            other => return Err(format!("checkpoint rings: bad tag {other:?}")),
        }
    }
    if let Some(r) = cur.take() { out.push(r); }
    Ok(out)
}

fn write_atomic(path: &std::path::Path, bytes: &[u8]) -> Result<(), String> {
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, bytes).map_err(|e| format!("checkpoint write {}: {e}", tmp.display()))?;
    std::fs::rename(&tmp, path).map_err(|e| format!("checkpoint rename {}: {e}", path.display()))
}

fn glyph_cp_dir(out_dir: &std::path::Path, g: &GlyphRow) -> std::path::PathBuf {
    out_dir.join("checkpoint").join(format!("{}__{}", g.name, g.cp))
}

fn write_checkpoint(dir: &std::path::Path, png_sha: &str, csha: &str, cp: &GlyphCheckpoint) -> Result<(), String> {
    std::fs::create_dir_all(dir).map_err(|e| format!("checkpoint dir: {e}"))?;
    let rings: [String; 2] = [encode_rings(&cp.rings[0]), encode_rings(&cp.rings[1])];
    write_atomic(&dir.join("rows.tsv"), cp.rows.as_bytes())?;
    write_atomic(&dir.join("rings_k1.txt"), rings[0].as_bytes())?;
    write_atomic(&dir.join("rings_prod.txt"), rings[1].as_bytes())?;
    let meta = format!(
        "version={}
png_sha256={}
config_sha256={}
engine_stamp={}
accepted_k1={}
accepted_prod={}
rows_sha256={}
rings_k1_sha256={}
rings_prod_sha256={}
",
        CHECKPOINT_VERSION, png_sha, csha, engine_stamp(),
        cp.accepted[0], cp.accepted[1],
        sha256_hex(cp.rows.as_bytes()), sha256_hex(rings[0].as_bytes()), sha256_hex(rings[1].as_bytes()),
    );
    write_atomic(&dir.join("meta.txt"), meta.as_bytes())
}

fn meta_get<'a>(meta: &'a str, key: &str) -> Result<&'a str, String> {
    meta.lines()
        .find_map(|l| l.strip_prefix(key).and_then(|v| v.strip_prefix('=')))
        .ok_or_else(|| format!("checkpoint meta missing {key}"))
}

fn load_checkpoint(dir: &std::path::Path, png_sha: &str, csha: &str) -> Result<Option<GlyphCheckpoint>, String> {
    let meta_path = dir.join("meta.txt");
    if !meta_path.exists() {
        return Ok(None);
    }
    let who = dir.file_name().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
    let meta = std::fs::read_to_string(&meta_path).map_err(|e| format!("checkpoint read {}: {e}", meta_path.display()))?;
    if meta_get(&meta, "version")? != CHECKPOINT_VERSION.to_string() {
        return Err(format!("checkpoint {who}: stale format version - refusing mixed cache"));
    }
    if meta_get(&meta, "png_sha256")? != png_sha {
        return Err(format!("checkpoint {who}: tile bytes differ from cache - refusing stale cache"));
    }
    if meta_get(&meta, "config_sha256")? != csha {
        return Err(format!("checkpoint {who}: run configuration differs from cache - refusing mixed cache"));
    }
    if meta_get(&meta, "engine_stamp")? != engine_stamp() {
        return Err(format!("checkpoint {who}: engine build differs from cache - refusing stale cache"));
    }
    let rows = std::fs::read_to_string(dir.join("rows.tsv")).map_err(|e| format!("checkpoint {who} rows: {e}"))?;
    if sha256_hex(rows.as_bytes()) != meta_get(&meta, "rows_sha256")? {
        return Err(format!("checkpoint {who}: rows checksum mismatch - refusing corrupt cache"));
    }
    let mut out = GlyphCheckpoint { rows, accepted: [false, false], rings: [vec![], vec![]] };
    for (i, (file, accepted_key, sha_key)) in [
        ("rings_k1.txt", "accepted_k1", "rings_k1_sha256"),
        ("rings_prod.txt", "accepted_prod", "rings_prod_sha256"),
    ].iter().enumerate() {
        let text = std::fs::read_to_string(dir.join(file)).map_err(|e| format!("checkpoint {who} {file}: {e}"))?;
        if sha256_hex(text.as_bytes()) != meta_get(&meta, sha_key)? {
            return Err(format!("checkpoint {who}: {file} checksum mismatch - refusing corrupt cache"));
        }
        out.accepted[i] = meta_get(&meta, accepted_key)? == "true";
        out.rings[i] = decode_rings(&text).map_err(|e| format!("checkpoint {who}: {e}"))?;
    }
    Ok(Some(out))
}

fn main() -> Result<(), String> {
    let a: Vec<String> = std::env::args().collect();
    if a.len() != 8 {
        return Err("usage: canonical_path_run MANIFEST TILEDIR OUT_DIR THRESHOLD FLATTEN_STEPS FLATTEN_TOL_PX MAX_WORKING_BYTES".into());
    }
    let manifest_path = std::path::PathBuf::from(&a[1]);
    let tiledir = &a[2];
    let out_dir = std::path::PathBuf::from(&a[3]);
    let threshold: u8 = a[4].parse().map_err(|_| "invalid threshold")?;
    let flatten_steps: usize = a[5].parse().map_err(|_| "invalid flatten steps")?;
    let flatten_tol_px: f64 = a[6].parse().map_err(|_| "invalid flatten tol")?;
    let max_working_bytes: usize = a[7].parse().map_err(|_| "invalid working bytes")?;
    if !flatten_tol_px.is_finite() || flatten_tol_px <= 0.0 { return Err("invalid flatten tol".into()); }
    let text = std::fs::read_to_string(&manifest_path).map_err(|e| format!("manifest read: {e}"))?;
    let manifest_dir = manifest_path.parent().ok_or("manifest dir")?.to_path_buf();
    let cfg = parse_manifest(&text, tiledir, &manifest_dir)?;
    if !(cfg.scale.is_finite() && cfg.scale > 0.0) { return Err("invalid manifest scale".into()); }
    let policy = FitPolicy { squared_error: cfg.se, max_refits: cfg.refits };
    std::fs::create_dir_all(&out_dir).map_err(|e| format!("out dir: {e}"))?;

    let manifest_sha = sha256_hex(text.as_bytes());
    let csha = config_sha(&cfg, threshold, flatten_steps, flatten_tol_px, max_working_bytes);
    let cp_root = out_dir.join("checkpoint");
    let run_path = cp_root.join("run.json");
    if run_path.exists() {
        let run = std::fs::read_to_string(&run_path).map_err(|e| format!("run cache read: {e}"))?;
        if meta_get(&run, "manifest_sha256")? != manifest_sha {
            return Err("run cache: manifest changed - refusing mixed cache".into());
        }
        if meta_get(&run, "config_sha256")? != csha {
            return Err("run cache: configuration changed - refusing mixed cache".into());
        }
        if meta_get(&run, "engine_stamp")? != engine_stamp() {
            return Err("run cache: engine build changed - refusing stale cache".into());
        }
    }
    let glyph_budget: Option<usize> = std::env::var("KNI_CANON_GLYPH_BUDGET")
        .ok()
        .map(|v| v.parse::<usize>().map_err(|_| -> String { "invalid KNI_CANON_GLYPH_BUDGET".into() }))
        .transpose()?;

    let tsv_header = "glyph\tcodepoint\tarm\tK\trings_in\trings_out\tdropped\tfallback\tsegments_line\tsegments_cubic\tsegments_total\tfit_error_sfe_px2\tfit_error_maxdev_px\tiou_scan_domain\tcharstring_len\tcharstring_sha256\tcharstring_eq_other_arm\tbyte_diff_first_offset\tbyte_diff_count\tcontainer_accepted\tnotes\n";

    let mut cached: Vec<Option<GlyphCheckpoint>> = Vec::with_capacity(cfg.glyphs.len());
    let mut newly_done = 0usize;
    let mut budget_hit = false;

    for g in &cfg.glyphs {
        // Tile bytes bind every checkpoint decision; an unreadable tile on a
        // glyph that has no checkpoint is a typed row, identical to fresh.
        let png = std::fs::read(&g.path);
        let png_sha = png.as_ref().map(|b| sha256_hex(b)).unwrap_or_default();
        let dir = glyph_cp_dir(&out_dir, g);
        if let Some(c) = load_checkpoint(&dir, &png_sha, &csha)? {
            cached.push(Some(c));
            continue;
        }
        if budget_hit {
            cached.push(None);
            continue;
        }
        let mut rows = String::new();
        let mut accepted = [false, false];
        let mut rings: [Vec<ReferenceRing>; 2] = [vec![], vec![]];
        let png = match png {
            Ok(b) => b,
            Err(e) => {
                rows.push_str(&format!("{}\t{}\tBOTH\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\tread_error:{e}\n", g.name, g.cp));
                let c = GlyphCheckpoint { rows, accepted, rings };
                write_checkpoint(&dir, &png_sha, &csha, &c)?;
                cached.push(Some(c));
                newly_done += 1;
                if let Some(b) = glyph_budget { if newly_done >= b { budget_hit = true; } }
                continue;
            }
        };
        let mc = match capture_png(&png, cfg.eps) {
            Ok(m) => m,
            Err(e) => {
                rows.push_str(&format!("{}\t{}\tBOTH\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\t-\tcapture_refused:{e}\n", g.name, g.cp));
                let c = GlyphCheckpoint { rows, accepted, rings };
                write_checkpoint(&dir, &png_sha, &csha, &c)?;
                cached.push(Some(c));
                newly_done += 1;
                if let Some(b) = glyph_budget { if newly_done >= b { budget_hit = true; } }
                continue;
            }
        };
        let rings_in = mc.rings.len();
        let k1 = run_arm("K1", &mc, &png, &png_sha, 1.0, &policy, cfg.eps, cfg.upm, &g.name, threshold, flatten_steps, flatten_tol_px, max_working_bytes, true);
        let prod = run_arm("PROD", &mc, &png, &png_sha, cfg.scale, &policy, cfg.eps, cfg.upm, &g.name, threshold, flatten_steps, flatten_tol_px, max_working_bytes, false);
        let (eq, _tot, first, ndiff) = byte_diff(&k1.cs, &prod.cs);
        let diff_assessable = k1.container_accepted && prod.container_accepted;
        for (label, k, arm) in [("canonical_k1", 1.0f64, &k1), ("production", cfg.scale, &prod)] {
            rows.push_str(&format!(
                "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n",
                g.name, g.cp, label, k, rings_in, arm.rings.len(), arm.dropped, arm.fallback,
                arm.line, arm.cubic, arm.line + arm.cubic,
                arm.sfe.map(|v| format!("{v:.6}")).unwrap_or("n/a".into()),
                arm.maxdev.map(|v| format!("{v:.6}")).unwrap_or("n/a".into()),
                arm.iou.map(|v| format!("{v:.6}")).unwrap_or("n/a".into()),
                arm.cs.len(), sha256_hex(&arm.cs),
                if diff_assessable { eq.to_string() } else { "n/a".into() },
                if diff_assessable { first.map(|v| v.to_string()).unwrap_or("none".into()) } else { "n/a".into() },
                if diff_assessable { ndiff.to_string() } else { "n/a".into() },
                arm.container_accepted,
                if arm.notes.is_empty() { "-".into() } else { arm.notes.join("|") },
            ));
        }
        accepted = [k1.container_accepted, prod.container_accepted];
        rings = [k1.rings.clone(), prod.rings.clone()];
        let c = GlyphCheckpoint { rows, accepted, rings };
        write_checkpoint(&dir, &png_sha, &csha, &c)?;
        cached.push(Some(c));
        newly_done += 1;
        if let Some(b) = glyph_budget { if newly_done >= b { budget_hit = true; } }
    }

    let done = cached.iter().filter(|c| c.is_some()).count();
    if done != cfg.glyphs.len() {
        std::fs::create_dir_all(&cp_root).map_err(|e| format!("run cache dir: {e}"))?;
        write_atomic(&run_path, format!("manifest_sha256={}\nconfig_sha256={}\nengine_stamp={}\n", manifest_sha, csha, engine_stamp()).as_bytes())?;
        println!("checkpointed {}/{} glyphs; resume to continue (no final outputs published)", done, cfg.glyphs.len());
        return Ok(());
    }

    // Complete: assemble final outputs from checkpoints in manifest order.
    let mut tsv = String::from(tsv_header);
    let mut ledger = String::new();
    ledger.push_str(&format!("manifest_population_sha256\t{}\n", cfg.population));
    for k in &cfg.ignored_keys { ledger.push_str(&format!("manifest_ignored_key\t{k}\n")); }
    let mut font_glyphs_k1: Vec<CffGlyph> = Vec::new();
    let mut font_glyphs_prod: Vec<CffGlyph> = Vec::new();
    let mut rows = 0usize;
    for (g, c) in cfg.glyphs.iter().zip(cached.iter()) {
        let c = c.as_ref().ok_or("internal: incomplete cache passed completeness gate")?;
        tsv.push_str(&c.rows);
        rows += c.rows.lines().count();
        for (label, i, sink) in [("canonical_k1", 0, &mut font_glyphs_k1), ("production", 1, &mut font_glyphs_prod)] {
            if c.accepted[i] {
                sink.push(CffGlyph { name: g.name.clone(), advance: cfg.upm, outline: DrawnGlyph { glyph_id: g.name.clone(), rings: c.rings[i].clone() } });
            } else if !c.rows.contains("\tBOTH\t") {
                ledger.push_str(&format!("font_excluded_glyph\t{}\t{}\tcontainer_refused\n", label, g.name));
            }
        }
    }

    // Whole-font CFF bytes per arm (notdef at GID0, manifest order after).
    let notdef = CffGlyph { name: ".notdef".into(), advance: cfg.upm, outline: DrawnGlyph { glyph_id: ".notdef".into(), rings: vec![] } };
    let mut font_rows = String::new();
    for (label, glyphs, file) in [("canonical_k1", &font_glyphs_k1, "canonical-k1.otf"), ("production", &font_glyphs_prod, "production.otf")] {
        let mut all = vec![notdef.clone()];
        all.extend(glyphs.iter().cloned());
        match cff_one(&cfg.ps_name, &all) {
            Ok(bytes) => {
                std::fs::write(out_dir.join(file), &bytes).map_err(|e| format!("font write: {e}"))?;
                font_rows.push_str(&format!("font\t{}\t{}\t{}\t{}\tglyphs={}\n", label, file, bytes.len(), sha256_hex(&bytes), glyphs.len() + 1));
            }
            Err(e) => font_rows.push_str(&format!("font\t{}\t{}\trefused\t{:?}\n", label, file, e)),
        }
    }

    std::fs::write(out_dir.join("measurements.tsv"), &tsv).map_err(|e| format!("tsv write: {e}"))?;
    std::fs::write(out_dir.join("ledger.tsv"), &ledger).map_err(|e| format!("ledger write: {e}"))?;
    std::fs::write(out_dir.join("fonts.tsv"), &font_rows).map_err(|e| format!("fonts write: {e}"))?;
    println!("rows={rows} glyphs={}", cfg.glyphs.len());
    println!("{font_rows}");
    Ok(())
}
