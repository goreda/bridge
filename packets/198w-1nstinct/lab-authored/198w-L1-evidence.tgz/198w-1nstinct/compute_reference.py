"""Fixture/statistic definitions only. No grain renderer, texture or shader."""
from pathlib import Path
import numpy as np
import json, hashlib, platform
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'regenerated';OUT.mkdir(parents=True,exist_ok=True)
LAGS=[(1,0),(0,1),(1,1),(2,0),(0,2),(4,0),(0,4),(8,0),(0,8)]
def statistics(a):
    a=np.asarray(a,dtype=np.float64)
    v=a-a.mean(); var=float(np.mean(v*v))
    result={'mean':float(a.mean()),'sigma_population':float(np.sqrt(var)),'spatial_autocorrelation':{}}
    for dx,dy in LAGS:
        u=a[dy:,dx:].ravel();w=a[:a.shape[0]-dy,:a.shape[1]-dx].ravel()
        u=u-u.mean();w=w-w.mean();den=float(np.sqrt(np.dot(u,u)*np.dot(w,w)))
        result['spatial_autocorrelation'][f'{dx},{dy}']=float(np.dot(u,w)/den) if den>1e-28 else None
    return result

def main():
    # Synthetic fixture choices, not supplied product constants or calibrated thresholds.
    y,x=np.indices((256,256));rows=[]
    for family in ['flat','near_flat_checker','horizontal_gradient']:
      for level in [0.10,0.40,0.85]:
        if family=='flat': a=np.full((256,256),level)
        elif family=='near_flat_checker':a=level+(2*((x+y)%2)-1)/1024
        else:a=level+0.025*(2*x/255-1)
        s=statistics(a)
        # Roundoff is not measurable variance for constant arrays.
        if family=='flat':s={'mean':level,'sigma_population':0.0,'spatial_autocorrelation':{f'{dx},{dy}':None for dx,dy in LAGS}}
        rows.append({'fixture_id':f'{family}_L{level:.2f}','family':family,'center_luma':level,'input_luma_statistics':s,'input_f64le_sha256':hashlib.sha256(a.astype('<f8').tobytes()).hexdigest(),'grain_measurement_status':'NOT_ATTESTED','expected_grain_sigma':None,'expected_grain_spatial_autocorrelation':{f'{dx},{dy}':None for dx,dy in LAGS},'grain_frames_measured':0})
    meta=json.load(open(ROOT/'pin-metadata.json'))
    tree={'sha':meta['bridge_commit']};entries=[None]*meta['input_file_count'];grain={'sha':meta['grain_git_blob']}
    manifest={'excluded':{'texture_sha256':meta['omitted_texture_sha256'],'bytes':meta['omitted_texture_bytes']}}
    j={'schema':'198w-L1-grain-reference-v1','verdict':'BLOCKED_REFERENCE_UNAVAILABLE_FROM_ALLOWED_INPUTS','status':'NOT_ATTESTED','acceptance':False,'clean_checkout':False,'pins_changed':False,'bridge_commit_verified':tree['sha'],'allowed_input_files_at_pin':len(entries),'consumer_delivered_pin_sender_reported':'c7365054','consumer_binary_or_checkout_verified':False,
    'provenance':{'grain_sanitized_sha256':'79484d7f696dda78eb8f500c2a314c77d5a765a4acfb051e8b27472856d74365','grain_sanitized_git_blob_verified':grain['sha'],'texture_sha256_sender_manifest':manifest['excluded']['texture_sha256'],'texture_bytes_sender_manifest':manifest['excluded']['bytes'],'texture_present':False,'texture_read_or_reconstructed':False,'grain_source_or_patch_in_output':False,'held_material_status':'HOLD338421ea unchanged','sources':[{'url':'https://api.github.com/repos/goreda/bridge/git/trees/fb828d25?recursive=1','purpose':'resolved commit and73-entry input inventory'}, {'url':'https://raw.githubusercontent.com/goreda/bridge/fb828d25d5d1910f08e0c43c0b983d2d28ce1b32/inputs/198k/README.md','purpose':'texture omission and non-runnable grain caveat'}, {'url':'https://raw.githubusercontent.com/goreda/bridge/fb828d25d5d1910f08e0c43c0b983d2d28ce1b32/inputs/198k/manifest.json','purpose':'sanitized source and omitted texture hashes'}]},
    'blocker':{'reason':'The pinned export omits its required4096-byte grain texture. Its missing empirical distribution and spatial arrangement prevent identification of actual grain variance and autocorrelation. A SHA256 is an identity, not statistical data. No substitute texture or renderer was introduced.','missing_execution_inputs':['authorized original runtime resource available privately to its permitted executor','frozen actual grain runtime parameters, raster, SDR/HDR/output encoding and playback bucket identities','aligned grain-on/off captures from that same actual renderer'],'numeric_expectations_are_null_not_zero':True,'unblocking_requires_new_authorized_private_execution_not_publication_of_texture':True},
    'fixture_spec':{'origin':'reviewer-defined synthetic fixtures, not supplied calibration targets','width':256,'height':256,'channels':'achromatic R=G=B=luma','representation':'float64 for fixture sanity checks only; no output encoding equivalence claimed','center_luma_levels':[0.10,0.40,0.85],'flat':'I[y,x]=L','near_flat_checker':'I[y,x]=L+(2*((x+y)%2)-1)/1024','horizontal_gradient':'I[y,x]=L+0.025*(2*x/255-1)','coordinate_convention':'zero-based x,y; dx horizontal, dy vertical; no wrap; overlaps only','these_inputs_alone_do_not_determine_adaptive_scene_state':True},
    'grain_statistic_contract':{'residual':'aligned actual grain-on luma minus grain-off luma, holding source/crop/transform/bucket and non-grain state fixed','units':'same normalized scalar luma domain for both captures, to be specified by actual executor','sigma':'population standard deviation of residual after subtracting its ROI mean','autocorrelation':'Pearson correlation of two overlap-only residual windows offset by dx,dy; each window separately mean-centered','lags_pixels':[list(t) for t in LAGS],'zero_variance_autocorrelation':None,'measurement_roi':'full256x256 only if capture alignment and output raster match; otherwise redefine before measuring','raw_output_autocorrelation_is_not_grain_autocorrelation':True,'expected_sigma_is_not_input_sigma':True,'do_not_infer_white_noise_or_independent_layers':True,'no_tolerance_or_acceptance_threshold_calibrated':True,'ensemble_estimation':'No ensemble sampled. Future executor must declare frame/bucket count and sampling rule; report per-bucket statistics and uncertainty, not pretend one frame is an expectation.'},
    'reviewer_measured':{'input_fixture_count':9,'grain_output_frames':0,'grain_runtime_executed':False,'platform':platform.system(),'numpy':np.__version__},'fixtures':rows,'secret_scan':{'status':'PENDING_GENERATED_OUTPUT_SCAN'}}
    (OUT/'reference-grain-statistics.json').write_text(json.dumps(j,indent=2,allow_nan=False)+'\n')
    print('Generated9 input-fixture sanity measurements; grain frames0; all9 expected grain sigma and all81 correlations null/NOT_ATTESTED')
    assert len(rows)==9 and len({r['input_f64le_sha256'] for r in rows})==9
    assert all(r['expected_grain_sigma'] is None for r in rows)
    for r in rows:
      st=r['input_luma_statistics'];fam=r['family']
      if fam=='near_flat_checker':assert abs(st['sigma_population']-1/1024)<1e-14
      if fam=='horizontal_gradient':assert abs(st['sigma_population']-0.025*np.sqrt(257/(3*255)))<1e-14
    assert statistics(np.zeros((20,20)))['spatial_autocorrelation']['1,0'] is None
    print('PASS input analytic-sigma/zero-variance sanity assertions; not grain calibration')
if __name__=='__main__':main()
