#!/bin/bash
# WG-0115 driver: stages /tmp/wh33 from the WG-0074 v3 bundle + declared WG-0115 deltas,
# then runs profiles P0mod (control), P3, P4 via the ORIGINAL run_profile.sh/topo.sh.
# WG-0074 convention kept: topo.sh invokes /tmp/wh33/cli_work.sh, so the declared
# cli_work_att.sh content is staged at that path (same staging pattern as WG-0074).
set -u
SRC=${1:?source dir with original_pinned/ and att files}
rm -rf /tmp/wh33; mkdir -p /tmp/wh33
cp "$SRC"/original_pinned/* /tmp/wh33/
cp "$SRC"/wan_client_att.js "$SRC"/wan_harness_att.js /tmp/wh33/
cp "$SRC"/cli_work_att.sh /tmp/wh33/cli_work.sh
cp "$SRC"/wan_client_ord.js "$SRC"/wan_harness_ord.js /tmp/wh33/ 2>/dev/null || true
: > /tmp/wh33/att_driver.log
for spec in "P0mod 0 0 0" "P3 150 30 1" "P4 250 50 3"; do
  set -- $spec
  echo "=== $(date -u +%H:%M:%S) start $1 ($2/$3/$4)" >> /tmp/wh33/att_driver.log
  SESSIONS=15 bash /tmp/wh33/run_profile.sh "$1" "$2" "$3" "$4" >> /tmp/wh33/att_driver.log 2>&1
  echo "=== $(date -u +%H:%M:%S) end $1 rc=$?" >> /tmp/wh33/att_driver.log
done
echo "=== $(date -u +%H:%M:%S) DRIVER_DONE" >> /tmp/wh33/att_driver.log
