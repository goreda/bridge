#!/usr/bin/env python3
"""WG-0115 analysis v2: non-delivering reconnect attempts at P3 and P4 (P0mod control).
Reads att_results_<profile>_<arm>.jsonl next to this script.
Registered definitions:
  attempt           = one entry [cid, ms] in attempt_log (every connect() call, logged at send time).
  reconnect attempt  = attempt with integer cid >= 2 (initial open cid=1 reported separately).
  delivering        = cid appears in order_log ([seq, ms, cid] per reception).
  non-delivering    = reconnect attempt whose cid never appears in order_log.
Row validity (registered): a row is INVALID, excluded from every metric, and counted by
reason if any of: r.error set; attempt_log missing/not a list/entries malformed;
order_log missing/not a list/entries malformed; session_index missing or duplicated
within the cell. Invalid rows contribute NO zeros: nothing is imputed. Metrics use
valid rows only; effective coverage (valid rows / 15 expected) is reported per cell.
A cell with zero valid reconnect attempts has fraction None (undefined), never 0."""
import json, os, math
PROFILES = ["P0mod", "P3", "P4"]
ARMS = ["sse-nocatch", "sse-catchup", "ws-catchup"]
EXPECTED_SESSIONS = 15

def valid_attempt(e):
    return isinstance(e, list) and len(e) == 2 and isinstance(e[0], int) and isinstance(e[1], (int, float))

def valid_order(e):
    return (isinstance(e, list) and len(e) == 3 and isinstance(e[0], int)
            and isinstance(e[1], (int, float)) and isinstance(e[2], int))

def pstdev(xs):
    m = sum(xs) / len(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))

out = {"cells": {}, "controls": {}, "expected_sessions_per_cell": EXPECTED_SESSIONS}
c1_missing = c1_mismatch = c2_fail = c3_fail = 0
for p in PROFILES:
    for arm in ARMS:
        key = f"{p}/{arm}"
        fn = f"att_results_{p}_{arm}.jsonl"
        cell = {"expected_sessions": EXPECTED_SESSIONS}
        if not os.path.exists(fn):
            cell.update({"error": "missing file", "rows_present": 0, "invalid_rows": {},
                         "valid_rows": 0, "coverage": 0.0,
                         "fraction_non_delivering": None})
            out["cells"][key] = cell; continue
        rows = []
        bad_lines = 0
        for line in open(fn):
            if not line.strip(): continue
            try: rows.append(json.loads(line))
            except Exception: bad_lines += 1
        seen_idx, dup_idx = set(), set()
        for r in rows:
            i = r.get("session_index") if isinstance(r, dict) else None
            if i in seen_idx: dup_idx.add(i)
            seen_idx.add(i)
        invalid = {"error_set": 0, "attempt_log_missing_or_malformed": 0,
                   "order_log_missing_or_malformed": 0,
                   "session_index_missing_or_duplicated": 0}
        valid_rows = []
        for r in rows:
            reasons = []
            if not isinstance(r, dict): invalid["attempt_log_missing_or_malformed"] += 1; continue
            if r.get("error"): reasons.append("error_set")
            att = r.get("attempt_log")
            if not isinstance(att, list) or any(not valid_attempt(e) for e in att):
                reasons.append("attempt_log_missing_or_malformed")
            ol = r.get("order_log")
            if not isinstance(ol, list) or any(not valid_order(e) for e in ol):
                reasons.append("order_log_missing_or_malformed")
            i = r.get("session_index")
            if not isinstance(i, int) or i in dup_idx:
                reasons.append("session_index_missing_or_duplicated")
            if reasons:
                for q in set(reasons): invalid[q] += 1
                continue
            # controls on valid rows (raw lists, duplicates preserved)
            req = r.get("requests")
            if req is None: c1_missing += 1
            elif len(att) != req: c1_mismatch += 1
            cids = [e[0] for e in att]
            if not {e[2] for e in ol}.issubset(set(cids)): c2_fail += 1
            if len(set(cids)) != len(cids) or sorted(cids) != list(range(1, len(cids) + 1)):
                c3_fail += 1
            valid_rows.append((r, att, ol))
        per_session, cell_rec, cell_nd, cell_att, cell_init_nd = [], 0, 0, 0, 0
        for r, att, ol in valid_rows:
            delivering = {e[2] for e in ol}
            rec = [c for c, _ms in att if c >= 2]
            nd = [c for c in rec if c not in delivering]
            init_nd = 1 if (any(c == 1 for c, _ in att) and 1 not in delivering) else 0
            cell_rec += len(rec); cell_nd += len(nd); cell_att += len(att); cell_init_nd += init_nd
            per_session.append({"session_index": r["session_index"], "timed_out": r.get("timed_out"),
                                "reconnects": len(rec), "non_delivering": len(nd),
                                "fraction": (len(nd) / len(rec)) if rec else None})
        n_valid = len(valid_rows)
        nd_counts = [s["non_delivering"] for s in per_session]
        tot_nd = sum(nd_counts); srt = sorted(nd_counts, reverse=True)
        fr = [s["fraction"] for s in per_session if s["fraction"] is not None]
        cell.update({
            "rows_present": len(rows), "unparseable_lines": bad_lines,
            "invalid_rows": {k: v for k, v in invalid.items() if v}, "invalid_rows_total": sum(invalid.values()),
            "valid_rows": n_valid, "coverage_valid_over_15": n_valid / EXPECTED_SESSIONS,
            "missing_session_indices": sorted(set(range(EXPECTED_SESSIONS)) - {i for i in seen_idx if isinstance(i, int)}),
            "duplicate_session_indices": sorted(i for i in dup_idx if isinstance(i, int)),
            "attempts_total": cell_att, "reconnect_attempts_effective_denominator": cell_rec,
            "non_delivering": cell_nd,
            "fraction_non_delivering": (cell_nd / cell_rec) if cell_rec else None,
            "fraction_note": None if cell_rec else "undefined: zero valid reconnect attempts",
            "initial_open_non_delivering": cell_init_nd,
            "stability": {
                "per_session_non_delivering": nd_counts,
                "max_single_session_share": (srt[0] / tot_nd) if tot_nd else None,
                "top3_share": (sum(srt[:3]) / tot_nd) if tot_nd else None,
                "uniform_baseline_single_share": 1 / EXPECTED_SESSIONS,
                "uniform_baseline_top3_share": 3 / EXPECTED_SESSIONS,
                "cv_population_sd": (pstdev(nd_counts) / (tot_nd / n_valid)) if tot_nd and n_valid else None,
                "per_session_fraction_min": min(fr) if fr else None,
                "per_session_fraction_max": max(fr) if fr else None,
            },
            "per_session": per_session,
        })
        out["cells"][key] = cell
out["controls"] = {
    "C1_requests_counter_missing_rows": c1_missing,
    "C1_attempt_log_len_ne_requests_rows": c1_mismatch,
    "C2_order_log_cid_not_in_attempts_rows": c2_fail,
    "C3_duplicate_noninteger_or_noncontiguous_cid_rows": c3_fail,
    "C4_P0mod_catchup_fraction_expect_0": {
        a: out["cells"].get(f"P0mod/{a}", {}).get("fraction_non_delivering")
        for a in ("sse-catchup", "ws-catchup")},
}
json.dump(out, open("wg115_analysis_output.json", "w"), indent=1, sort_keys=True)
print(json.dumps(out, indent=1, sort_keys=True))
