'use strict';
// WAN DELTA (WH-0033): exactly one guarded line vs published rex_client.js (see below).
// rex_client.js - WH-0014 reconnect-arm fixture client.
// Emulated browser client (foreground scheduling, as in W-0052): opens one push stream
// (SSE or WebSocket), drops and re-establishes it at CONTROLLED intervals
// (fixed schedule, identical across sessions and arms), and records every received
// event with a client-side timestamp. Arms:
//   sse-nocatch : SSE, re-open WITHOUT since -> events emitted while down are lost.
//   sse-catchup : SSE, re-open with ?since=<max contiguous seq> -> server replays the gap.
//   ws-catchup  : WebSocket, sends {"since":N} after upgrade -> server replays the gap.
const http = require('http');
const crypto = require('crypto');
const { mulberry32, seedFrom } = require('./prng');

function getJson(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, (res) => {
      let b = '';
      res.on('data', (c) => (b += c));
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
    req.setTimeout(5000, () => req.destroy(new Error('req timeout')));
  });
}
function openEventStream(url, onEvent) {
  const req = http.get(url, (res) => {
    let buf = '';
    res.on('data', (chunk) => {
      buf += chunk;
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const frame = buf.slice(0, idx); buf = buf.slice(idx + 2);
        for (const line of frame.split('\n')) {
          if (line.startsWith('data: ')) { try { onEvent(JSON.parse(line.slice(6))); } catch (e) {} }
        }
      }
    });
  });
  req.on('error', () => {}); // destroy() during controlled drop surfaces here
  return { close: () => req.destroy() };
}
// Minimal RFC 6455 client: masked text frames, no fragmentation, no ping/pong.
function wsConnect(url, onMessage) {
  const u = new URL(url);
  const key = crypto.randomBytes(16).toString('base64');
  const req = http.request({ host: u.hostname, port: u.port, path: u.pathname + u.search,
    headers: { Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Key': key, 'Sec-WebSocket-Version': 13 } });
  const state = { socket: null, open: false };
  req.on('upgrade', (res, socket) => {
    state.socket = socket; state.open = true;
    let buf = Buffer.alloc(0);
    socket.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      // server frames are unmasked, no fragmentation
      let off = 0;
      while (off + 2 <= buf.length) {
        const b1 = buf[off + 1];
        let len = b1 & 0x7f, p = off + 2;
        if (len === 126) { if (p + 2 > buf.length) break; len = buf.readUInt16BE(p); p += 2; }
        else if (len === 127) { if (p + 8 > buf.length) break; len = Number(buf.readBigUInt64BE(p)); p += 8; }
        if (p + len > buf.length) break;
        const opcode = buf[off] & 0x0f;
        if (opcode === 0x1) { try { onMessage(JSON.parse(buf.slice(p, p + len).toString('utf8')), state); } catch (e) {} }
        off = p + len;
      }
      buf = buf.slice(off); // drop consumed frames; keep any partial tail
    });
    socket.on('error', () => {});
    if (state.onopen) state.onopen(state);
  });
  req.on('error', () => {});
  req.end();
  return {
    sendJson: (obj) => {
      if (!state.socket) return;
      const payload = Buffer.from(JSON.stringify(obj));
      const mask = crypto.randomBytes(4);
      const len = payload.length;
      let head;
      if (len < 126) { head = Buffer.from([0x81, 0x80 | len]); }
      else { head = Buffer.alloc(4); head[0] = 0x81; head[1] = 0x80 | 126; head.writeUInt16BE(len, 2); }
      const masked = Buffer.from(payload);
      for (let i = 0; i < masked.length; i++) masked[i] ^= mask[i & 3];
      state.socket.write(Buffer.concat([head, mask, masked]));
    },
    onOpen: (fn) => { if (state.open) fn(state); else state.onopen = fn; },
    close: () => { try { if (state.socket) state.socket.destroy(); } catch (e) {} },
  };
}
// Emulated browser scheduler (foreground: timers fire at requested delay). Counts firings.
function makeScheduler() {
  let firings = 0;
  return {
    firings: () => firings,
    after: (delay, fn) => { const id = setTimeout(() => { firings++; fn(); }, delay); return id; },
    clear: (id) => clearTimeout(id),
  };
}

// run_rex_fixture(config) -> per-session metrics row.
// config: {server_url, arm:'sse-nocatch'|'sse-catchup'|'ws-catchup', seed,
//          drop_start_ms, drop_period_ms, drop_len_ms, hard_timeout_ms}
async function run_rex_fixture(cfg) {
  const sched = makeScheduler();
  const cpu0 = process.cpuUsage();
  const t0 = Date.now();
  const base = cfg.server_url;
  const DROP_START = cfg.drop_start_ms, DROP_PERIOD = cfg.drop_period_ms, DROP_LEN = cfg.drop_len_ms;
  const HARD_TIMEOUT = cfg.hard_timeout_ms;
  const ctrl = await getJson(base + '/rex/new?seed=' + cfg.seed); // control plane, not counted
  const sessionId = ctrl.session_id;
  let requests = 0;
  let done = false;
  const order_log = []; // WG-0074 DELTA
  const attempt_log = []; // WG-0115 DELTA: every connection attempt, delivering or not
  const received = new Map(); // seq -> {first_at, count, conn_id}
  let connId = 0;
  let stream = null;
  let ws = null;
  const timerIds = [];
  const drops = []; // {start_at, end_at, first_recv_after_ms, gap_seqs later filled}

  const maxContig = () => { let n = 0; while (received.has(n + 1)) n++; return n; };
  const note = (ev, cid) => {
    const at = Date.now();
    if (done) return;
    order_log.push([ev.seq, at - t0, cid]); // WG-0074 DELTA: ordered arrival log (observation only)
    const prev = received.get(ev.seq);
    if (prev) prev.count++;
    else received.set(ev.seq, { first_at: at, count: 1, conn_id: cid, emitted_at: ev.emitted_at, done: ev.done });
    if (ev.done) finish(false);
  };
  const connect = () => {
    if (done) return;
    connId++;
    const cid = connId;
    attempt_log.push([cid, Date.now() - t0]); // WG-0115 DELTA: logged at send time, before any reception
    requests++;
    if (cfg.arm === 'ws-catchup') {
      ws = wsConnect(base.replace('http', 'ws') + '/rex/ws?id=' + sessionId, (ev) => note(ev, cid));
      ws.onOpen(() => { if (ws) ws.sendJson({ since: maxContig() }); }); // WAN DELTA: guard stale onOpen after scheduled disconnect (handshake can outlive the drop window under netem; duplicate since is ignored server-side by the pending flag)
    } else {
      const since = cfg.arm === 'sse-catchup' ? maxContig() : 0;
      stream = openEventStream(base + '/rex/events?id=' + sessionId + (since ? '&since=' + since : ''), (ev) => note(ev, cid));
    }
  };
  const disconnect = () => {
    if (stream) { stream.close(); stream = null; }
    if (ws) { ws.close(); ws = null; }
  };
  let finishDone = false;
  const finish = (timedOut) => {
    if (finishDone) return; finishDone = true; done = true;
    for (const id of timerIds) sched.clear(id);
    disconnect();
    const tEnd = Date.now();
    // per-drop recovery delay: first reception after the re-open moment
    const dropStats = drops.map((d) => {
      let first = null;
      for (const [seq, r] of received) {
        if (r.first_at >= d.end_at && (first === null || r.first_at < first)) first = r.first_at;
      }
      return { start_at: d.start_at, end_at: d.end_at,
               recovery_delay_ms: first === null ? null : first - d.end_at };
    });
    resolveDone({
      session_id: sessionId, arm: cfg.arm, seed: cfg.seed,
      events_received_unique: received.size,
      receptions_total: [...received.values()].reduce((a, r) => a + r.count, 0),
      duplicates: [...received.values()].reduce((a, r) => a + r.count - 1, 0),
      done_received: !timedOut && received.size > 0 && [...received.values()].some((r) => r.done),
      timed_out: timedOut,
      session_wall_ms: tEnd - t0,
      requests, timer_firings: sched.firings(),
      cpu_ms: Math.round(((process.cpuUsage().user - cpu0.user) + (process.cpuUsage().system - cpu0.system)) / 10) / 100,
      drops: dropStats,
      order_log, // WG-0074 DELTA
      attempt_log, // WG-0115 DELTA
      received_map: [...received.entries()].map(([seq, r]) => ({ seq, first_at_ms: r.first_at, count: r.count, emitted_at: r.emitted_at, done: r.done })),
      error: null,
    });
  };
  let resolveDone;
  const doneP = new Promise((res) => { resolveDone = res; });
  // controlled drop schedule: fixed offsets, identical across sessions and arms
  for (let s = DROP_START; s + DROP_LEN < HARD_TIMEOUT; s += DROP_PERIOD) {
    timerIds.push(sched.after(s, () => { if (done) return; disconnect(); drops.push({ start_at: Date.now(), end_at: Date.now() + DROP_LEN }); }));
    timerIds.push(sched.after(s + DROP_LEN, () => { if (done) return; connect(); }));
  }
  timerIds.push(sched.after(HARD_TIMEOUT, () => finish(true)));
  connect(); // initial stream open
  return doneP;
}
module.exports = { run_rex_fixture, getJson };
