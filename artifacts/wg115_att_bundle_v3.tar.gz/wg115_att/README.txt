WG-0115 non-delivering reconnect attempts - measurement bundle.
Pre-registration: PREREG_WG0115.md (public receipt in2tinct H-0309, 2026-10-25 20:41:58 UTC,
canonical page https://files.instinct.com/21801ahjs1xw-wg-0115-pre-registration-file,
27,683 B, sha256 0debec6310aebd1bce419487ff073ad04abc1b3ca9d32dcf5fa0e16268a1dd22).

ACTUAL RUN HISTORY (no silent selection; everything completed was kept):
- Measurement start 2026-10-25 20:43:20 UTC, after public receipt 20:41:58 UTC.
- The registered driver was executed in resumable chunks: run_profile.sh per chunk with
  SESSIONS=15 WALL_BUDGET_MS=60000, the pinned harness's own append-only resume (completed
  (arm,session_index) rows are skipped; the wall budget is checked only between sessions, and
  a session's row is appended at session completion - the same documented behavior as
  WG-0074's driver). Chunk boundaries are in att_driver.log.
- P0mod (0/0/0): chunks at 20:43:22, 20:44:42, 20:45:59 UTC; cumulative rows 17, 34, 45; complete 20:47:03.
- P3 (150/30/1%): chunks at 20:47:09, 20:48:35, 20:49:54, 20:51:16, 20:52:46 UTC; cumulative 11, 23, 36, 42, 45; complete 20:53:32.
- P4 (250/50/3%): first chunk at 20:53:34 aborted. Observed: the server-side namespace's
  veths device never appeared - the setup script's 10 s device wait expired and its three
  setup commands failed ("Cannot find device veths" x3, att_driver.log), and the server-side
  link observer logged the same error every 5 s from 20:53:44 to 20:55:19
  (linkobs_srv_P4.log), stopping when the chunk watchdog killed the chunk at 110 s
  (20:55:24, rc=124). Zero sessions started; zero rows were written. Later "Cannot find
  device veths" errors appear in all three server-side link-observer logs (P0mod from
  20:44:42, P3 from 20:48:30, P4 from 20:57:18), each starting right after a chunk teardown
  and recurring until 21:03:41-21:03:44, when the measurement ended; these later errors
  match routine per-chunk teardown and are not specific to the abort. Whether the kill
  orphaned server-side namespace processes, and if so when they ended, is not established
  from the logs: no observer output exists at or after 21:08, and orphaned observers were
  still logging across chunk boundaries, so the earlier host-reaping rationale is not
  uniformly supported either.
  (Dated repair 2026-10-25: an earlier version of this README said the aborted chunk's
  observer "kept logging until reaped by the host by ~21:08"; that timing is not supported
  by the logs, and the reaping cause is not established.)
  Suspected cause of the abort: a race in veth pair creation / netns handoff 2 s after the
  previous chunk's teardown - not confirmed from logs. Retry at 20:55:48 succeeded in a
  fresh namespace and veth pair. Further chunks 20:57:21, 20:58:47, 21:00:15, 21:01:48 UTC;
  cumulative 9, 18, 27, 38, 45; complete 21:03:14.
- In-flight loss across chunk interruptions: zero. 14 chunk runs in total; all 13
  non-aborted exits were clean (rc=0, budget checked between sessions), and the one kill
  struck before any session began. No in-flight session, and no in-flight connection
  attempt, left no row. Every row present is a completed session; no row was rerun
  selectively and no row was dropped.
- 135 rows total (9 cells x 15), all valid per the registered validity rules (coverage
  15/15 every cell). Fractions condition on completed, recorded sessions; here the recorded
  sessions are all 135 registered sessions (135/135), so the conditioning drops nothing.

CONTROLS (wg115_analysis_output.json): C1a 0, C1b 0, C2 0, C3 0 failed rows; C4 P0mod
catchup fractions 0.0 / 0.0 as registered. Analysis run 21:03 UTC on the shipped rows.

Environment: Node v22.23.3, Linux 7.2.9, iproute2 5.15.0-1ubuntu2.2 local prefix,
unprivileged userns+netns, kernel netem. All traffic inside the 10.99.0.0/24 veth pair.
