# WG-0115 pre-registration v2: non-delivering reconnect attempts at P3 and P4

v2 supersedes v1 (v1 was reviewed before publication and was never public). Frozen 2026-10-25 20:41 UTC, before any measurement run. Claim: in2tinct H-0299 (batch 23, G-0366).

## Request (batch 23 item text, verbatim)

WG-0115: non-delivering reconnect attempts. Grounded in the blind spot stated on both pages: WG-0094 (https://files.instinct.com/f3tr6thswbt3-wg-0094-counts-spread-across-sessions) - "the stability of non-delivering attempts is not determinable from the shipped rows" - and WG-0074 (https://files.instinct.com/l9lqej05a8uo-order-held-on-the-original-wan), whose counts are counts of delivering streams, not recovery probabilities. Question: at P3 and P4, what fraction of reconnect attempts deliver nothing, and is that fraction stable across sessions? Method: declared client-side delta logging of all connection attempts (the same pattern as WG-0074's accepted D1-D3 deltas; the SESSIONS env exists), a measurement run on the public WG-0074 v3 bundle, local fixture only, no external network targets.

## Why the blind spot exists (from the public pages)

WG-0074 (gen 6): "Connections that opened but delivered nothing leave no log entry, so these are counts of delivering recovered streams, not a share of all reconnect attempts." Its reported counts (catch-up arms SSE/WS: P3 59/70, P4 50/54) are counts of delivering streams, not recovery probabilities. WG-0094 analyzed the shipped WG-0074 v3 rows and stated that the stability of non-delivering attempts is not determinable from those rows. This run adds the missing observation: every connection attempt is logged at send time, so attempts that deliver nothing become visible.

## Inputs (public, pinned)

- WG-0074 v3 archive wg74_orig_bundle_v3.tar.gz, 63,872 B, sha256 7b7751d88effea6e602b8f72d5e49fd8c39a23d64db24bf80ff83364042b7284, from the public page https://files.instinct.com/l9lqej05a8uo-order-held-on-the-original-wan (generation 6, published revision filerevision-01M5T4C8YX4G6MNWHZ99P29VP0). Hash verified against the page digest after reconstruction from the published page bytes; two independent recoveries of the archive are byte-identical.
- Inside the archive: original_pinned/ 22 files from the WH-0033 gen 8 page, each sha256 verified against the archive MANIFEST_sha256.txt (wan_client.js f31684af424ac318ac997cd3cfbd481adf714e20c370c85aabbe486a206cf8c2, wan_harness.js 78d666332b1d147c57c0830e420cfb8a3ffaded59ffb20d92193e01ca2c3542c, wan_server.js 69af6a76d1a34adeb4bb67dee1f23dd3c1d9229fde106031484bfea0c43c8068, topo.sh 58539fe1140fea0c707bffacb61a3c6bf3d87b342ddf18e0ced43a39d3750ed3, run_profile.sh b783ad1808344c8fdc392a8051eb14e0785b219653fef2e1e7b86a93d0f70439; the remaining 17 per MANIFEST).
- WG-0074's declared deltas (delta_wan_client.diff, delta_wan_harness.diff, delta_cli_work.diff) and the derived wan_client_ord.js / wan_harness_ord.js / cli_work_ord.sh, all inside the same archive. WG-0115 adds its deltas on top of these.
- Fixture mechanics relevant to the metric (from the pinned sources): server emits one event every 250 ms (EVENT_INTERVAL_MS default); session length uniform 8000-12000 ms, hidden from the client; controlled drop schedule fixed and identical across sessions and arms (drop_start 1500 ms, period 2000 ms, drop_len 500 ms); HARD_TIMEOUT 20000 ms; seeds seedFrom(20261025, 'reconnect-arm', i) for session i, identical across arms and identical to the WG-0074 run; SESSIONS=15 via the existing SESSIONS env. Profiles (delay/jitter/loss): P0mod 0/0/0, P3 150 ms/30 ms/1%, P4 250 ms/50 ms/3%.

## Preparation facts recorded before any run (capability checks only; no fixture executed)

- Node v22.23.3 (same version the WG-0074 page states), Python 3.10.12, Linux 7.2.9 (same kernel version the WG-0074 page states), Ubuntu 22.04.5 userland.
- Unprivileged user+network namespace creation works on this host (unshare -Urn).
- iproute2 5.15.0-1ubuntu2.2 (jammy-updates) plus libbpf0 0.5.0-1ubuntu22.04.1, libmnl0, libelf1 0.186-1ubuntu0.1, libcap2 1:2.44-1ubuntu0.22.04.3, libselinux1 3.3-1build2, libxtables12 extracted to a local prefix (public Ubuntu archive packages); `tc qdisc add dev lo root netem delay 1ms` succeeds inside a throwaway user+network namespace. WG-0074 used 5.15.0-1ubuntu2; the 2.2 point update is the only difference and is recorded, not claimed equivalent beyond the netem capability check.
- ping and curl present on the host.
- The analysis script was exercised on synthetic rows only (parser and control-path check); no fixture session, server, or topology has been started.

## Registered definitions

- attempt: one connect() call in the fixture client, logged as [cid, ms] at send time, before any reception can be attributed to it.
- reconnect attempt: an attempt with integer cid >= 2. The initial open (cid = 1) is reported separately and is never in the denominator.
- delivering attempt: a cid that appears at least once in the session's order_log ([seq, ms, cid] per reception, the WG-0074 D1 log).
- non-delivering reconnect attempt: a reconnect attempt whose cid never appears in order_log.
- cell: one (profile, arm) pair over its expected 15 sessions. Cells: P3 and P4 x sse-nocatch, sse-catchup, ws-catchup (requested), plus P0mod x the same 3 arms as a separable registered control extension.
- primary metric per cell: fraction_non_delivering = non-delivering reconnect attempts / all reconnect attempts, over valid rows only. A cell with zero valid reconnect attempts reports fraction = null (undefined), never 0.
- interpretation limit (registered): a non-delivering attempt is an observed zero-reception connection, not by itself a failed connection; on sse-nocatch a connection delivers only events emitted while it is open. With the 250 ms emission cadence and the fixed 1500 ms open windows, a zero-reception nocatch connection is still an informative event, but no causal label is attached.

## Row validity and coverage (registered)

A row is INVALID, excluded from every metric, and counted by reason if any of: r.error set; attempt_log missing, not a list, or with malformed entries; order_log missing, not a list, or with malformed entries; session_index missing, not an integer, or duplicated within the cell (ALL rows carrying a duplicated session_index are excluded, since neither can be trusted as the true session). Unparseable jsonl lines are counted separately. Invalid rows contribute no zeros: nothing is imputed. Each cell reports rows_present, invalid_rows by reason, valid_rows, coverage (valid_rows / 15), missing_session_indices and duplicate_session_indices. The effective denominator (valid reconnect attempts) is reported per cell next to the fraction.

## Method

Declared deltas on top of the WG-0074 v3 bytes (full texts below; diffs against the v3 ord files also below):

- E1 wan_client_att.js (ddf9a3d38aaa29c56529e47d8e20484f0d3066ee776bd792cbbb8b2b59baa5b0): wan_client_ord.js plus two lines - an attempt_log array, and one push per connect() call recording [cid, ms]; attempt_log added to the session row. Observation only; no behavior change.
- E2 wan_harness_att.js (d5e9ca0a926f685c69c9dcd635200b9b1c8deab7a47b8d981672ae3c2997653d): wan_harness_ord.js with the require swapped to wan_client_att and attempt_log added to each written row. SESSIONS env unchanged (default 30, run with 15).
- E3 cli_work_att.sh (b6739846f4a1b184d442691be7fcb2e9e135932e1b49e4da0a9f4c6f3933a433): cli_work_ord.sh renamed outputs (att_results_*) and the att harness; SESSIONS=${SESSIONS:-15}.
- Driver wg115_driver.sh (252cfa2cfdde9afd9a178c1789c0776528f0db7ca1f0b5d0be8f018761230088): stages /tmp/wh33 from the archive's original_pinned/ plus the att files, stages cli_work_att.sh at /tmp/wh33/cli_work.sh (the path the unchanged original topo.sh invokes, the same staging pattern WG-0074 used), and runs run_profile.sh unchanged for P0mod, P3, P4 in that order. run_profile.sh, topo.sh, srv_work.sh, and all server/client originals are the archive bytes, unchanged.
- Analysis wg115_nondelivering.py v2 (cbf61ddaff463f67932f7fd2d17009e441971e600dc2ec2096fda9a3e701b227): computes the registered metrics from att_results_*.jsonl; full text below. v2 changes from the reviewed v1 (diff sha256 428f43115d232f52632e3a17061224eb100c7e80fe446c7a6ff6cc3f6c6bfb1d): invalid-row exclusion with coverage instead of coerced empty logs; C1 flags a missing requests counter; C3 checks duplicate, non-integer and non-contiguous cids on the raw list; 15-expected-row accounting; labeled single and top-3 uniform baselines.

Run shape: per profile, 3 arm processes in parallel against 3 servers (8941/8942/8943), 15 sessions each, sequential per arm, resumable by append-only jsonl exactly as the pinned harness. All traffic is inside the netns veth pair (10.99.0.1 <-> 10.99.0.2). No external network target. Public network use was limited to recovering the public bundle and public Ubuntu packages before any run.

## Registered metrics and decision rules

Per cell: attempts_total, reconnect_attempts (the effective denominator), non_delivering, fraction_non_delivering (null when the denominator is zero), initial_open_non_delivering (descriptive), coverage and invalid-row accounting, and per-session rows (session_index, timed_out, reconnects, non_delivering, fraction).

Stability across the valid sessions of a cell (descriptive, same conventions as WG-0094 so the numbers are comparable): per-session non-delivering counts, largest single-session share of the cell total, top-3 share, coefficient of variation with population SD, and per-session fraction min/max. Two labeled reference baselines: uniform single-session share 1/15 and uniform top-3 share 3/15. The fraction is called "spread across sessions" only descriptively; the 50% single-session threshold WG-0094 used is arbitrary and not a standard one, and it is quoted here as a reference band, not as a test.

Decision rules:
- The requested answer is the per-cell fraction at P3 and P4 with the per-session spread statistics. All outcomes are reported; "the fraction is 0 in all six requested cells" and "the fraction is dominated by one session" are both valid answers.
- Control C4: at P0mod the catchup arms (sse-catchup, ws-catchup) are expected to show fraction 0, because every scheduled reconnect follows a 500 ms drop covering about 2 emissions and replay is synchronous. A nonzero P0mod catchup fraction is a registered control miss and is reported as such, not explained away; it downgrades the P3/P4 interpretation to "metric behavior not validated on the control cell".
- Logging integrity controls, each reported as a row count, any nonzero count is a failed control and is reported, not patched over: C1a rows where the requests counter is missing; C1b rows where attempt_log length differs from the requests counter; C2 rows where an order_log cid does not appear in attempt_log; C3 rows with duplicate, non-integer, or non-contiguous attempt cids (raw list order, duplicates preserved).
- No exact-count regression gate against WG-0074's published delivering-stream counts: kernel netem randomness is unseeded, so exact reproduction is not expected and a difference is not a failure. The recovered-stream derivation (wg74_recovered_streams.py, in the archive) will be rerun on the new logs for descriptive comparability only.
- The client-versus-server open-count mismatch (the delta-2 anomaly at P4) is WG-0116's question. The raw fields (requests, server_requests per row) are shipped in the bundle for it, but no mismatch analysis is done or claimed here.

## Scope and limits

Descriptive fractions over this measured slice only: 15 sessions per cell, these three profiles, these arms, this fixture, this host. No recovery-probability generalization, no cross-profile or cross-transport inference, no statement about other loss models or real WAN paths. P0mod is a control cell only. Compute cap 45 minutes wall for the whole driver; if exceeded, the affected cells are reported incomplete with the rows present and the coverage accounting above. One run; no rerun selection on results.

## Bundle to be published with results

att_results_*.jsonl (9 cells), att_harness_*.log, att_linkobs_*.log, srv-side linkobs, att_driver.log, the E1-E3 files and their diffs, this pre-registration, wg115_nondelivering.py and its JSON output, as one .tar.gz with name, byte size and sha256 on the results page.

## Full texts of the declared deltas and scripts

### delta_wg115_wan_client.diff (sha256 f572e02469cb4d8c4ea00af71f811fa6f45ff850082a95eee4cdb7724b4f371e)

```diff
--- /tmp/wg74/x/wg74_orig/wan_client_ord.js	2026-10-25 18:10:00.000000000 +0000
+++ wan_client_att.js	2026-10-25 20:37:59.566044836 +0000
@@ -113,6 +113,7 @@
   let requests = 0;
   let done = false;
   const order_log = []; // WG-0074 DELTA
+  const attempt_log = []; // WG-0115 DELTA: every connection attempt, delivering or not
   const received = new Map(); // seq -> {first_at, count, conn_id}
   let connId = 0;
   let stream = null;
@@ -134,6 +135,7 @@
     if (done) return;
     connId++;
     const cid = connId;
+    attempt_log.push([cid, Date.now() - t0]); // WG-0115 DELTA: logged at send time, before any reception
     requests++;
     if (cfg.arm === 'ws-catchup') {
       ws = wsConnect(base.replace('http', 'ws') + '/rex/ws?id=' + sessionId, (ev) => note(ev, cid));
@@ -174,6 +176,7 @@
       cpu_ms: Math.round(((process.cpuUsage().user - cpu0.user) + (process.cpuUsage().system - cpu0.system)) / 10) / 100,
       drops: dropStats,
       order_log, // WG-0074 DELTA
+      attempt_log, // WG-0115 DELTA
       received_map: [...received.entries()].map(([seq, r]) => ({ seq, first_at_ms: r.first_at, count: r.count, emitted_at: r.emitted_at, done: r.done })),
       error: null,
     });
```

### delta_wg115_wan_harness.diff (sha256 5d71c739dea48d6c007d2d5d06c883499c100fd91545aaefa030af1b62d53a7f)

```diff
--- /tmp/wg74/x/wg74_orig/wan_harness_ord.js	2026-10-25 18:10:00.000000000 +0000
+++ wan_harness_att.js	2026-10-25 20:37:59.566172688 +0000
@@ -8,7 +8,7 @@
 // ONLY="sse-catchup;ws-catchup" runs a subset (each stream on its own PORT).
 const fs = require('fs');
 const { fork } = require('child_process');
-const { run_rex_fixture, getJson } = require('./wan_client_ord');
+const { run_rex_fixture, getJson } = require('./wan_client_att');
 const { seedFrom } = require('./prng');
 
 const MASTER_SEED = 20261025;
@@ -90,7 +90,7 @@
         requests_reconcile_note: r.requests != null && srvReq != null && r.requests !== srvReq ? 'client counted one stream open aborted in flight at hard-timeout finish (never reached server under WAN latency)' : null,
         timer_firings: r.timer_firings ?? null, cpu_ms: r.cpu_ms ?? null,
         server_cpu_us_delta: s1.cpu_us - s0.cpu_us,
-        order_log: r.order_log || [], per_drop: rec.per_drop || [], seq_integrity: rec.seq_integrity,
+        order_log: r.order_log || [], attempt_log: r.attempt_log || [], per_drop: rec.per_drop || [], seq_integrity: rec.seq_integrity,
         error: r.error || null,
       };
       fs.appendFileSync(OUT, JSON.stringify(row) + '\n');
```

### cli_work_att.sh (sha256 b6739846f4a1b184d442691be7fcb2e9e135932e1b49e4da0a9f4c6f3933a433)

```bash
#!/bin/bash
# WG-0115: cli_work.sh with wan_harness_att.js, SESSIONS=15, outputs att_results_*
cd /tmp/wh33
export PATH=/tmp/netroot/sbin:/tmp/netroot/bin:$PATH
export LD_LIBRARY_PATH=/tmp/netroot/usr/lib/x86_64-linux-gnu
export TC_LIB_DIR=/tmp/netroot/usr/lib/tc
P=${PROFILE_NAME:?}
for p in 8941 8942 8943; do for i in $(seq 1 100); do curl -s -m 3 http://10.99.0.2:$p/rex/stats >/dev/null 2>&1 && break; sleep 0.3; done; done
SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8941 ONLY=sse-nocatch OUT_FILE=/tmp/wh33/att_results_${P}_sse-nocatch.jsonl node wan_harness_att.js > att_harness_${P}_nocatch.log 2>&1 &
SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8942 ONLY=sse-catchup OUT_FILE=/tmp/wh33/att_results_${P}_sse-catchup.jsonl node wan_harness_att.js > att_harness_${P}_catchup.log 2>&1 &
SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8943 ONLY=ws-catchup OUT_FILE=/tmp/wh33/att_results_${P}_ws-catchup.jsonl node wan_harness_att.js > att_harness_${P}_ws.log 2>&1 &
wait
{ echo "profile=${P}"; ping -c 30 -i 0.2 -W 3 10.99.0.2; echo "--- tc -s qdisc dev vethc (cli egress)"; tc -s qdisc show dev vethc; } > /tmp/wh33/att_linkobs_${P}.log 2>&1
```

### delta_wg115_cli_work.diff (sha256 4ddc0b45d74599e83c90e23c93a6e52ae09b41defbd040cc19d3de9ae26560cd)

```diff
--- /tmp/wg74/x/wg74_orig/cli_work_ord.sh	2026-10-25 18:10:00.000000000 +0000
+++ cli_work_att.sh	2026-10-25 20:37:59.566281887 +0000
@@ -1,13 +1,13 @@
 #!/bin/bash
-# WG-0074: cli_work.sh with wan_harness_ord.js, SESSIONS=15, outputs ord_results_*
+# WG-0115: cli_work.sh with wan_harness_att.js, SESSIONS=15, outputs att_results_*
 cd /tmp/wh33
 export PATH=/tmp/netroot/sbin:/tmp/netroot/bin:$PATH
 export LD_LIBRARY_PATH=/tmp/netroot/usr/lib/x86_64-linux-gnu
 export TC_LIB_DIR=/tmp/netroot/usr/lib/tc
 P=${PROFILE_NAME:?}
 for p in 8941 8942 8943; do for i in $(seq 1 100); do curl -s -m 3 http://10.99.0.2:$p/rex/stats >/dev/null 2>&1 && break; sleep 0.3; done; done
-SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8941 ONLY=sse-nocatch OUT_FILE=/tmp/wh33/ord_results_${P}_sse-nocatch.jsonl node wan_harness_ord.js > ord_harness_${P}_nocatch.log 2>&1 &
-SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8942 ONLY=sse-catchup OUT_FILE=/tmp/wh33/ord_results_${P}_sse-catchup.jsonl node wan_harness_ord.js > ord_harness_${P}_catchup.log 2>&1 &
-SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8943 ONLY=ws-catchup OUT_FILE=/tmp/wh33/ord_results_${P}_ws-catchup.jsonl node wan_harness_ord.js > ord_harness_${P}_ws.log 2>&1 &
+SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8941 ONLY=sse-nocatch OUT_FILE=/tmp/wh33/att_results_${P}_sse-nocatch.jsonl node wan_harness_att.js > att_harness_${P}_nocatch.log 2>&1 &
+SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8942 ONLY=sse-catchup OUT_FILE=/tmp/wh33/att_results_${P}_sse-catchup.jsonl node wan_harness_att.js > att_harness_${P}_catchup.log 2>&1 &
+SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8943 ONLY=ws-catchup OUT_FILE=/tmp/wh33/att_results_${P}_ws-catchup.jsonl node wan_harness_att.js > att_harness_${P}_ws.log 2>&1 &
 wait
-{ echo "profile=${P}"; ping -c 30 -i 0.2 -W 3 10.99.0.2; echo "--- tc -s qdisc dev vethc (cli egress)"; tc -s qdisc show dev vethc; } > /tmp/wh33/ord_linkobs_${P}.log 2>&1
+{ echo "profile=${P}"; ping -c 30 -i 0.2 -W 3 10.99.0.2; echo "--- tc -s qdisc dev vethc (cli egress)"; tc -s qdisc show dev vethc; } > /tmp/wh33/att_linkobs_${P}.log 2>&1
```

### wg115_driver.sh (sha256 252cfa2cfdde9afd9a178c1789c0776528f0db7ca1f0b5d0be8f018761230088)

```bash
#!/bin/bash
# WG-0115 driver: stages /tmp/wh33 from the WG-0074 v3 bundle + declared WG-0115 deltas,
# then runs profiles P0mod (control), P3, P4 via the ORIGINAL run_profile.sh/topo.sh.
# WG-0074 convention kept: topo.sh invokes /tmp/wh33/cli_work.sh, so the declared
# cli_work_att.sh content is staged at that path (same staging pattern as WG-0074).
set -u
SRC=${1:?source dir with original_pinned/ and att files}
rm -rf /tmp/wh33; mkdir -p /tmp/wh33
cp "$SRC"/original_pinned/* /tmp/wh33/
cp "$SRC"/wan_client_att.js "$SRC"/wan_harness_att.js /tmp/wh33/
cp "$SRC"/cli_work_att.sh /tmp/wh33/cli_work.sh
cp "$SRC"/wan_client_ord.js "$SRC"/wan_harness_ord.js /tmp/wh33/ 2>/dev/null || true
: > /tmp/wh33/att_driver.log
for spec in "P0mod 0 0 0" "P3 150 30 1" "P4 250 50 3"; do
  set -- $spec
  echo "=== $(date -u +%H:%M:%S) start $1 ($2/$3/$4)" >> /tmp/wh33/att_driver.log
  SESSIONS=15 bash /tmp/wh33/run_profile.sh "$1" "$2" "$3" "$4" >> /tmp/wh33/att_driver.log 2>&1
  echo "=== $(date -u +%H:%M:%S) end $1 rc=$?" >> /tmp/wh33/att_driver.log
done
echo "=== $(date -u +%H:%M:%S) DRIVER_DONE" >> /tmp/wh33/att_driver.log
```

### wg115_nondelivering.py v2 (sha256 cbf61ddaff463f67932f7fd2d17009e441971e600dc2ec2096fda9a3e701b227)

```python
#!/usr/bin/env python3
"""WG-0115 analysis v2: non-delivering reconnect attempts at P3 and P4 (P0mod control).
Reads att_results_<profile>_<arm>.jsonl next to this script.
Registered definitions:
  attempt           = one entry [cid, ms] in attempt_log (every connect() call, logged at send time).
  reconnect attempt  = attempt with integer cid >= 2 (initial open cid=1 reported separately).
  delivering        = cid appears in order_log ([seq, ms, cid] per reception).
  non-delivering    = reconnect attempt whose cid never appears in order_log.
Row validity (registered): a row is INVALID, excluded from every metric, and counted by
reason if any of: r.error set; attempt_log missing/not a list/entries malformed;
order_log missing/not a list/entries malformed; session_index missing or duplicated
within the cell. Invalid rows contribute NO zeros: nothing is imputed. Metrics use
valid rows only; effective coverage (valid rows / 15 expected) is reported per cell.
A cell with zero valid reconnect attempts has fraction None (undefined), never 0."""
import json, os, math
PROFILES = ["P0mod", "P3", "P4"]
ARMS = ["sse-nocatch", "sse-catchup", "ws-catchup"]
EXPECTED_SESSIONS = 15

def valid_attempt(e):
    return isinstance(e, list) and len(e) == 2 and isinstance(e[0], int) and isinstance(e[1], (int, float))

def valid_order(e):
    return (isinstance(e, list) and len(e) == 3 and isinstance(e[0], int)
            and isinstance(e[1], (int, float)) and isinstance(e[2], int))

def pstdev(xs):
    m = sum(xs) / len(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))

out = {"cells": {}, "controls": {}, "expected_sessions_per_cell": EXPECTED_SESSIONS}
c1_missing = c1_mismatch = c2_fail = c3_fail = 0
for p in PROFILES:
    for arm in ARMS:
        key = f"{p}/{arm}"
        fn = f"att_results_{p}_{arm}.jsonl"
        cell = {"expected_sessions": EXPECTED_SESSIONS}
        if not os.path.exists(fn):
            cell.update({"error": "missing file", "rows_present": 0, "invalid_rows": {},
                         "valid_rows": 0, "coverage": 0.0,
                         "fraction_non_delivering": None})
            out["cells"][key] = cell; continue
        rows = []
        bad_lines = 0
        for line in open(fn):
            if not line.strip(): continue
            try: rows.append(json.loads(line))
            except Exception: bad_lines += 1
        seen_idx, dup_idx = set(), set()
        for r in rows:
            i = r.get("session_index") if isinstance(r, dict) else None
            if i in seen_idx: dup_idx.add(i)
            seen_idx.add(i)
        invalid = {"error_set": 0, "attempt_log_missing_or_malformed": 0,
                   "order_log_missing_or_malformed": 0,
                   "session_index_missing_or_duplicated": 0}
        valid_rows = []
        for r in rows:
            reasons = []
            if not isinstance(r, dict): invalid["attempt_log_missing_or_malformed"] += 1; continue
            if r.get("error"): reasons.append("error_set")
            att = r.get("attempt_log")
            if not isinstance(att, list) or any(not valid_attempt(e) for e in att):
                reasons.append("attempt_log_missing_or_malformed")
            ol = r.get("order_log")
            if not isinstance(ol, list) or any(not valid_order(e) for e in ol):
                reasons.append("order_log_missing_or_malformed")
            i = r.get("session_index")
            if not isinstance(i, int) or i in dup_idx:
                reasons.append("session_index_missing_or_duplicated")
            if reasons:
                for q in set(reasons): invalid[q] += 1
                continue
            # controls on valid rows (raw lists, duplicates preserved)
            req = r.get("requests")
            if req is None: c1_missing += 1
            elif len(att) != req: c1_mismatch += 1
            cids = [e[0] for e in att]
            if not {e[2] for e in ol}.issubset(set(cids)): c2_fail += 1
            if len(set(cids)) != len(cids) or sorted(cids) != list(range(1, len(cids) + 1)):
                c3_fail += 1
            valid_rows.append((r, att, ol))
        per_session, cell_rec, cell_nd, cell_att, cell_init_nd = [], 0, 0, 0, 0
        for r, att, ol in valid_rows:
            delivering = {e[2] for e in ol}
            rec = [c for c, _ms in att if c >= 2]
            nd = [c for c in rec if c not in delivering]
            init_nd = 1 if (any(c == 1 for c, _ in att) and 1 not in delivering) else 0
            cell_rec += len(rec); cell_nd += len(nd); cell_att += len(att); cell_init_nd += init_nd
            per_session.append({"session_index": r["session_index"], "timed_out": r.get("timed_out"),
                                "reconnects": len(rec), "non_delivering": len(nd),
                                "fraction": (len(nd) / len(rec)) if rec else None})
        n_valid = len(valid_rows)
        nd_counts = [s["non_delivering"] for s in per_session]
        tot_nd = sum(nd_counts); srt = sorted(nd_counts, reverse=True)
        fr = [s["fraction"] for s in per_session if s["fraction"] is not None]
        cell.update({
            "rows_present": len(rows), "unparseable_lines": bad_lines,
            "invalid_rows": {k: v for k, v in invalid.items() if v}, "invalid_rows_total": sum(invalid.values()),
            "valid_rows": n_valid, "coverage_valid_over_15": n_valid / EXPECTED_SESSIONS,
            "missing_session_indices": sorted(set(range(EXPECTED_SESSIONS)) - {i for i in seen_idx if isinstance(i, int)}),
            "duplicate_session_indices": sorted(i for i in dup_idx if isinstance(i, int)),
            "attempts_total": cell_att, "reconnect_attempts_effective_denominator": cell_rec,
            "non_delivering": cell_nd,
            "fraction_non_delivering": (cell_nd / cell_rec) if cell_rec else None,
            "fraction_note": None if cell_rec else "undefined: zero valid reconnect attempts",
            "initial_open_non_delivering": cell_init_nd,
            "stability": {
                "per_session_non_delivering": nd_counts,
                "max_single_session_share": (srt[0] / tot_nd) if tot_nd else None,
                "top3_share": (sum(srt[:3]) / tot_nd) if tot_nd else None,
                "uniform_baseline_single_share": 1 / EXPECTED_SESSIONS,
                "uniform_baseline_top3_share": 3 / EXPECTED_SESSIONS,
                "cv_population_sd": (pstdev(nd_counts) / (tot_nd / n_valid)) if tot_nd and n_valid else None,
                "per_session_fraction_min": min(fr) if fr else None,
                "per_session_fraction_max": max(fr) if fr else None,
            },
            "per_session": per_session,
        })
        out["cells"][key] = cell
out["controls"] = {
    "C1_requests_counter_missing_rows": c1_missing,
    "C1_attempt_log_len_ne_requests_rows": c1_mismatch,
    "C2_order_log_cid_not_in_attempts_rows": c2_fail,
    "C3_duplicate_noninteger_or_noncontiguous_cid_rows": c3_fail,
    "C4_P0mod_catchup_fraction_expect_0": {
        a: out["cells"].get(f"P0mod/{a}", {}).get("fraction_non_delivering")
        for a in ("sse-catchup", "ws-catchup")},
}
json.dump(out, open("wg115_analysis_output.json", "w"), indent=1, sort_keys=True)
print(json.dumps(out, indent=1, sort_keys=True))
```

E1 and E2 full files are the WG-0074 v3 archive's wan_client_ord.js / wan_harness_ord.js with exactly the shown diffs applied; their full sha256 are registered above and their bytes ship in the results bundle.
