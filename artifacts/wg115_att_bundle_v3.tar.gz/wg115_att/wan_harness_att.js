'use strict';
// WAN DELTA (WH-0033): external server via SERVER_BASE (server lives in a netem-shaped netns);
// adds profile field to each row; no server fork. Drop schedule, seeds, arms unchanged.
// rex_harness.js - WH-0014 full run: 3 arms x 30 sessions, sequential, resumable.
// Arms: sse-nocatch, sse-catchup, ws-catchup. Same controlled drop schedule for all.
// Resumability mirrors W-0052: append one JSON line per session to results_rex.jsonl;
// on restart existing (arm|session_index) keys are skipped. WALL_BUDGET_MS bounds chunks.
// ONLY="sse-catchup;ws-catchup" runs a subset (each stream on its own PORT).
const fs = require('fs');
const { fork } = require('child_process');
const { run_rex_fixture, getJson } = require('./wan_client_att');
const { seedFrom } = require('./prng');

const MASTER_SEED = 20261025;
const SESSIONS = Number(process.env.SESSIONS || 30); // WG-0074 DELTA: SESSIONS env (default 30 as published)
const BASE = process.env.SERVER_BASE || 'http://127.0.0.1:8941';
const PROFILE = process.env.PROFILE || 'wan-unspecified';
const ONLY = process.env.ONLY ? process.env.ONLY.split(';') : null;
const OUT = process.env.OUT_FILE || (__dirname + '/results_rex.jsonl');
const ARMS = ['sse-nocatch', 'sse-catchup', 'ws-catchup'];
// Controlled drop schedule (fixed, identical across sessions and arms):
const DROP = { drop_start_ms: 1500, drop_period_ms: 2000, drop_len_ms: 500 };
const HARD_TIMEOUT_MS = Number(process.env.HARD_TIMEOUT_MS || 20000);

async function main() {
  const startWall = Date.now();
  const budget = process.env.WALL_BUDGET_MS ? Number(process.env.WALL_BUDGET_MS) : null;
  // WAN DELTA (WH-0033): server runs externally (separate network namespace); no fork here.
  { const t0 = Date.now(); for (;;) { try { await getJson(BASE + '/rex/stats'); break; } catch (e) { if (Date.now() - t0 > 30000) throw e; await new Promise((r) => setTimeout(r, 250)); } } }
  const doneKeys = new Set();
  if (fs.existsSync(OUT)) {
    for (const line of fs.readFileSync(OUT, 'utf8').split('\n')) {
      if (!line.trim()) continue;
      try { const r = JSON.parse(line); doneKeys.add([r.arm, r.session_index].join('|')); } catch (e) {}
    }
  }
  console.log('resuming with ' + doneKeys.size + ' completed sessions');
  for (const arm of ARMS) {
    if (ONLY && !ONLY.includes(arm)) continue;
    for (let i = 0; i < SESSIONS; i++) {
      if (budget && Date.now() - startWall > budget) { console.log('BUDGET_EXIT completed=' + doneKeys.size); process.exit(0); }
      if (doneKeys.has([arm, i].join('|'))) continue;
      // Identical seed across arms per index: cells are paired on the same session-length draw.
      const seed = seedFrom(MASTER_SEED, 'reconnect-arm', i);
      const s0 = await getJson(BASE + '/rex/stats');
      let r;
      try {
        r = await run_rex_fixture({ server_url: BASE, arm, seed, ...DROP, hard_timeout_ms: HARD_TIMEOUT_MS });
      } catch (e) {
        r = { session_id: null, arm, seed, error: String(e) };
      }
      // WAN DELTA: let in-flight stream opens land server-side before reconciliation
      // (client counts an open at send time; server counts on receipt, ~1 RTT later under netem).
      await new Promise((r2) => setTimeout(r2, Number(process.env.RECONCILE_SETTLE_MS || 1500)));
      // server-side reconciliation (control plane): emitted log vs client receptions
      let rec = { emitted: null, reconciled: false, lost_seqs: [], gap_seqs: [], seq_integrity: false };
      if (r.session_id) {
        const logRes = await getJson(BASE + '/rex/log?id=' + r.session_id);
        const log = logRes.log;
        const recvSet = new Set((r.received_map || []).map((x) => x.seq));
        const emittedSet = new Set(log.map((e) => e.seq));
        rec.emitted = log.length;
        rec.lost_seqs = log.filter((e) => !recvSet.has(e.seq)).map((e) => e.seq);
        // per-drop gap analysis on the server clock
        rec.per_drop = (r.drops || []).map((d, k) => {
          const gap = log.filter((e) => e.emitted_at > d.start_at && e.emitted_at <= d.end_at).map((e) => e.seq);
          const gapRecv = gap.filter((s) => recvSet.has(s));
          const recvTimes = gapRecv.map((s) => r.received_map.find((x) => x.seq === s).first_at_ms);
          return { drop_index: k, gap_events: gap.length,
                   gap_recovered: gapRecv.length, gap_lost: gap.length - gapRecv.length,
                   backfill_ms: gap.length > 0 && gapRecv.length === gap.length ? Math.max(...recvTimes) - d.end_at : null,
                   recovery_delay_ms: d.recovery_delay_ms };
        });
        // integrity: every received seq was emitted; received + lost = emitted
        const allEmitted = [...recvSet].every((s) => emittedSet.has(s));
        rec.seq_integrity = allEmitted && (recvSet.size + rec.lost_seqs.length === log.length);
        rec.reconciled = rec.seq_integrity;
      }
      const s1 = await getJson(BASE + '/rex/stats');
      const srvReq = r.session_id && s1.sessions[r.session_id] ? s1.sessions[r.session_id].requests : null;
      const row = {
        profile: PROFILE, arm, session_index: i, seed: r.seed,
        emitted: rec.emitted, received_unique: r.events_received_unique ?? null,
        receptions_total: r.receptions_total ?? null, duplicates: r.duplicates ?? null,
        lost: rec.lost_seqs ? rec.lost_seqs.length : null,
        done_received: r.done_received ?? null, timed_out: r.timed_out ?? null,
        session_wall_ms: r.session_wall_ms ?? null,
        requests: r.requests ?? null, server_requests: srvReq,
        requests_reconciled: r.requests != null && srvReq != null ? (r.requests === srvReq || (r.timed_out === true && r.requests - srvReq === 1)) : null,
        requests_reconcile_note: r.requests != null && srvReq != null && r.requests !== srvReq ? 'client counted one stream open aborted in flight at hard-timeout finish (never reached server under WAN latency)' : null,
        timer_firings: r.timer_firings ?? null, cpu_ms: r.cpu_ms ?? null,
        server_cpu_us_delta: s1.cpu_us - s0.cpu_us,
        order_log: r.order_log || [], attempt_log: r.attempt_log || [], per_drop: rec.per_drop || [], seq_integrity: rec.seq_integrity,
        error: r.error || null,
      };
      fs.appendFileSync(OUT, JSON.stringify(row) + '\n');
      doneKeys.add([arm, i].join('|'));
      console.log('done', arm, i, 'emitted=' + row.emitted, 'recv=' + row.received_unique, 'lost=' + row.lost, 'dup=' + row.duplicates);
    }
  }
  console.log('ALL_DONE');
  process.exit(0); // DRIVER ROBUSTNESS (not measurement): half-open WAN sockets can hold the event loop after all rows are written
}
main().catch((e) => { console.error(e); process.exit(1); });
