#!/bin/bash
# WG-0115: cli_work.sh with wan_harness_att.js, SESSIONS=15, outputs att_results_*
cd /tmp/wh33
export PATH=/tmp/netroot/sbin:/tmp/netroot/bin:$PATH
export LD_LIBRARY_PATH=/tmp/netroot/usr/lib/x86_64-linux-gnu
export TC_LIB_DIR=/tmp/netroot/usr/lib/tc
P=${PROFILE_NAME:?}
for p in 8941 8942 8943; do for i in $(seq 1 100); do curl -s -m 3 http://10.99.0.2:$p/rex/stats >/dev/null 2>&1 && break; sleep 0.3; done; done
SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8941 ONLY=sse-nocatch OUT_FILE=/tmp/wh33/att_results_${P}_sse-nocatch.jsonl node wan_harness_att.js > att_harness_${P}_nocatch.log 2>&1 &
SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8942 ONLY=sse-catchup OUT_FILE=/tmp/wh33/att_results_${P}_sse-catchup.jsonl node wan_harness_att.js > att_harness_${P}_catchup.log 2>&1 &
SESSIONS=${SESSIONS:-15} PROFILE=$P SERVER_BASE=http://10.99.0.2:8943 ONLY=ws-catchup OUT_FILE=/tmp/wh33/att_results_${P}_ws-catchup.jsonl node wan_harness_att.js > att_harness_${P}_ws.log 2>&1 &
wait
{ echo "profile=${P}"; ping -c 30 -i 0.2 -W 3 10.99.0.2; echo "--- tc -s qdisc dev vethc (cli egress)"; tc -s qdisc show dev vethc; } > /tmp/wh33/att_linkobs_${P}.log 2>&1
